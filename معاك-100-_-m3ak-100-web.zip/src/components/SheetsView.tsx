import React, { useState, useEffect, useCallback } from 'react';
import { useApp } from '../context/AppContext';
import {
  signInWithGoogleWorkspace,
  getCachedAccessToken,
  initGoogleAuth
} from '../lib/googleAuth';
import {
  listSpreadsheets,
  getSpreadsheetMetadata,
  getSheetValues,
  appendSheetValues,
  createSpreadsheet,
  deleteSpreadsheet,
  SpreadsheetFile,
  SpreadsheetMetadata,
  SheetTab
} from '../lib/sheetsService';
import {
  FileSpreadsheet,
  Plus,
  RefreshCw,
  Search,
  ExternalLink,
  Trash2,
  Table,
  Upload,
  Layers,
  ChevronLeft,
  ChevronRight,
  ShieldCheck,
  CheckCircle,
  AlertTriangle,
  FileDown,
  Download,
  Database,
  ArrowRight,
  Sparkles,
  ShoppingBag,
  Package,
  Wallet,
  X
} from 'lucide-react';

export const SheetsView: React.FC = () => {
  const { products, orders, budgets, stores, selectedCountry, countries } = useApp();

  // Auth & Connection State
  const [token, setToken] = useState<string | null>(getCachedAccessToken());
  const [isAuthenticating, setIsAuthenticating] = useState(false);

  // Spreadsheets List State
  const [files, setFiles] = useState<SpreadsheetFile[]>([]);
  const [isLoadingFiles, setIsLoadingFiles] = useState(false);
  const [searchFilter, setSearchFilter] = useState('');

  // Active Spreadsheet State
  const [activeFile, setActiveFile] = useState<SpreadsheetFile | null>(null);
  const [metadata, setMetadata] = useState<SpreadsheetMetadata | null>(null);
  const [activeTabTitle, setActiveTabTitle] = useState<string>('');
  const [sheetRows, setSheetRows] = useState<string[][]>([]);
  const [isLoadingSheet, setIsLoadingSheet] = useState(false);

  // Create / Export Modal State
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [newTitle, setNewTitle] = useState('');
  const [templateType, setTemplateType] = useState<'custom' | 'products' | 'orders' | 'budgets'>('custom');
  const [isCreating, setIsCreating] = useState(false);

  // Add Row Modal State
  const [isAddRowOpen, setIsAddRowOpen] = useState(false);
  const [newRowValues, setNewRowValues] = useState<string[]>([]);
  const [isAppending, setIsAppending] = useState(false);

  // Destructive Action Confirmation Modal
  const [trashConfirmFile, setTrashConfirmFile] = useState<SpreadsheetFile | null>(null);
  const [isTrashing, setIsTrashing] = useState(false);

  // Feedback Toast
  const [toastMessage, setToastMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  const showToast = (type: 'success' | 'error', text: string) => {
    setToastMessage({ type, text });
    setTimeout(() => setToastMessage(null), 4000);
  };

  // Auth listener
  useEffect(() => {
    const unsubscribe = initGoogleAuth(
      (user, accessToken) => {
        setToken(accessToken);
      },
      () => {
        setToken(getCachedAccessToken());
      }
    );
    return () => unsubscribe();
  }, []);

  // Connect Google Workspace
  const handleConnect = async () => {
    setIsAuthenticating(true);
    try {
      const res = await signInWithGoogleWorkspace();
      setToken(res.accessToken);
      showToast('success', 'تم الاتصال بحساب Google Sheets بنجاح!');
    } catch (err: any) {
      console.error('Google Workspace Connect error:', err);
      showToast('error', err.message || 'تعذر الاتصال بـ Google Sheets');
    } finally {
      setIsAuthenticating(false);
    }
  };

  // Load Spreadsheet Files from Drive
  const loadFiles = useCallback(async () => {
    if (!token) return;
    setIsLoadingFiles(true);
    try {
      const list = await listSpreadsheets(token);
      setFiles(list);
    } catch (err: any) {
      console.error('Load sheets error:', err);
      showToast('error', 'تعذر جلب ملفات Google Sheets: ' + (err.message || ''));
    } finally {
      setIsLoadingFiles(false);
    }
  }, [token]);

  useEffect(() => {
    if (token) {
      loadFiles();
    }
  }, [token, loadFiles]);

  // Load Selected Spreadsheet details
  const handleSelectFile = async (file: SpreadsheetFile) => {
    if (!token) return;
    setActiveFile(file);
    setIsLoadingSheet(true);
    try {
      const meta = await getSpreadsheetMetadata(file.id, token);
      setMetadata(meta);
      const firstTab = meta.sheets[0]?.properties.title || 'Sheet1';
      setActiveTabTitle(firstTab);

      // Load first tab values
      const valRes = await getSheetValues(file.id, `'${firstTab}'`, token);
      setSheetRows(valRes.values || []);
    } catch (err: any) {
      console.error('Fetch spreadsheet data error:', err);
      showToast('error', 'فشل قراءة محتوى جدول البيانات.');
    } finally {
      setIsLoadingSheet(false);
    }
  };

  // Switch Tab within active workbook
  const handleSwitchTab = async (tabTitle: string) => {
    if (!token || !activeFile) return;
    setActiveTabTitle(tabTitle);
    setIsLoadingSheet(true);
    try {
      const valRes = await getSheetValues(activeFile.id, `'${tabTitle}'`, token);
      setSheetRows(valRes.values || []);
    } catch (err: any) {
      console.error('Fetch tab data error:', err);
      showToast('error', 'فشل قراءة محتوى هذا التبويب.');
    } finally {
      setIsLoadingSheet(false);
    }
  };

  // Refresh active tab
  const handleRefreshActiveSheet = async () => {
    if (!token || !activeFile || !activeTabTitle) return;
    setIsLoadingSheet(true);
    try {
      const valRes = await getSheetValues(activeFile.id, `'${activeTabTitle}'`, token);
      setSheetRows(valRes.values || []);
      showToast('success', 'تم تحديث بيانات الجدول بنجاح.');
    } catch (err: any) {
      showToast('error', 'فشل التحديث.');
    } finally {
      setIsLoadingSheet(false);
    }
  };

  // Handle Create or Export to Google Sheets
  const handleCreateOrExport = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!token) return;

    let title = newTitle.trim();
    if (!title) {
      if (templateType === 'products') title = 'جرد المنتجات والأسعار - المتجر';
      else if (templateType === 'orders') title = 'سجل ومتابعة الطلبات - المتجر';
      else if (templateType === 'budgets') title = 'الميزانية والمصروفات - المتجر';
      else title = 'جدول بيانات جديد';
    }

    setIsCreating(true);
    try {
      let initialSheets: { title: string; headers?: string[]; rows?: (string | number)[][] }[] = [];

      if (templateType === 'products') {
        const headers = ['المعرف ID', 'اسم المنتج', 'القسم', 'السعر', 'سعر التكلفة', 'الكمية المخزنة', 'التقييم', 'اسم المتجر', 'الدولة'];
        const rows = products.map((p) => [
          p.id,
          p.title,
          p.category,
          p.price,
          p.cost_price || 0,
          p.stock_quantity ?? 10,
          p.rating,
          p.store_name || 'المتجر الرئيسي',
          p.country || selectedCountry
        ]);
        initialSheets = [{ title: 'قائمة المنتجات', headers, rows }];
      } else if (templateType === 'orders') {
        const headers = ['رقم الطلب', 'اسم العميل', 'رقم الهاتف', 'العنوان', 'طريقة الدفع', 'الإجمالي', 'الحالة', 'تاريخ الطلب', 'عدد المنتجات'];
        const rows = orders.map((o) => [
          o.order_number,
          o.customer_name,
          o.customer_phone,
          o.customer_address,
          o.payment_method,
          o.total_amount,
          o.status,
          o.date,
          o.items?.length || 1
        ]);
        initialSheets = [{ title: 'سجل الطلبات', headers, rows }];
      } else if (templateType === 'budgets') {
        const headers = ['اسم القسم', 'الميزانية المخصصة', 'المصروفات الحالية', 'المبلغ المتبقي', 'نسبة الاستهلاك', 'المتجر المستهدف'];
        const rows = budgets.map((b) => {
          const remaining = Math.max(0, b.allocated_amount - b.spent_amount);
          const percent = b.allocated_amount > 0 ? Math.round((b.spent_amount / b.allocated_amount) * 100) : 0;
          return [
            b.category_name,
            b.allocated_amount,
            b.spent_amount,
            remaining,
            `${percent}%`,
            stores.find((s) => s.id === b.store_id)?.name || 'الكل'
          ];
        });
        initialSheets = [{ title: 'ميزانيات الأقسام', headers, rows }];
      } else {
        initialSheets = [
          {
            title: 'البيانات',
            headers: ['الرقم', 'العنصر', 'الوصف', 'المبلغ', 'التاريخ'],
            rows: [
              [1, 'عنصر توضيحي 1', 'وصف تجريبي', 100, new Date().toLocaleDateString('ar-EG')],
              [2, 'عنصر توضيحي 2', 'بيانات مسجلة', 250, new Date().toLocaleDateString('ar-EG')]
            ]
          }
        ];
      }

      const created = await createSpreadsheet(title, initialSheets, token);
      showToast('success', `تم إنشاء جدول "${title}" في Google Sheets بنجاح!`);
      setIsCreateModalOpen(false);
      setNewTitle('');
      setTemplateType('custom');
      await loadFiles();

      // Automatically select and open the newly created spreadsheet
      const newFileObj: SpreadsheetFile = {
        id: created.spreadsheetId,
        name: created.properties.title,
        webViewLink: created.spreadsheetUrl
      };
      handleSelectFile(newFileObj);
    } catch (err: any) {
      console.error('Create sheet error:', err);
      showToast('error', 'فشل إنشاء الجدول: ' + (err.message || ''));
    } finally {
      setIsCreating(false);
    }
  };

  // Append a row to the active sheet
  const handleAppendRow = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!token || !activeFile || !activeTabTitle) return;

    setIsAppending(true);
    try {
      await appendSheetValues(activeFile.id, `'${activeTabTitle}'`, [newRowValues], token);
      showToast('success', 'تمت إضافة الصف إلى Google Sheet بنجاح!');
      setIsAddRowOpen(false);
      setNewRowValues([]);
      // Reload values
      const valRes = await getSheetValues(activeFile.id, `'${activeTabTitle}'`, token);
      setSheetRows(valRes.values || []);
    } catch (err: any) {
      console.error('Append row error:', err);
      showToast('error', 'فشل إضافة الصف: ' + (err.message || ''));
    } finally {
      setIsAppending(false);
    }
  };

  // Confirm delete/trash spreadsheet
  const handleConfirmTrash = async () => {
    if (!token || !trashConfirmFile) return;
    setIsTrashing(true);
    try {
      await deleteSpreadsheet(trashConfirmFile.id, token);
      showToast('success', 'تم نقل جدول البيانات إلى سلة المهملات في Google Drive.');
      setFiles((prev) => prev.filter((f) => f.id !== trashConfirmFile.id));
      if (activeFile && activeFile.id === trashConfirmFile.id) {
        setActiveFile(null);
        setMetadata(null);
        setSheetRows([]);
      }
      setTrashConfirmFile(null);
    } catch (err: any) {
      console.error('Delete sheet error:', err);
      showToast('error', 'فشل الحذف: ' + (err.message || ''));
    } finally {
      setIsTrashing(false);
    }
  };

  const filteredFiles = files.filter((f) =>
    f.name.toLowerCase().includes(searchFilter.trim().toLowerCase())
  );

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Page Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6 pb-6 border-b border-zinc-800">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-[#0F9D58] to-[#0B8043] text-white flex items-center justify-center shadow-lg shadow-[#0F9D58]/20">
            <FileSpreadsheet className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-2xl font-black text-white">Google Sheets</h1>
              <span className="text-[11px] font-bold px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                Google Workspace
              </span>
            </div>
            <p className="text-xs text-zinc-400 mt-0.5">
              إدارة وتصدير وقراءة جداول البيانات وتحليلات المتجر عبر Google Sheets المعتمد
            </p>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center gap-3">
          {token ? (
            <>
              <button
                onClick={() => {
                  setNewTitle('');
                  setTemplateType('custom');
                  setIsCreateModalOpen(true);
                }}
                className="px-4 py-2.5 rounded-2xl bg-[#0F9D58] hover:bg-[#0B8043] text-white text-xs font-bold flex items-center gap-2 transition-all shadow-md shadow-[#0F9D58]/20 active:scale-95"
              >
                <Plus className="w-4 h-4" />
                <span>جدول بيانات جديد</span>
              </button>
            </>
          ) : (
            <button
              onClick={handleConnect}
              disabled={isAuthenticating}
              className="px-4 py-2.5 rounded-2xl bg-white hover:bg-zinc-100 text-black text-xs font-bold flex items-center gap-2 transition-all shadow-md active:scale-95 disabled:opacity-50"
            >
              <svg className="w-4 h-4" viewBox="0 0 24 24">
                <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
                <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
                <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z" />
                <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z" />
              </svg>
              <span>{isAuthenticating ? 'جاري الاتصال...' : 'ربط Google Sheets'}</span>
            </button>
          )}
        </div>
      </div>

      {/* Main Content Area */}
      {!token ? (
        /* Not Connected Card */
        <div className="bg-[#141414] border border-[#242424] rounded-3xl p-8 sm:p-12 text-center max-w-2xl mx-auto shadow-2xl my-8">
          <div className="w-16 h-16 rounded-3xl bg-emerald-500/10 border border-emerald-500/20 text-[#0F9D58] flex items-center justify-center mx-auto mb-5 shadow-inner">
            <FileSpreadsheet className="w-8 h-8" />
          </div>
          <h2 className="text-xl sm:text-2xl font-black text-white mb-2">
            الاتصال بخدمة Google Sheets
          </h2>
          <p className="text-sm text-zinc-400 max-w-md mx-auto mb-6 leading-relaxed">
            قم بالاتصال بحساب Google للوصول إلى جداول البيانات الخاصة بك، استيراد وتصدير بيانات المتجر (المنتجات، الطلبات، الميزانيات) وعرض الخلايا وتحريرها بشكل تفاعلي.
          </p>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-3">
            <button
              onClick={handleConnect}
              disabled={isAuthenticating}
              className="w-full sm:w-auto px-6 py-3.5 rounded-2xl bg-white hover:bg-zinc-100 text-black text-sm font-bold flex items-center justify-center gap-3 transition-all shadow-lg active:scale-95 disabled:opacity-50"
            >
              <svg className="w-5 h-5" viewBox="0 0 24 24">
                <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
                <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
                <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z" />
                <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z" />
              </svg>
              <span>{isAuthenticating ? 'جاري الاتصال...' : 'تسجيل الدخول وربط Google Sheets'}</span>
            </button>
          </div>

          <div className="mt-8 pt-6 border-t border-zinc-800/80 flex items-center justify-center gap-2 text-zinc-500 text-xs">
            <ShieldCheck className="w-4 h-4 text-emerald-500" />
            <span>اتصال رسمي مشفر ومحمي عبر Google OAuth API</span>
          </div>
        </div>
      ) : (
        /* Connected Layout */
        <div className="space-y-6">
          {/* Quick 1-Click Export Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <button
              onClick={() => {
                setTemplateType('products');
                setNewTitle(`جرد المنتجات - ${new Date().toLocaleDateString('ar-EG')}`);
                setIsCreateModalOpen(true);
              }}
              className="p-4 bg-[#141414] hover:bg-[#1A1A1A] border border-zinc-800 hover:border-emerald-500/40 rounded-2xl text-right transition-all group flex items-start justify-between shadow-sm"
            >
              <div>
                <div className="flex items-center gap-2 text-xs font-bold text-white mb-1">
                  <Package className="w-4 h-4 text-emerald-400" />
                  <span>تصدير كتالوج المنتجات</span>
                </div>
                <p className="text-[11px] text-zinc-400">
                  تصدير {products.length} منتج بأسعارها ومخزونها إلى Sheet جديد
                </p>
              </div>
              <FileDown className="w-4 h-4 text-zinc-500 group-hover:text-emerald-400 transition-colors" />
            </button>

            <button
              onClick={() => {
                setTemplateType('orders');
                setNewTitle(`سجل الطلبات - ${new Date().toLocaleDateString('ar-EG')}`);
                setIsCreateModalOpen(true);
              }}
              className="p-4 bg-[#141414] hover:bg-[#1A1A1A] border border-zinc-800 hover:border-emerald-500/40 rounded-2xl text-right transition-all group flex items-start justify-between shadow-sm"
            >
              <div>
                <div className="flex items-center gap-2 text-xs font-bold text-white mb-1">
                  <ShoppingBag className="w-4 h-4 text-blue-400" />
                  <span>تصدير سجل الطلبات</span>
                </div>
                <p className="text-[11px] text-zinc-400">
                  تصدير {orders.length} طلب مع بيانات العملاء والحالات
                </p>
              </div>
              <FileDown className="w-4 h-4 text-zinc-500 group-hover:text-blue-400 transition-colors" />
            </button>

            <button
              onClick={() => {
                setTemplateType('budgets');
                setNewTitle(`تقرير الميزانية - ${new Date().toLocaleDateString('ar-EG')}`);
                setIsCreateModalOpen(true);
              }}
              className="p-4 bg-[#141414] hover:bg-[#1A1A1A] border border-zinc-800 hover:border-emerald-500/40 rounded-2xl text-right transition-all group flex items-start justify-between shadow-sm"
            >
              <div>
                <div className="flex items-center gap-2 text-xs font-bold text-white mb-1">
                  <Wallet className="w-4 h-4 text-amber-400" />
                  <span>تصدير تحليلات الميزانية</span>
                </div>
                <p className="text-[11px] text-zinc-400">
                  تصدير ميزانيات الأقسام والمصروفات ونسب الاستهلاك
                </p>
              </div>
              <FileDown className="w-4 h-4 text-zinc-500 group-hover:text-amber-400 transition-colors" />
            </button>
          </div>

          {/* Grid Layout: Files List on Left / Viewer on Right */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
            {/* Spreadsheets Sidebar */}
            <div className="lg:col-span-4 bg-[#141414] border border-[#242424] rounded-3xl p-4 shadow-xl space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <FileSpreadsheet className="w-4 h-4 text-emerald-400" />
                  <h3 className="text-xs font-bold text-white">ملفات Google Sheets</h3>
                </div>
                <button
                  onClick={loadFiles}
                  disabled={isLoadingFiles}
                  className="p-1.5 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-zinc-400 hover:text-white transition-colors"
                  title="تحديث القائمة"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${isLoadingFiles ? 'animate-spin text-emerald-400' : ''}`} />
                </button>
              </div>

              {/* Search Bar */}
              <div className="relative">
                <input
                  type="text"
                  value={searchFilter}
                  onChange={(e) => setSearchFilter(e.target.value)}
                  placeholder="ابحث عن ملف..."
                  className="w-full bg-[#1A1A1A] border border-zinc-700/70 rounded-xl pl-8 pr-3 py-1.5 text-xs text-white placeholder:text-zinc-500 focus:outline-none focus:border-emerald-500"
                />
                <Search className="w-3.5 h-3.5 text-zinc-500 absolute left-2.5 top-2.5" />
              </div>

              {/* Files List */}
              <div className="space-y-1.5 max-h-[500px] overflow-y-auto divide-y divide-zinc-800/40">
                {isLoadingFiles ? (
                  <div className="py-12 text-center text-zinc-400 text-xs">
                    <RefreshCw className="w-6 h-6 animate-spin text-emerald-500 mx-auto mb-2" />
                    <span>جاري تحميل الجداول من Google Drive...</span>
                  </div>
                ) : filteredFiles.length === 0 ? (
                  <div className="py-12 text-center text-zinc-500 text-xs">
                    <FileSpreadsheet className="w-8 h-8 mx-auto mb-2 opacity-30" />
                    <span>لا توجد جداول بيانات مطابقة</span>
                  </div>
                ) : (
                  filteredFiles.map((f) => {
                    const isSelected = activeFile?.id === f.id;
                    return (
                      <div
                        key={f.id}
                        onClick={() => handleSelectFile(f)}
                        className={`p-3 rounded-2xl cursor-pointer transition-all flex items-center justify-between group ${
                          isSelected
                            ? 'bg-emerald-950/40 border border-emerald-500/40 text-white'
                            : 'hover:bg-[#1C1C1C] text-zinc-300'
                        }`}
                      >
                        <div className="flex items-center gap-2.5 min-w-0">
                          <FileSpreadsheet className={`w-4 h-4 shrink-0 ${isSelected ? 'text-emerald-400' : 'text-zinc-500'}`} />
                          <div className="min-w-0">
                            <p className="text-xs font-bold truncate">{f.name}</p>
                            <p className="text-[10px] text-zinc-500">
                              {f.modifiedTime ? new Date(f.modifiedTime).toLocaleDateString('ar-EG') : 'ملف جدول'}
                            </p>
                          </div>
                        </div>

                        <div className="flex items-center gap-1 opacity-60 group-hover:opacity-100">
                          {f.webViewLink && (
                            <a
                              href={f.webViewLink}
                              target="_blank"
                              rel="noreferrer"
                              onClick={(e) => e.stopPropagation()}
                              className="p-1 rounded-lg hover:bg-zinc-700 text-zinc-400 hover:text-white"
                              title="فتح في Google Sheets"
                            >
                              <ExternalLink className="w-3.5 h-3.5" />
                            </a>
                          )}
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              setTrashConfirmFile(f);
                            }}
                            className="p-1 rounded-lg hover:bg-red-950/60 text-zinc-400 hover:text-red-400"
                            title="حذف"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    );
                  })
                )}
              </div>
            </div>

            {/* Spreadsheet Viewer & Grid */}
            <div className="lg:col-span-8 bg-[#141414] border border-[#242424] rounded-3xl overflow-hidden shadow-xl min-h-[550px] flex flex-col">
              {activeFile && metadata ? (
                <>
                  {/* Workbook Top Bar */}
                  <div className="p-4 bg-[#111] border-b border-zinc-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                    <div className="flex items-center gap-2.5 min-w-0">
                      <div className="w-8 h-8 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center shrink-0">
                        <Table className="w-4 h-4" />
                      </div>
                      <div className="min-w-0">
                        <h2 className="text-sm font-black text-white truncate">{metadata.properties.title}</h2>
                        <span className="text-[10px] text-zinc-500 font-mono">ID: {metadata.spreadsheetId}</span>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 shrink-0">
                      <button
                        onClick={handleRefreshActiveSheet}
                        disabled={isLoadingSheet}
                        className="px-3 py-1.5 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-xs font-bold text-zinc-300 flex items-center gap-1.5"
                        title="تحديث البيانات"
                      >
                        <RefreshCw className={`w-3.5 h-3.5 ${isLoadingSheet ? 'animate-spin text-emerald-400' : ''}`} />
                        <span>تحديث</span>
                      </button>

                      <button
                        onClick={() => {
                          const colCount = (sheetRows[0] || []).length || 4;
                          setNewRowValues(new Array(colCount).fill(''));
                          setIsAddRowOpen(true);
                        }}
                        className="px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold flex items-center gap-1.5 shadow-sm"
                      >
                        <Plus className="w-3.5 h-3.5" />
                        <span>إضافة صف</span>
                      </button>

                      {metadata.spreadsheetUrl && (
                        <a
                          href={metadata.spreadsheetUrl}
                          target="_blank"
                          rel="noreferrer"
                          className="px-3 py-1.5 rounded-xl bg-[#1F1F1F] hover:bg-zinc-800 text-zinc-300 hover:text-white text-xs font-bold flex items-center gap-1.5"
                        >
                          <ExternalLink className="w-3.5 h-3.5 text-emerald-400" />
                          <span>فتح في Sheets</span>
                        </a>
                      )}
                    </div>
                  </div>

                  {/* Tabs Selector Bar (Dynamic sheets, avoiding hardcoding Sheet1) */}
                  <div className="px-4 py-2 bg-[#0E0E0E] border-b border-zinc-800/80 flex items-center gap-2 overflow-x-auto">
                    <span className="text-[10px] font-bold text-zinc-500 shrink-0 flex items-center gap-1">
                      <Layers className="w-3 h-3" />
                      التبويبات:
                    </span>
                    {metadata.sheets.map((sheet) => {
                      const tabName = sheet.properties.title;
                      const isCurrent = activeTabTitle === tabName;
                      return (
                        <button
                          key={sheet.properties.sheetId}
                          onClick={() => handleSwitchTab(tabName)}
                          className={`px-3 py-1 rounded-xl text-xs font-bold transition-all whitespace-nowrap ${
                            isCurrent
                              ? 'bg-emerald-600 text-white shadow-sm'
                              : 'bg-zinc-900 text-zinc-400 hover:text-zinc-200 hover:bg-zinc-800'
                          }`}
                        >
                          {tabName}
                        </button>
                      );
                    })}
                  </div>

                  {/* Interactive Spreadsheet Grid View */}
                  <div className="flex-1 overflow-auto max-h-[500px] p-4">
                    {isLoadingSheet ? (
                      <div className="py-20 text-center text-zinc-400 text-xs">
                        <RefreshCw className="w-8 h-8 animate-spin text-emerald-500 mx-auto mb-2" />
                        <span>جاري قراءة خلايا الجدول...</span>
                      </div>
                    ) : sheetRows.length === 0 ? (
                      <div className="py-20 text-center text-zinc-500 text-xs">
                        <Table className="w-10 h-10 mx-auto mb-2 opacity-20" />
                        <p className="font-bold text-zinc-400">الجدول فارغ</p>
                        <p className="mt-1">يمكنك البدء بإضافة صفوف جديدة عبر زر "إضافة صف" أعلاه.</p>
                      </div>
                    ) : (
                      <div className="border border-zinc-800 rounded-2xl overflow-hidden shadow-inner">
                        <table className="w-full text-right border-collapse text-xs">
                          {/* Column Header (A, B, C...) */}
                          <thead>
                            <tr className="bg-[#1C1C1C] text-zinc-400 border-b border-zinc-800">
                              <th className="p-2 w-10 text-center border-l border-zinc-800 text-[10px] font-mono text-zinc-500 bg-[#161616]">
                                #
                              </th>
                              {sheetRows[0]?.map((_, colIndex) => {
                                const colLetter = String.fromCharCode(65 + (colIndex % 26));
                                return (
                                  <th
                                    key={colIndex}
                                    className="p-2.5 font-bold text-zinc-300 border-l border-zinc-800 last:border-l-0 text-center"
                                  >
                                    {colLetter}
                                  </th>
                                );
                              })}
                            </tr>
                          </thead>
                          <tbody className="divide-y divide-zinc-800/60">
                            {sheetRows.map((row, rowIndex) => {
                              const isHeaderRow = rowIndex === 0;
                              return (
                                <tr
                                  key={rowIndex}
                                  className={`transition-colors ${
                                    isHeaderRow
                                      ? 'bg-[#181818] font-black text-white'
                                      : 'hover:bg-[#1A1A1A] text-zinc-300'
                                  }`}
                                >
                                  {/* Row index */}
                                  <td className="p-2 text-center border-l border-zinc-800 text-[10px] font-mono text-zinc-500 bg-[#141414]">
                                    {rowIndex + 1}
                                  </td>
                                  {/* Cells */}
                                  {row.map((cell, cellIndex) => (
                                    <td
                                      key={cellIndex}
                                      className="p-2.5 border-l border-zinc-800/80 last:border-l-0 truncate max-w-[220px]"
                                      title={String(cell)}
                                    >
                                      {cell !== undefined && cell !== null && cell !== '' ? String(cell) : '-'}
                                    </td>
                                  ))}
                                </tr>
                              );
                            })}
                          </tbody>
                        </table>
                      </div>
                    )}
                  </div>
                </>
              ) : (
                /* No File Selected State */
                <div className="flex-1 flex flex-col items-center justify-center p-12 text-center text-zinc-500">
                  <div className="w-16 h-16 rounded-3xl bg-zinc-800/40 border border-zinc-800 flex items-center justify-center mb-4 text-zinc-600">
                    <FileSpreadsheet className="w-8 h-8" />
                  </div>
                  <h3 className="text-sm font-bold text-zinc-300 mb-1">اختر جدول بيانات لعرضه</h3>
                  <p className="text-xs text-zinc-500 max-w-sm mb-5">
                    اختر ملفاً من القائمة الجانبية أو اضغط على "جدول بيانات جديد" أو استخدم أزرار التصدير السريعة.
                  </p>
                  <button
                    onClick={() => {
                      setNewTitle('');
                      setTemplateType('custom');
                      setIsCreateModalOpen(true);
                    }}
                    className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold flex items-center gap-2 shadow-sm"
                  >
                    <Plus className="w-4 h-4" />
                    <span>إنشاء جدول بيانات الآن</span>
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* CREATE / EXPORT MODAL */}
      {isCreateModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-150">
          <div
            className="w-full max-w-lg bg-[#141414] border border-[#282828] text-white rounded-3xl shadow-2xl p-6 relative overflow-hidden"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between pb-4 border-b border-zinc-800 mb-5">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center">
                  <FileSpreadsheet className="w-4 h-4" />
                </div>
                <h3 className="text-base font-bold text-white">إنشاء / تصدير إلى Google Sheets</h3>
              </div>

              <button
                onClick={() => setIsCreateModalOpen(false)}
                className="p-1.5 rounded-full bg-zinc-800 hover:bg-zinc-700 text-zinc-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateOrExport} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-zinc-400 mb-1.5">
                  عنوان ملف جدول البيانات:
                </label>
                <input
                  type="text"
                  required
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  placeholder="مثال: سجل مبيعات المتجر 2026"
                  className="w-full bg-[#1A1A1A] border border-zinc-700/80 rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-zinc-400 mb-1.5">
                  نموذج البيانات المراد تضمينها:
                </label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setTemplateType('products')}
                    className={`p-3 rounded-2xl border text-right transition-all ${
                      templateType === 'products'
                        ? 'bg-emerald-950/40 border-emerald-500 text-white'
                        : 'bg-[#181818] border-zinc-800 text-zinc-400 hover:bg-zinc-800'
                    }`}
                  >
                    <div className="text-xs font-bold flex items-center gap-1.5 mb-1">
                      <Package className="w-3.5 h-3.5 text-emerald-400" />
                      <span>قائمة المنتجات</span>
                    </div>
                    <span className="text-[10px] text-zinc-500">{products.length} منتج مسجل</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setTemplateType('orders')}
                    className={`p-3 rounded-2xl border text-right transition-all ${
                      templateType === 'orders'
                        ? 'bg-emerald-950/40 border-emerald-500 text-white'
                        : 'bg-[#181818] border-zinc-800 text-zinc-400 hover:bg-zinc-800'
                    }`}
                  >
                    <div className="text-xs font-bold flex items-center gap-1.5 mb-1">
                      <ShoppingBag className="w-3.5 h-3.5 text-blue-400" />
                      <span>سجل الطلبات</span>
                    </div>
                    <span className="text-[10px] text-zinc-500">{orders.length} طلب</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setTemplateType('budgets')}
                    className={`p-3 rounded-2xl border text-right transition-all ${
                      templateType === 'budgets'
                        ? 'bg-emerald-950/40 border-emerald-500 text-white'
                        : 'bg-[#181818] border-zinc-800 text-zinc-400 hover:bg-zinc-800'
                    }`}
                  >
                    <div className="text-xs font-bold flex items-center gap-1.5 mb-1">
                      <Wallet className="w-3.5 h-3.5 text-amber-400" />
                      <span>الميزانية والأقسام</span>
                    </div>
                    <span className="text-[10px] text-zinc-500">{budgets.length} ميزانية</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setTemplateType('custom')}
                    className={`p-3 rounded-2xl border text-right transition-all ${
                      templateType === 'custom'
                        ? 'bg-emerald-950/40 border-emerald-500 text-white'
                        : 'bg-[#181818] border-zinc-800 text-zinc-400 hover:bg-zinc-800'
                    }`}
                  >
                    <div className="text-xs font-bold flex items-center gap-1.5 mb-1">
                      <Table className="w-3.5 h-3.5 text-zinc-400" />
                      <span>جدول مخصص فارغ</span>
                    </div>
                    <span className="text-[10px] text-zinc-500">خلايا وأعمدة قياسية</span>
                  </button>
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-4 border-t border-zinc-800">
                <button
                  type="button"
                  onClick={() => setIsCreateModalOpen(false)}
                  className="px-4 py-2 rounded-xl text-xs font-bold text-zinc-400 hover:text-white"
                >
                  إلغاء
                </button>

                <button
                  type="submit"
                  disabled={isCreating}
                  className="px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold transition-all shadow-md shadow-emerald-600/20 disabled:opacity-50 flex items-center gap-2"
                >
                  <FileSpreadsheet className="w-4 h-4" />
                  <span>{isCreating ? 'جاري الإنشاء في Google Sheets...' : 'إنشاء وحفظ في Drive'}</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ADD ROW MODAL */}
      {isAddRowOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-150">
          <div
            className="w-full max-w-md bg-[#141414] border border-[#282828] text-white rounded-3xl shadow-2xl p-6 relative"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between pb-3 border-b border-zinc-800 mb-4">
              <div className="flex items-center gap-2">
                <Plus className="w-4 h-4 text-emerald-400" />
                <h3 className="text-sm font-bold text-white">إضافة صف إلى "{activeTabTitle}"</h3>
              </div>
              <button
                onClick={() => setIsAddRowOpen(false)}
                className="p-1 rounded-full hover:bg-zinc-800 text-zinc-400"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleAppendRow} className="space-y-3">
              <p className="text-xs text-zinc-400 mb-2">أدخل قيم الأعمدة بالترتيب:</p>
              <div className="space-y-2 max-h-[300px] overflow-y-auto pr-1">
                {newRowValues.map((val, idx) => {
                  const headerName = sheetRows[0]?.[idx] || `العمود ${String.fromCharCode(65 + idx)}`;
                  return (
                    <div key={idx}>
                      <label className="block text-[11px] font-bold text-zinc-400 mb-1">
                        {headerName}:
                      </label>
                      <input
                        type="text"
                        value={val}
                        onChange={(e) => {
                          const updated = [...newRowValues];
                          updated[idx] = e.target.value;
                          setNewRowValues(updated);
                        }}
                        placeholder={`قيمة ${headerName}`}
                        className="w-full bg-[#1A1A1A] border border-zinc-700/80 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-emerald-500"
                      />
                    </div>
                  );
                })}
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-zinc-800">
                <button
                  type="button"
                  onClick={() => setIsAddRowOpen(false)}
                  className="px-3 py-2 rounded-xl text-xs font-bold text-zinc-400 hover:text-white"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  disabled={isAppending}
                  className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold flex items-center gap-1.5 disabled:opacity-50"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>{isAppending ? 'جاري الإضافة...' : 'حفظ وإضافة'}</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* DESTRUCTIVE TRASH ACTION CONFIRMATION MODAL (Required by Workspace Integration Policy) */}
      {trashConfirmFile && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-150">
          <div
            className="w-full max-w-md bg-[#161616] border border-red-900/40 rounded-3xl p-6 shadow-2xl text-center"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="w-12 h-12 rounded-2xl bg-red-500/10 border border-red-500/20 text-red-400 flex items-center justify-center mx-auto mb-4">
              <AlertTriangle className="w-6 h-6" />
            </div>

            <h3 className="text-base font-bold text-white mb-2">
              تأكيد نقل جدول البيانات إلى المهملات
            </h3>

            <p className="text-xs text-zinc-400 mb-6 leading-relaxed">
              هل أنت متأكد من رغبتك في نقل الملف <strong className="text-white">"{trashConfirmFile.name}"</strong> إلى سلة المهملات في Google Drive؟
            </p>

            <div className="flex items-center justify-center gap-3">
              <button
                type="button"
                onClick={() => setTrashConfirmFile(null)}
                className="px-4 py-2.5 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-zinc-300 text-xs font-bold flex-1"
              >
                إلغاء
              </button>

              <button
                type="button"
                onClick={handleConfirmTrash}
                disabled={isTrashing}
                className="px-4 py-2.5 rounded-xl bg-red-600 hover:bg-red-700 text-white text-xs font-bold flex-1 transition-all shadow-md shadow-red-600/20 disabled:opacity-50"
              >
                {isTrashing ? 'جاري الحذف...' : 'تأكيد الحذف'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-6 left-6 z-50 animate-in slide-in-from-bottom-5 fade-in duration-200">
          <div
            className={`px-4 py-3 rounded-2xl border text-xs font-bold flex items-center gap-2.5 shadow-2xl ${
              toastMessage.type === 'success'
                ? 'bg-emerald-950 border-emerald-700 text-emerald-200'
                : 'bg-red-950 border-red-700 text-red-200'
            }`}
          >
            {toastMessage.type === 'success' ? (
              <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0" />
            ) : (
              <AlertTriangle className="w-4 h-4 text-red-400 shrink-0" />
            )}
            <span>{toastMessage.text}</span>
          </div>
        </div>
      )}
    </div>
  );
};
