import React from 'react';
import { useApp } from '../context/AppContext';
import { ProductCard } from './ProductCard';
import { Flame, ArrowLeft } from 'lucide-react';

export const FeaturedProducts: React.FC = () => {
  const { products, selectedBudget, selectedCountry, countries, activeCurrencySymbol, setCurrentView } = useApp();

  const currentCountryObj = countries.find((c) => c.code === selectedCountry);

  // Filter products by selected country (EG, SA, AE, or ALL) and selected budget
  const displayProducts = products
    .filter((p) => {
      if (!p.is_available) return false;
      // Country Filter
      if (selectedCountry && selectedCountry !== 'ALL') {
        const pCountry = p.country_code || 'EG';
        if (pCountry !== selectedCountry) return false;
      }
      if (selectedBudget !== null) return p.budget === selectedBudget;
      return true;
    })
    .slice(0, 18);

  return (
    <section id="featured-products" className="py-6 sm:py-12 max-w-7xl mx-auto px-2.5 sm:px-6 lg:px-8">
      {/* Section Header matching Screenshot 1 */}
      <div className="flex items-center justify-between mb-4 sm:mb-8">
        <div className="flex items-center gap-2">
          <div className="p-1.5 sm:p-2 rounded-xl bg-[#E50914]/15 text-[#FF3344]">
            <Flame className="w-4 h-4 sm:w-5 sm:h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <h2 className="text-lg sm:text-2xl font-black text-white">
                {selectedBudget
                  ? `منتجات ميزانية ${selectedBudget} ${activeCurrencySymbol}`
                  : `الأكثر طلباً 🔥`}
              </h2>
              {selectedCountry !== 'ALL' && currentCountryObj && (
                <span className="text-[10px] sm:text-xs bg-[#E50914]/20 border border-[#E50914]/40 text-[#FF3344] font-bold px-2 py-0.5 rounded-full flex items-center gap-1">
                  <span>{currentCountryObj.flag_emoji}</span>
                  <span>{currentCountryObj.name_ar}</span>
                </span>
              )}
            </div>
            <p className="text-[11px] sm:text-xs text-zinc-400 mt-0.5">
              {selectedCountry === 'ALL'
                ? 'عرض أفضل الاختيارات من جميع الدول المتاحة'
                : `أفضل الاختيارات الموثوقة المتاحة للشحن داخل ${currentCountryObj?.name_ar || 'بلدك'}`}
            </p>
          </div>
        </div>

        <button
          onClick={() => setCurrentView('products')}
          className="text-[11px] sm:text-sm font-bold text-[#FF3344] hover:text-[#FF6677] flex items-center gap-1 transition-colors group shrink-0"
        >
          <span>عرض كل المنتجات</span>
          <ArrowLeft className="w-3.5 h-3.5 sm:w-4 sm:h-4 group-hover:-translate-x-1 transition-transform" />
        </button>
      </div>

      {/* Products Grid with multi-column layout */}
      {displayProducts.length === 0 ? (
        <div className="text-center py-16 bg-[#161616] rounded-3xl border border-[#2A2A2A]">
          <p className="text-sm text-zinc-400">لا توجد منتجات متوفرة لهذه الميزانية حالياً</p>
        </div>
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 2xl:grid-cols-7 gap-2 sm:gap-3.5">
          {displayProducts.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      )}
    </section>
  );
};
