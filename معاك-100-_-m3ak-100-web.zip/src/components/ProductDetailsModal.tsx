import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { X, Heart, Store, Shield, Check, Copy, ShoppingBag, ExternalLink, Tag, Globe } from 'lucide-react';
import { getCountryDetails } from '../utils/country';

export const ProductDetailsModal: React.FC = () => {
  const {
    activeProductModal,
    setActiveProductModal,
    setActiveOrderModal,
    favorites,
    toggleFavorite,
    activeCurrency,
    orderFee
  } = useApp();

  const [copiedCoupon, setCopiedCoupon] = useState(false);

  if (!activeProductModal) return null;

  const product = activeProductModal;
  const isFav = favorites.includes(product.id);
  const country = getCountryDetails(product.country_code);

  const handleCopyCoupon = () => {
    if (product.coupon_code) {
      navigator.clipboard.writeText(product.coupon_code);
      setCopiedCoupon(true);
      setTimeout(() => setCopiedCoupon(false), 2500);
    }
  };

  const handleStartOrder = () => {
    setActiveProductModal(null);
    setActiveOrderModal({ product, step: 'confirm' });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div
        className="relative w-full max-w-2xl bg-[#161616] border border-[#2A2A2A] rounded-3xl overflow-hidden shadow-2xl max-h-[90vh] flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Modal Header */}
        <div className="flex items-center justify-between p-4 sm:p-5 border-b border-[#2A2A2A]">
          <div className="flex items-center gap-2 flex-wrap">
            {/* Country Flag Badge */}
            <span
              className="px-3 py-1 rounded-xl bg-black/80 border border-white/20 text-white text-xs font-black flex items-center gap-1.5 shadow-sm"
              title={`دولة النشر: ${country.fullName}`}
            >
              <span className="text-base leading-none">{country.flag}</span>
              <span>{country.name}</span>
            </span>

            <span className="px-2.5 py-1 rounded-xl bg-[#E50914]/20 text-[#FF3344] text-xs font-bold">
              ميزانية {product.budget} {country.currencySymbol}
            </span>

            {product.is_featured && (
              <span className="px-2.5 py-1 rounded-xl bg-[#FFD700] text-black text-xs font-black">
                ⭐ منتج مميز
              </span>
            )}
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => toggleFavorite(product.id)}
              className={`p-2 rounded-full border transition-colors ${
                isFav
                  ? 'bg-[#E50914] text-white border-[#E50914]'
                  : 'bg-[#222222] text-zinc-400 border-[#333333] hover:text-white'
              }`}
              title="المفضلة"
            >
              <Heart className={`w-4 h-4 ${isFav ? 'fill-current' : ''}`} />
            </button>
            <button
              onClick={() => setActiveProductModal(null)}
              className="p-2 rounded-full bg-[#222222] text-zinc-400 hover:text-white border border-[#333333] transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Modal Body */}
        <div className="p-4 sm:p-6 overflow-y-auto space-y-6">
          {/* Main Image with Country Overlay */}
          <div className="relative aspect-video w-full rounded-2xl overflow-hidden bg-black border border-zinc-800">
            <img
              src={product.image_url}
              alt={product.name}
              className="w-full h-full object-cover"
              referrerPolicy="no-referrer"
            />
            {/* Country Floating Badge on Image */}
            <div className="absolute top-3 right-3 bg-black/85 backdrop-blur-md px-3 py-1 rounded-xl border border-white/20 text-white text-xs font-black flex items-center gap-1.5 shadow-lg">
              <span className="text-base">{country.flag}</span>
              <span>متاح في {country.fullName}</span>
            </div>
          </div>

          {/* Product Name & Store / Country Info */}
          <div>
            <div className="flex items-center gap-2 text-xs text-zinc-400 mb-2 flex-wrap">
              <span className="px-2 py-0.5 rounded-md bg-zinc-800 text-white font-bold flex items-center gap-1 border border-zinc-700">
                <span>{country.flag}</span>
                <span>{country.name}</span>
              </span>
              <span>•</span>
              <Store className="w-4 h-4 text-[#FF3344]" />
              <span className="font-semibold text-zinc-300">{product.store_name}</span>
              <span>•</span>
              <span>رابط أصلي معتمد</span>
            </div>
            <h2 className="text-xl sm:text-2xl font-black text-white leading-tight">
              {product.name}
            </h2>
          </div>

          {/* Pricing & Fee Breakdown Card */}
          <div className="p-4 rounded-2xl bg-[#0B0B0B] border border-[#2A2A2A] space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-sm text-zinc-400">سعر المنتج في المتجر الأصلي ({country.name}):</span>
              <span className="text-xl font-black text-white flex items-center gap-1">
                <span>{product.price.toLocaleString('ar-EG')}</span>
                <span className="text-sm text-[#FF3344] font-bold">{country.currencySymbol}</span>
              </span>
            </div>

            <div className="flex items-center justify-between pt-2 border-t border-zinc-800">
              <span className="text-xs text-zinc-400 flex items-center gap-1">
                <span>رسوم خدمة تأمين وتفعيل الرابط:</span>
              </span>
              <span className="text-sm font-bold text-[#FF3344]">
                {orderFee} {activeCurrency} (مرة واحدة)
              </span>
            </div>

            <p className="text-[11px] text-zinc-500 pt-1">
              * سعر المنتج نفسه يتم سداده للمتجر الأصلي في {country.name} عند الشراء هناك. رسوم المنصة الرمزية ({orderFee} {activeCurrency}) تُسدد لتأمين كود الخصم ورابط الأفلييت المباشر.
            </p>
          </div>

          {/* Coupon Section if available */}
          {product.coupon_code && (
            <div className="p-4 rounded-2xl bg-emerald-950/30 border border-emerald-500/40 flex items-center justify-between gap-4">
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-xl bg-emerald-500/20 text-emerald-400">
                  <Tag className="w-5 h-5" />
                </div>
                <div>
                  <p className="text-xs text-emerald-300 font-bold">كوبون خصم إضافي متاح!</p>
                  <p className="text-lg font-black text-white tracking-widest">{product.coupon_code}</p>
                </div>
              </div>

              <button
                onClick={handleCopyCoupon}
                className="px-4 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-black text-xs font-black flex items-center gap-1.5 transition-colors"
              >
                {copiedCoupon ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                <span>{copiedCoupon ? 'تم النسخ!' : 'نسخ الكوبون'}</span>
              </button>
            </div>
          )}

          {/* Description */}
          <div className="space-y-2">
            <h4 className="text-sm font-bold text-white">وصف ومواصفات المنتج:</h4>
            <p className="text-sm text-zinc-300 leading-relaxed bg-[#0B0B0B]/50 p-4 rounded-2xl border border-zinc-800/80">
              {product.description}
            </p>
          </div>

          {/* Guarantee / Transparency Notice */}
          <div className="flex items-start gap-3 p-3.5 rounded-xl bg-zinc-900/60 border border-zinc-800 text-xs text-zinc-400">
            <Shield className="w-5 h-5 text-[#FF3344] shrink-0 mt-0.5" />
            <p className="leading-snug">
              تضمن منصة <strong>معاك 100</strong> توجيهك للمتجر الأصلي الموثوق في <strong>{country.fullName}</strong> بدون أي تلاعب بالأسعار أو تكاليف خفية.
            </p>
          </div>
        </div>

        {/* Modal Footer CTA */}
        <div className="p-4 sm:p-5 border-t border-[#2A2A2A] bg-[#0E0E0E] flex items-center gap-3">
          <button
            onClick={handleStartOrder}
            className="flex-1 py-3.5 rounded-2xl bg-[#E50914] hover:bg-[#FF3344] text-white font-bold text-sm transition-all transform active:scale-98 shadow-lg shadow-[#E50914]/25 flex items-center justify-center gap-2"
          >
            <ShoppingBag className="w-4 h-4" />
            <span>طلب المنتج وتفعيل الرابط ({orderFee} {activeCurrency})</span>
          </button>
        </div>
      </div>
    </div>
  );
};
