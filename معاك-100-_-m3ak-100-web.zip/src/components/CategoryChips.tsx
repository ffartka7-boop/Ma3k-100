import React from 'react';
import { useApp } from '../context/AppContext';

export const CategoryChips: React.FC = () => {
  const { categories, selectedCategory, setSelectedCategory, products, selectedCountry } = useApp();

  const countryFilteredProducts = products.filter(
    (p) => p.is_available && (selectedCountry === 'ALL' || (p.country_code || 'EG') === selectedCountry)
  );

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mb-6">
      <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none">
        <button
          onClick={() => setSelectedCategory(null)}
          className={`px-4 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-all flex items-center gap-1.5 ${
            selectedCategory === null
              ? 'bg-[#E50914] text-white shadow-md shadow-[#E50914]/20'
              : 'bg-[#161616] text-zinc-400 hover:text-white hover:bg-[#202020] border border-[#2A2A2A]'
          }`}
        >
          <span>🏷️</span>
          <span>جميع التصنيفات ({countryFilteredProducts.length})</span>
        </button>

        {categories.filter(c => c.is_active && c.id !== 'all').map((cat) => {
          const isSelected = selectedCategory === cat.id;
          const count = countryFilteredProducts.filter(p => p.category_id === cat.id).length;

          return (
            <button
              key={cat.id}
              onClick={() => setSelectedCategory(isSelected ? null : cat.id)}
              className={`px-3.5 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-all flex items-center gap-1.5 ${
                isSelected
                  ? 'bg-[#E50914] text-white shadow-md shadow-[#E50914]/20'
                  : 'bg-[#161616] text-zinc-400 hover:text-white hover:bg-[#202020] border border-[#2A2A2A]'
              }`}
            >
              <span>{cat.icon}</span>
              <span>{cat.name}</span>
              {count > 0 && (
                <span className={`text-[10px] px-1.5 py-0.2 rounded-full ${isSelected ? 'bg-black/30 text-white' : 'bg-zinc-800 text-zinc-400'}`}>
                  {count}
                </span>
              )}
            </button>
          );
        })}
      </div>
    </div>
  );
};
