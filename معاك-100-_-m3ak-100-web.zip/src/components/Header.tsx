import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import {
  Search,
  Heart,
  ShoppingBag,
  User,
  ShieldCheck,
  MessageCircle,
  Menu,
  X,
  Globe,
  LogOut,
  ChevronDown,
  Sparkles,
  Mail,
  FileSpreadsheet,
  Smartphone,
  Download
} from 'lucide-react';

export const Header: React.FC = () => {
  const {
    currentView,
    setCurrentView,
    searchQuery,
    setSearchQuery,
    favorites,
    orders,
    currentUser,
    isAdmin,
    setIsAuthModalOpen,
    setIsChatModalOpen,
    isDownloadModalOpen,
    setIsDownloadModalOpen,
    latestActiveAppUpdate,
    selectedCountry,
    setSelectedCountry,
    activeCountries,
    countries,
    logout
  } = useApp();

  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [userDropdownOpen, setUserDropdownOpen] = useState(false);
  const [countryDropdownOpen, setCountryDropdownOpen] = useState(false);

  const activeOrdersCount = orders.filter(o => o.payment_status === 'PENDING_PAYMENT' || o.payment_status === 'PAYMENT_REVIEW').length;

  const currentCountryObj = countries.find(c => c.code === selectedCountry) || activeCountries[0] || { name_ar: 'مصر', flag_emoji: '🇪🇬' };

  return (
    <header className="sticky top-0 z-40 w-full bg-[#0B0B0B]/95 backdrop-blur-md border-b border-[#222222]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20 gap-4">
          
          {/* Brand Logo matching Screenshots */}
          <div
            onClick={() => setCurrentView('home')}
            className="flex items-center gap-3 cursor-pointer group select-none shrink-0"
          >
            <div className="w-11 h-11 rounded-2xl bg-gradient-to-br from-[#FF3344] via-[#E50914] to-[#B8000A] p-[2px] shadow-lg shadow-[#E50914]/20 group-hover:scale-105 transition-transform flex items-center justify-center">
              <div className="w-full h-full bg-[#0B0B0B]/40 rounded-2xl flex flex-col items-center justify-center">
                <span className="text-white font-black text-sm leading-none">100</span>
                <span className="text-[#FFD700] text-[8px] font-bold">ج.م</span>
              </div>
            </div>
            <div className="flex flex-col">
              <span className="text-white font-black text-lg tracking-tight flex items-center gap-1">
                معاك <span className="text-[#E50914]">100</span>
              </span>
              <span className="text-[#FF3344] text-[10px] font-bold tracking-widest uppercase">
                M3AK 100
              </span>
            </div>
          </div>

          {/* Navigation Links - Desktop */}
          <nav className="hidden lg:flex items-center gap-1 xl:gap-2">
            <button
              onClick={() => setCurrentView('home')}
              className={`px-3 py-2 rounded-xl text-sm font-bold transition-colors ${
                currentView === 'home'
                  ? 'text-[#E50914] bg-[#E50914]/10'
                  : 'text-zinc-300 hover:text-white hover:bg-zinc-900/60'
              }`}
            >
              الرئيسية
            </button>
            <button
              onClick={() => setCurrentView('products')}
              className={`px-3 py-2 rounded-xl text-sm font-bold transition-colors ${
                currentView === 'products'
                  ? 'text-[#E50914] bg-[#E50914]/10'
                  : 'text-zinc-300 hover:text-white hover:bg-zinc-900/60'
              }`}
            >
              كل المنتجات
            </button>
            <button
              onClick={() => setCurrentView('favorites')}
              className={`px-3 py-2 rounded-xl text-sm font-bold transition-colors relative flex items-center gap-1.5 ${
                currentView === 'favorites'
                  ? 'text-[#E50914] bg-[#E50914]/10'
                  : 'text-zinc-300 hover:text-white hover:bg-zinc-900/60'
              }`}
            >
              <Heart className="w-4 h-4" />
              <span>المفضلة</span>
              {favorites.length > 0 && (
                <span className="bg-[#E50914] text-white text-[10px] font-bold px-1.5 py-0.5 rounded-full">
                  {favorites.length}
                </span>
              )}
            </button>
            <button
              onClick={() => setCurrentView('orders')}
              className={`px-3 py-2 rounded-xl text-sm font-bold transition-colors relative flex items-center gap-1.5 ${
                currentView === 'orders'
                  ? 'text-[#E50914] bg-[#E50914]/10'
                  : 'text-zinc-300 hover:text-white hover:bg-zinc-900/60'
              }`}
            >
              <ShoppingBag className="w-4 h-4" />
              <span>طلباتي</span>
              {activeOrdersCount > 0 && (
                <span className="bg-[#FF9800] text-black text-[10px] font-black px-1.5 py-0.5 rounded-full animate-pulse">
                  {activeOrdersCount}
                </span>
              )}
            </button>
            <button
              onClick={() => setCurrentView('about')}
              className={`px-3 py-2 rounded-xl text-sm font-bold transition-colors ${
                currentView === 'about'
                  ? 'text-[#E50914] bg-[#E50914]/10'
                  : 'text-zinc-300 hover:text-white hover:bg-zinc-900/60'
              }`}
            >
              من نحن
            </button>

            <button
              onClick={() => setCurrentView('gmail')}
              className={`px-3 py-2 rounded-xl text-sm font-bold transition-colors flex items-center gap-1.5 ${
                currentView === 'gmail'
                  ? 'text-[#EA4335] bg-[#EA4335]/15 border border-[#EA4335]/30'
                  : 'text-zinc-300 hover:text-white hover:bg-zinc-900/60'
              }`}
            >
              <Mail className="w-4 h-4 text-red-500" />
              <span>Gmail</span>
            </button>

            <button
              onClick={() => setCurrentView('sheets')}
              className={`px-3 py-2 rounded-xl text-sm font-bold transition-colors flex items-center gap-1.5 ${
                currentView === 'sheets'
                  ? 'text-emerald-400 bg-emerald-500/15 border border-emerald-500/30'
                  : 'text-zinc-300 hover:text-white hover:bg-zinc-900/60'
              }`}
            >
              <FileSpreadsheet className="w-4 h-4 text-emerald-400" />
              <span>Sheets</span>
            </button>

            {isAdmin && (
              <button
                onClick={() => setCurrentView('admin')}
                className={`px-3 py-2 rounded-xl text-sm font-bold transition-colors flex items-center gap-1.5 ${
                  currentView === 'admin'
                    ? 'text-emerald-400 bg-emerald-500/15 border border-emerald-500/30'
                    : 'text-emerald-400 hover:bg-emerald-500/10'
                }`}
              >
                <ShieldCheck className="w-4 h-4" />
                <span>لوحة الإدارة</span>
              </button>
            )}
          </nav>

          {/* Search Input matching Screenshot 1 */}
          <div className="hidden md:flex flex-1 max-w-xs xl:max-w-sm relative">
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => {
                setSearchQuery(e.target.value);
                if (currentView !== 'products' && e.target.value.trim().length > 0) {
                  setCurrentView('products');
                }
              }}
              placeholder="ابحث عن منتج..."
              className="w-full bg-[#161616] text-white text-sm rounded-full pl-10 pr-4 py-2 border border-[#2A2A2A] focus:outline-none focus:border-[#E50914] transition-colors placeholder:text-zinc-500"
            />
            <Search className="w-4 h-4 text-zinc-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
          </div>

          {/* Actions: Country, Chat, Auth */}
          <div className="flex items-center gap-2">
            
            {/* Country Selector */}
            <div className="relative">
              <button
                onClick={() => setCountryDropdownOpen(!countryDropdownOpen)}
                className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-full bg-[#161616] border border-[#2A2A2A] hover:border-[#E50914]/50 text-xs text-white font-medium transition-colors"
                title="تغيير الدولة والعملة"
              >
                <span className="text-base leading-none">
                  {currentCountryObj.flag_emoji || '🇪🇬'}
                </span>
                <span className="hidden sm:inline">
                  {currentCountryObj.name_ar || 'مصر'}
                </span>
                <ChevronDown className="w-3 h-3 text-zinc-400" />
              </button>

              {countryDropdownOpen && (
                <div
                  className="absolute left-0 mt-2 w-52 max-h-80 overflow-y-auto bg-[#161616] border border-[#2A2A2A] rounded-2xl shadow-2xl p-1.5 z-50 animate-in fade-in zoom-in-95 duration-100 custom-scrollbar"
                  onClick={() => setCountryDropdownOpen(false)}
                >
                  <div className="text-[10px] text-zinc-500 px-3 py-1 font-semibold border-b border-zinc-800 mb-1">
                    اختر الدولة والعملة:
                  </div>
                  {activeCountries.map((c) => (
                    <button
                      key={c.code}
                      onClick={() => setSelectedCountry(c.code)}
                      className={`w-full flex items-center justify-between px-3 py-2 text-xs rounded-xl transition-colors ${
                        selectedCountry === c.code
                          ? 'bg-[#E50914] text-white font-bold'
                          : 'text-zinc-300 hover:bg-zinc-800'
                      }`}
                    >
                      <span className="flex items-center gap-2">
                        <span className="text-base">{c.flag_emoji}</span>
                        <span>{c.name_ar}</span>
                      </span>
                      <span className="text-[10px] opacity-80">{c.currency_symbol}</span>
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Download Android App Button (Desktop) */}
            <button
              onClick={() => setIsDownloadModalOpen(true)}
              className="hidden sm:flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-gradient-to-r from-emerald-950/80 via-zinc-900 to-[#161616] border border-emerald-500/40 hover:border-emerald-400 text-xs text-white font-bold transition-all shadow-sm hover:shadow-emerald-500/20 group"
              title="تحميل تطبيق الأندرويد (APK)"
            >
              <div className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              <Smartphone className="w-3.5 h-3.5 text-emerald-400 group-hover:scale-110 transition-transform" />
              <span>تحميل التطبيق</span>
              {latestActiveAppUpdate && (
                <span className="text-[10px] text-emerald-300 font-mono bg-emerald-500/20 px-1.5 py-0.5 rounded-md border border-emerald-500/30">
                  v{latestActiveAppUpdate.version_name}
                </span>
              )}
            </button>

            {/* Support Chat Bubble Button */}
            <button
              onClick={() => setIsChatModalOpen(true)}
              className="p-2 rounded-full bg-[#161616] border border-[#2A2A2A] text-zinc-300 hover:text-white hover:border-[#E50914]/50 hover:bg-[#E50914]/10 transition-colors relative"
              title="محادثة الدعم الفني المباشر"
            >
              <MessageCircle className="w-4 h-4" />
            </button>

            {/* User Login/Account Button */}
            {currentUser ? (
              <div className="relative">
                <button
                  onClick={() => setUserDropdownOpen(!userDropdownOpen)}
                  className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-[#161616] border border-[#2A2A2A] hover:border-zinc-700 text-xs text-white font-semibold transition-colors"
                >
                  <div className={`w-5 h-5 rounded-full ${currentUser.role === 'guest' ? 'bg-zinc-700 text-zinc-300' : 'bg-[#E50914] text-white'} flex items-center justify-center text-[10px] font-bold`}>
                    {currentUser.role === 'guest' ? <User className="w-3 h-3" /> : (currentUser.name.charAt(0) || 'م')}
                  </div>
                  <span className="hidden md:inline max-w-[110px] truncate">
                    {currentUser.name}
                  </span>
                  <ChevronDown className="w-3 h-3 text-zinc-400" />
                </button>

                {userDropdownOpen && (
                  <div
                    className="absolute left-0 mt-2 w-52 bg-[#161616] border border-[#2A2A2A] rounded-2xl shadow-2xl p-2 z-50 animate-in fade-in zoom-in-95 duration-150"
                    onClick={() => setUserDropdownOpen(false)}
                  >
                    <div className="px-3 py-2 border-b border-zinc-800 mb-1">
                      <p className="text-xs text-white font-bold truncate">{currentUser.name}</p>
                      <div className="flex items-center justify-between gap-1 mt-0.5">
                        <span className="text-[10px] text-zinc-400 font-mono dir-ltr">
                          ID: {currentUser.id}
                        </span>
                        {currentUser.role === 'guest' && (
                          <span className="text-[9px] bg-zinc-800 text-zinc-400 px-1.5 py-0.5 rounded font-medium">
                            زائر
                          </span>
                        )}
                      </div>
                      {isAdmin && (
                        <span className="inline-block mt-1 bg-emerald-500/20 text-emerald-400 text-[9px] font-bold px-1.5 py-0.5 rounded">
                          مدير المنصة 👑
                        </span>
                      )}
                    </div>

                    {currentUser.role === 'guest' && (
                      <button
                        onClick={() => setIsAuthModalOpen(true)}
                        className="w-full flex items-center gap-2 px-3 py-2 text-xs text-[#E50914] hover:bg-[#E50914]/10 rounded-xl transition-colors font-bold text-right"
                      >
                        <Sparkles className="w-4 h-4" />
                        <span>تسجيل بحساب Google</span>
                      </button>
                    )}

                    {isAdmin && (
                      <button
                        onClick={() => setCurrentView('admin')}
                        className="w-full flex items-center gap-2 px-3 py-2 text-xs text-emerald-400 hover:bg-emerald-500/10 rounded-xl transition-colors font-medium text-right"
                      >
                        <ShieldCheck className="w-4 h-4" />
                        <span>لوحة تحكم الإدارة</span>
                      </button>
                    )}
                    <button
                      onClick={() => setCurrentView('orders')}
                      className="w-full flex items-center gap-2 px-3 py-2 text-xs text-zinc-300 hover:bg-zinc-800 rounded-xl transition-colors font-medium text-right"
                    >
                      <ShoppingBag className="w-4 h-4" />
                      <span>سجل طلباتي</span>
                    </button>
                    <button
                      onClick={() => setCurrentView('favorites')}
                      className="w-full flex items-center gap-2 px-3 py-2 text-xs text-zinc-300 hover:bg-zinc-800 rounded-xl transition-colors font-medium text-right"
                    >
                      <Heart className="w-4 h-4" />
                      <span>المفضلة</span>
                    </button>
                    <button
                      onClick={() => logout()}
                      className="w-full flex items-center gap-2 px-3 py-2 text-xs text-[#FF3344] hover:bg-[#E50914]/10 rounded-xl transition-colors font-medium text-right mt-1 border-t border-zinc-800"
                    >
                      <LogOut className="w-4 h-4" />
                      <span>تسجيل الخروج</span>
                    </button>
                  </div>
                )}
              </div>
            ) : (
              <button
                onClick={() => setIsAuthModalOpen(true)}
                className="flex items-center gap-1.5 px-3.5 py-2 rounded-full bg-[#161616] hover:bg-[#E50914] text-white border border-[#2A2A2A] hover:border-[#E50914] text-xs font-bold transition-all shadow-sm"
              >
                <User className="w-3.5 h-3.5" />
                <span>تسجيل الدخول</span>
              </button>
            )}

            {/* Mobile Hamburger Menu */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="lg:hidden p-2 rounded-full bg-[#161616] border border-[#2A2A2A] text-zinc-300 hover:text-white"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="lg:hidden bg-[#0B0B0B] border-b border-[#222222] px-4 pt-2 pb-6 space-y-3">
          <div className="relative mb-3">
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => {
                setSearchQuery(e.target.value);
                if (currentView !== 'products') setCurrentView('products');
              }}
              placeholder="ابحث عن منتج..."
              className="w-full bg-[#161616] text-white text-sm rounded-full pl-10 pr-4 py-2.5 border border-[#2A2A2A]"
            />
            <Search className="w-4 h-4 text-zinc-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
          </div>

          {/* Mobile Country Selector */}
          <div className="bg-[#161616] p-2.5 rounded-2xl border border-[#2A2A2A] mb-2">
            <span className="text-[11px] text-zinc-400 font-bold block mb-2 text-right">الدولة المحددة:</span>
            <div className="grid grid-cols-3 sm:grid-cols-4 gap-1.5 max-h-36 overflow-y-auto custom-scrollbar">
              {activeCountries.map((c) => (
                <button
                  key={c.code}
                  onClick={() => {
                    setSelectedCountry(c.code);
                  }}
                  className={`py-1.5 px-2 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1 ${
                    selectedCountry === c.code
                      ? 'bg-[#E50914] text-white shadow'
                      : 'bg-zinc-800/80 text-zinc-300'
                  }`}
                >
                  <span className="text-base">{c.flag_emoji}</span>
                  <span className="truncate">{c.name_ar}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Mobile Download APK Card */}
          <div className="p-3.5 bg-gradient-to-r from-emerald-950/70 via-zinc-900 to-zinc-900 border border-emerald-500/40 rounded-2xl flex items-center justify-between gap-3 shadow-lg">
            <div className="flex items-center gap-2.5">
              <div className="w-10 h-10 rounded-xl bg-emerald-500/20 border border-emerald-500/30 flex items-center justify-center text-emerald-400 shrink-0 shadow-inner">
                <Smartphone className="w-5 h-5" />
              </div>
              <div className="text-right">
                <div className="flex items-center gap-1.5">
                  <span className="text-xs font-black text-white">تطبيق معاك 100</span>
                  <span className="text-[9px] bg-emerald-500/30 text-emerald-300 px-1.5 py-0.5 rounded font-mono font-bold">
                    APK {latestActiveAppUpdate ? `v${latestActiveAppUpdate.version_name}` : ''}
                  </span>
                </div>
                <p className="text-[10px] text-zinc-400 mt-0.5">تصفح سريع وإشعارات بالطلبات</p>
              </div>
            </div>
            <button
              onClick={() => {
                setMobileMenuOpen(false);
                setIsDownloadModalOpen(true);
              }}
              className="px-3.5 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-white font-black text-xs transition-all flex items-center gap-1.5 shadow-md shadow-emerald-500/30 shrink-0 active:scale-95"
            >
              <Download className="w-3.5 h-3.5" />
              <span>تحميل</span>
            </button>
          </div>

          <div className="grid grid-cols-2 gap-2">
            <button
              onClick={() => { setCurrentView('home'); setMobileMenuOpen(false); }}
              className={`p-3 rounded-xl text-sm font-bold text-center ${currentView === 'home' ? 'bg-[#E50914] text-white' : 'bg-[#161616] text-zinc-300'}`}
            >
              الرئيسية
            </button>
            <button
              onClick={() => { setCurrentView('products'); setMobileMenuOpen(false); }}
              className={`p-3 rounded-xl text-sm font-bold text-center ${currentView === 'products' ? 'bg-[#E50914] text-white' : 'bg-[#161616] text-zinc-300'}`}
            >
              كل المنتجات
            </button>
            <button
              onClick={() => { setCurrentView('favorites'); setMobileMenuOpen(false); }}
              className={`p-3 rounded-xl text-sm font-bold text-center flex items-center justify-center gap-2 ${currentView === 'favorites' ? 'bg-[#E50914] text-white' : 'bg-[#161616] text-zinc-300'}`}
            >
              <Heart className="w-4 h-4" />
              <span>المفضلة ({favorites.length})</span>
            </button>
            <button
              onClick={() => { setCurrentView('orders'); setMobileMenuOpen(false); }}
              className={`p-3 rounded-xl text-sm font-bold text-center flex items-center justify-center gap-2 ${currentView === 'orders' ? 'bg-[#E50914] text-white' : 'bg-[#161616] text-zinc-300'}`}
            >
              <ShoppingBag className="w-4 h-4" />
              <span>طلباتي ({orders.length})</span>
            </button>
            <button
              onClick={() => { setCurrentView('about'); setMobileMenuOpen(false); }}
              className={`p-3 rounded-xl text-sm font-bold text-center ${currentView === 'about' ? 'bg-[#E50914] text-white' : 'bg-[#161616] text-zinc-300'}`}
            >
              من نحن ورسالتنا
            </button>
            <button
              onClick={() => { setCurrentView('gmail'); setMobileMenuOpen(false); }}
              className={`p-3 rounded-xl text-sm font-bold text-center flex items-center justify-center gap-2 ${currentView === 'gmail' ? 'bg-[#EA4335] text-white' : 'bg-[#161616] text-zinc-300'}`}
            >
              <Mail className="w-4 h-4 text-red-400" />
              <span>بريد Gmail</span>
            </button>
            <button
              onClick={() => { setCurrentView('sheets'); setMobileMenuOpen(false); }}
              className={`p-3 rounded-xl text-sm font-bold text-center flex items-center justify-center gap-2 ${currentView === 'sheets' ? 'bg-[#0F9D58] text-white' : 'bg-[#161616] text-zinc-300'}`}
            >
              <FileSpreadsheet className="w-4 h-4 text-emerald-400" />
              <span>جداول Sheets</span>
            </button>
            {isAdmin && (
              <button
                onClick={() => { setCurrentView('admin'); setMobileMenuOpen(false); }}
                className="p-3 rounded-xl text-sm font-bold text-center col-span-2 bg-emerald-600/20 text-emerald-400 border border-emerald-500/30 flex items-center justify-center gap-2"
              >
                <ShieldCheck className="w-4 h-4" />
                <span>لوحة الإدارة والمدفوعات 👑</span>
              </button>
            )}
          </div>
        </div>
      )}
    </header>
  );
};
