import React from 'react';
import type { Product } from '../types';
import { useApp } from '../context/AppContext';
import { Heart, ShoppingCart, Store as StoreIcon, Eye, Tag } from 'lucide-react';
import { getCountryDetails } from '../utils/country';

interface ProductCardProps {
  product: Product;
}

export const ProductCard: React.FC<ProductCardProps> = ({ product }) => {
  const {
    favorites,
    toggleFavorite,
    setActiveProductModal,
    setActiveOrderModal
  } = useApp();

  const isFav = favorites.includes(product.id);
  const country = getCountryDetails(product.country_code);

  const handleCardClick = () => {
    setActiveProductModal(product);
  };

  const handleOrderClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    setActiveOrderModal({ product, step: 'confirm' });
  };

  return (
    <div
      onClick={handleCardClick}
      className="group relative bg-[#151515] hover:bg-[#1A1A1A] border border-[#242424] hover:border-[#E50914]/60 rounded-xl sm:rounded-2xl overflow-hidden transition-all duration-200 transform hover:-translate-y-0.5 cursor-pointer flex flex-col shadow-sm hover:shadow-lg hover:shadow-black/50"
    >
      {/* Product Image Box */}
      <div className="relative aspect-square w-full overflow-hidden bg-zinc-900/90">
        <img
          src={product.image_url}
          alt={product.name}
          className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-300"
          loading="lazy"
          referrerPolicy="no-referrer"
        />

        {/* Gradient Shadow Overlay */}
        <div className="absolute inset-0 bg-gradient-to-t from-[#151515] via-transparent to-black/30 pointer-events-none" />

        {/* Top Badges: Country Flag & Badge + Favorites */}
        <div className="absolute top-1.5 inset-x-1.5 flex items-center justify-between z-10">
          <div className="flex items-center gap-1 flex-wrap">
            {/* Prominent Country Flag Badge */}
            <span
              className="px-2 py-0.5 rounded-full bg-black/85 backdrop-blur-md text-white text-[10px] sm:text-[11px] font-black border border-white/20 shadow-md flex items-center gap-1 hover:scale-105 transition-transform"
              title={`دولة النشر: ${country.fullName}`}
            >
              <span className="text-sm leading-none">{country.flag}</span>
              <span className="font-bold">{country.name}</span>
            </span>

            {/* Budget Pill */}
            <span className="px-1.5 py-0.5 rounded-full bg-[#E50914]/90 text-white text-[8px] sm:text-[9px] font-black border border-white/10 shadow-sm">
              {product.budget} {country.currencySymbol}
            </span>

            {product.is_featured && (
              <span className="px-1 py-0.5 rounded bg-[#FFD700] text-black text-[8px] font-black shadow-sm">
                ⭐
              </span>
            )}
          </div>

          {/* Favorite Heart Button */}
          <button
            onClick={(e) => {
              e.stopPropagation();
              toggleFavorite(product.id);
            }}
            className={`w-6 h-6 rounded-full flex items-center justify-center backdrop-blur-md transition-all active:scale-90 shadow-sm shrink-0 ${
              isFav
                ? 'bg-[#E50914] text-white'
                : 'bg-black/60 text-white/80 hover:text-white hover:bg-black/80'
            }`}
            title={isFav ? 'إزالة من المفضلة' : 'حفظ في المفضلة'}
          >
            <Heart className={`w-3 h-3 ${isFav ? 'fill-current text-white' : ''}`} />
          </button>
        </div>

        {/* Coupon pill if available */}
        {product.coupon_code && (
          <div className="absolute bottom-1.5 right-1.5 bg-[#E50914]/90 text-white text-[8px] font-bold px-1.5 py-0.5 rounded backdrop-blur-sm flex items-center gap-0.5 shadow-sm">
            <Tag className="w-2 h-2" />
            <span>{product.coupon_code}</span>
          </div>
        )}
      </div>

      {/* Product Content Details */}
      <div className="p-2 sm:p-2.5 flex-1 flex flex-col justify-between gap-1.5">
        <div>
          {/* Store Info and Country Tag */}
          <div className="flex items-center justify-between text-[10px] text-zinc-400 mb-0.5">
            <span className="flex items-center gap-1 text-zinc-300 font-medium truncate max-w-[80%]">
              <StoreIcon className="w-2.5 h-2.5 text-[#FF3344] shrink-0" />
              <span className="truncate">{product.store_name}</span>
              <span className="text-zinc-400 font-bold shrink-0">({country.flag} {country.name})</span>
            </span>
            {product.order_count ? (
              <span className="text-[9px] text-zinc-500 shrink-0">
                {product.order_count} طلب
              </span>
            ) : null}
          </div>

          {/* Title */}
          <h3 className="text-[11px] sm:text-xs font-bold text-white line-clamp-2 leading-snug group-hover:text-[#FF3344] transition-colors">
            {product.name}
          </h3>
        </div>

        {/* Price and Action Button */}
        <div className="pt-1.5 border-t border-zinc-800/80 flex items-center justify-between gap-1">
          <div className="min-w-0">
            <div className="flex items-baseline gap-0.5">
              <span className="text-xs sm:text-sm font-black text-white truncate">
                {product.price.toLocaleString('ar-EG')}
              </span>
              <span className="text-[9px] sm:text-[10px] text-[#FF3344] font-bold shrink-0">
                {country.currencySymbol}
              </span>
            </div>
          </div>

          <button
            onClick={handleOrderClick}
            className="px-2.5 py-1 rounded-full bg-white hover:bg-zinc-200 text-black text-[10px] sm:text-[11px] font-black transition-all transform active:scale-95 shadow flex items-center gap-1 shrink-0"
          >
            <span>اطلب</span>
          </button>
        </div>
      </div>
    </div>
  );
};
