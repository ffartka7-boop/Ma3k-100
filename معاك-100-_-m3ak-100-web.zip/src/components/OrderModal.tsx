import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import {
  X,
  CheckCircle2,
  Copy,
  Check,
  Upload,
  ArrowRight,
  ShieldCheck,
  AlertCircle,
  ExternalLink,
  PhoneCall,
  Lock
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { getCountryDetails } from '../utils/country';

export const OrderModal: React.FC = () => {
  const {
    activeOrderModal,
    setActiveOrderModal,
    createOrder,
    submitPayment,
    paymentMethods,
    countries,
    orderFee,
    activeCurrency,
    setCurrentView
  } = useApp();

  const [step, setStep] = useState<'confirm' | 'pay' | 'success'>(activeOrderModal?.step || 'confirm');
  const [createdOrder, setCreatedOrder] = useState(activeOrderModal?.order || null);

  React.useEffect(() => {
    if (activeOrderModal) {
      setStep(activeOrderModal.step || 'confirm');
      setCreatedOrder(activeOrderModal.order || null);
      // Reset form on new modal open
      setSenderWallet('');
      setTransactionId('');
      setReceiptImage('');
      setErrorMsg('');
      setIsSubmitting(false);
    }
  }, [activeOrderModal]);

  const [selectedMethodId, setSelectedMethodId] = useState<string>(paymentMethods[0]?.id || 'vodafone_cash');
  const [senderWallet, setSenderWallet] = useState('');
  const [transactionId, setTransactionId] = useState('');
  const [receiptImage, setReceiptImage] = useState<string>('');
  const [copiedNumber, setCopiedNumber] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  if (!activeOrderModal) return null;

  const { product } = activeOrderModal;
  const productCountryCode = product.country_code || 'EG';
  const countryObj = countries.find(c => c.code === productCountryCode) || {
    code: productCountryCode,
    name_ar: getCountryDetails(productCountryCode).name,
    currency_symbol: getCountryDetails(productCountryCode).currencySymbol,
    currency_name_ar: getCountryDetails(productCountryCode).currencyName,
    order_fee: orderFee
  };

  const currentOrderFee = countryObj.order_fee !== undefined ? countryObj.order_fee : orderFee;
  const currencyName = countryObj.currency_name_ar || countryObj.currency_code || activeCurrency;
  const currencySymbol = countryObj.currency_symbol || 'ج.م';
  const country = {
    code: productCountryCode,
    name: countryObj.name_ar,
    currencySymbol: currencySymbol,
    currencyName: currencyName,
    flag: getCountryDetails(productCountryCode).flag
  };

  const countryPaymentMethods = paymentMethods.filter(m => m.is_enabled && (!m.country_code || m.country_code === productCountryCode));
  const availableMethods = countryPaymentMethods.length > 0 ? countryPaymentMethods : paymentMethods.filter(m => m.is_enabled);

  const selectedMethod = availableMethods.find(m => m.id === selectedMethodId) || availableMethods[0] || null;

  const handleCopyWalletNumber = () => {
    if (selectedMethod) {
      navigator.clipboard.writeText(selectedMethod.wallet_number);
      setCopiedNumber(true);
      setTimeout(() => setCopiedNumber(false), 2500);
    }
  };

  const handleConfirmOrder = async () => {
    try {
      setIsSubmitting(true);
      const newOrder = await createOrder(product);
      setCreatedOrder(newOrder);
      setStep('pay');
    } catch {
      setErrorMsg('حدث خطأ أثناء إنشاء الطلب، يرجى المحاولة مرة أخرى.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (uploadEvent) => {
        setReceiptImage(uploadEvent.target?.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmitPayment = async () => {
    if (!createdOrder) return;
    if (!senderWallet.trim()) {
      setErrorMsg('يرجى إدخال رقم المحفظة التي قمت بالتحويل منها.');
      return;
    }
    if (!transactionId.trim()) {
      setErrorMsg('يرجى إدخال رقم العملية أو المرجع (Transaction ID).');
      return;
    }
    if (!selectedMethod) {
      setErrorMsg('يرجى اختيار وسيلة دفع مفعلة ومتاحة.');
      return;
    }
    if (!receiptImage) {
      setErrorMsg('يرجى إرفاق صورة إيصال التحويل للمطابقة السريعة.');
      return;
    }

    try {
      setIsSubmitting(true);
      setErrorMsg('');
      const ok = await submitPayment(
        createdOrder.order_id,
        selectedMethod.name,
        senderWallet,
        transactionId,
        receiptImage
      );
      if (ok) {
        setStep('success');
        try {
          confetti({
            particleCount: 80,
            spread: 70,
            origin: { y: 0.6 }
          });
        } catch {
          // ignore if canvas not ready
        }
      } else {
        setErrorMsg('تعذر تسجيل بيانات الدفع، يرجى إعادة المحاولة.');
      }
    } catch {
      setErrorMsg('حدث خطأ غير متوقع.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm animate-in fade-in duration-200">
      <div
        className="relative w-full max-w-xl bg-[#161616] border border-[#2A2A2A] rounded-3xl overflow-hidden shadow-2xl max-h-[92vh] flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between p-4 sm:p-5 border-b border-[#2A2A2A]">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-[#E50914] animate-pulse" />
            <h3 className="text-base sm:text-lg font-black text-white">
              {step === 'confirm' && 'تأكيد تفاصيل الطلب'}
              {step === 'pay' && 'سداد رسوم الخدمة وتفعيل الرابط'}
              {step === 'success' && 'تم استلام طلبك بنجاح!'}
            </h3>
          </div>
          <button
            onClick={() => setActiveOrderModal(null)}
            className="p-1.5 rounded-full bg-[#222222] text-zinc-400 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-4 sm:p-6 overflow-y-auto space-y-5">
          {/* STEP 1: CONFIRM */}
          {step === 'confirm' && (
            <>
              <div className="flex items-center gap-3.5 p-3.5 bg-[#0B0B0B] rounded-2xl border border-zinc-800">
                <img
                  src={product.image_url}
                  alt={product.name}
                  className="w-16 h-16 rounded-xl object-cover"
                  referrerPolicy="no-referrer"
                />
                <div className="flex-1">
                  <div className="flex items-center gap-1.5 mb-1">
                    <span className="px-2 py-0.5 rounded-full bg-zinc-800 text-white text-[10px] font-bold border border-zinc-700 flex items-center gap-1">
                      <span>{country.flag}</span>
                      <span>{country.name}</span>
                    </span>
                    <span className="text-xs text-zinc-400">المتجر: {product.store_name}</span>
                  </div>
                  <h4 className="text-sm font-bold text-white line-clamp-1">{product.name}</h4>
                  <p className="text-xs text-emerald-400 font-bold mt-1">
                    سعر السلعة: {product.price.toLocaleString('ar-EG')} {country.currencySymbol}
                  </p>
                </div>
              </div>

              {/* Order Cost Breakdown */}
              <div className="p-4 rounded-2xl bg-[#0B0B0B] border border-[#2A2A2A] space-y-2.5 text-xs sm:text-sm">
                <div className="flex justify-between text-zinc-400">
                  <span>سعر المنتج في المتجر الأصلي ({country.name}):</span>
                  <span className="text-white font-bold">{product.price} {country.currencySymbol}</span>
                </div>
                <div className="flex justify-between text-zinc-400">
                  <span>رسوم خدمة المنصة (تفعيل الرابط والكود):</span>
                  <span className="text-[#FF3344] font-black">{currentOrderFee} {currencySymbol}</span>
                </div>
                <div className="pt-2 border-t border-zinc-800 flex justify-between text-sm sm:text-base font-black text-white">
                  <span>المبلغ المطلوب سداده الآن:</span>
                  <span className="text-[#E50914]">{currentOrderFee} {currencySymbol}</span>
                </div>
              </div>

              {/* Security Note */}
              <div className="p-3.5 rounded-xl bg-amber-500/10 border border-amber-500/30 text-xs text-amber-300 flex items-start gap-2.5">
                <AlertCircle className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
                <p className="leading-relaxed">
                  بمجرد سداد رسوم الخدمة الرمزية ({currentOrderFee} {currencySymbol})، سيتم تفعيل رابط الشراء المباشر فوراً وكوبون الخصم الخاص بك لشراء المنتج بسعره الأصلي من المتجر.
                </p>
              </div>

              {errorMsg && (
                <div className="p-3 rounded-xl bg-red-950/40 border border-red-500/50 text-xs text-red-300">
                  {errorMsg}
                </div>
              )}

              <button
                onClick={handleConfirmOrder}
                disabled={isSubmitting}
                className="w-full py-3.5 rounded-2xl bg-[#E50914] hover:bg-[#FF3344] text-white font-bold text-sm transition-all transform active:scale-98 shadow-lg shadow-[#E50914]/25 flex items-center justify-center gap-2 disabled:opacity-50"
              >
                {isSubmitting ? (
                  <span>جاري إنشاء الطلب...</span>
                ) : (
                  <>
                    <span>متابعة للدفع وسداد {currentOrderFee} {currencySymbol}</span>
                    <ArrowRight className="w-4 h-4 rotate-180" />
                  </>
                )}
              </button>
            </>
          )}

          {/* STEP 2: PAYMENT WITH WALLETS */}
          {step === 'pay' && (
            <>
              {/* Payment Methods Selector */}
              <div>
                <label className="text-xs font-bold text-zinc-300 block mb-2">
                  اختر وسيلة الدفع المناسبة:
                </label>
                {availableMethods.length > 0 ? (
                  <div className="grid grid-cols-2 gap-2">
                    {availableMethods.map(method => (
                      <button
                        key={method.id}
                        type="button"
                        onClick={() => setSelectedMethodId(method.id)}
                        className={`p-3 rounded-2xl border text-right transition-all flex flex-col gap-1 ${
                          (selectedMethod?.id === method.id)
                            ? 'bg-[#E50914]/15 border-[#E50914] text-white shadow-lg shadow-[#E50914]/10'
                            : 'bg-[#0B0B0B] border-[#2A2A2A] text-zinc-400 hover:text-white hover:border-zinc-700'
                        }`}
                      >
                        <span className="text-xs font-bold">{method.name}</span>
                        <span className="text-[10px] text-zinc-500 font-mono">{method.wallet_number}</span>
                      </button>
                    ))}
                  </div>
                ) : (
                  <div className="p-4 rounded-2xl bg-amber-500/10 border border-amber-500/20 text-center space-y-1.5 my-2">
                    <p className="text-xs font-bold text-amber-300">لا توجد وسائل دفع مفعلة ومتاحة حالياً لهذه الدولة.</p>
                    <p className="text-[11px] text-zinc-400">يرجى التواصل معنا عبر زر المحادثة لتوفير وسيلة تحويل مباشرة.</p>
                  </div>
                )}
              </div>

              {/* Wallet Info & Copy Card */}
              {selectedMethod && (
                <div className="p-4 rounded-2xl bg-[#0B0B0B] border border-[#2A2A2A] space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-xs text-zinc-400">حول المبلغ المطلوب:</span>
                    <span className="text-base font-black text-[#FF3344]">
                      {currentOrderFee} {currencySymbol}
                    </span>
                  </div>

                  <div className="flex items-center justify-between p-2.5 rounded-xl bg-zinc-900 border border-zinc-800">
                    <div>
                      <span className="text-[10px] text-zinc-500 block">رقم المحفظة المعتمد</span>
                      <span className="text-base font-black text-white font-mono tracking-wider">
                        {selectedMethod.wallet_number}
                      </span>
                    </div>

                    <button
                      onClick={handleCopyWalletNumber}
                      className="px-3 py-1.5 rounded-lg bg-[#E50914] hover:bg-[#FF3344] text-white text-xs font-bold flex items-center gap-1 transition-colors"
                    >
                      {copiedNumber ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                      <span>{copiedNumber ? 'تم النسخ' : 'نسخ الرقم'}</span>
                    </button>
                  </div>

                  <p className="text-[11px] text-zinc-400 leading-relaxed">
                    {selectedMethod.instructions}
                  </p>
                </div>
              )}

              {/* Form inputs for verification */}
              <div className="space-y-3 pt-1">
                <div>
                  <label className="text-xs font-bold text-zinc-300 block mb-1">
                    رقم المحفظة المحول منها:
                  </label>
                  <input
                    type="text"
                    value={senderWallet}
                    onChange={(e) => setSenderWallet(e.target.value)}
                    placeholder="مثال: 01012345678"
                    className="w-full bg-[#0B0B0B] text-white text-sm rounded-xl px-3.5 py-2.5 border border-[#2A2A2A] focus:outline-none focus:border-[#E50914]"
                  />
                </div>

                <div>
                  <label className="text-xs font-bold text-zinc-300 block mb-1">
                    رقم العملية أو الرقم المرجعي (Transaction ID):
                  </label>
                  <input
                    type="text"
                    value={transactionId}
                    onChange={(e) => setTransactionId(e.target.value)}
                    placeholder="مثال: 94827103"
                    className="w-full bg-[#0B0B0B] text-white text-sm rounded-xl px-3.5 py-2.5 border border-[#2A2A2A] focus:outline-none focus:border-[#E50914]"
                  />
                </div>

                {/* Receipt Upload */}
                <div>
                  <label className="text-xs font-bold text-zinc-300 block mb-1">
                    صورة إيصال التحويل (سكرين شوت):
                  </label>
                  <label className="flex flex-col items-center justify-center w-full p-4 border-2 border-dashed border-[#2A2A2A] hover:border-[#E50914] rounded-2xl bg-[#0B0B0B] cursor-pointer transition-colors">
                    {receiptImage ? (
                      <div className="flex items-center gap-3">
                        <img
                          src={receiptImage}
                          alt="Receipt"
                          className="w-14 h-14 object-cover rounded-lg border border-zinc-700"
                        />
                        <div className="text-right">
                          <span className="text-xs font-bold text-emerald-400 block">تم إرفاق الإيصال بنجاح</span>
                          <span className="text-[10px] text-zinc-400">اضغط لتغيير الصورة</span>
                        </div>
                      </div>
                    ) : (
                      <div className="flex flex-col items-center justify-center gap-1.5 text-zinc-400">
                        <Upload className="w-5 h-5 text-[#FF3344]" />
                        <span className="text-xs font-bold text-white">اضغط لاختيار صورة الإيصال</span>
                        <span className="text-[10px] text-zinc-500">PNG, JPG بحد أقصى 5 ميجابايت</span>
                      </div>
                    )}
                    <input
                      type="file"
                      accept="image/*"
                      onChange={handleFileChange}
                      className="hidden"
                    />
                  </label>
                </div>
              </div>

              {errorMsg && (
                <div className="p-3 rounded-xl bg-red-950/40 border border-red-500/50 text-xs text-red-300">
                  {errorMsg}
                </div>
              )}

              <button
                onClick={handleSubmitPayment}
                disabled={isSubmitting}
                className="w-full py-3.5 rounded-2xl bg-[#E50914] hover:bg-[#FF3344] text-white font-bold text-sm transition-all transform active:scale-98 shadow-lg shadow-[#E50914]/25 flex items-center justify-center gap-2 disabled:opacity-50"
              >
                {isSubmitting ? (
                  <span>جاري إرسال الإيصال للمراجعة...</span>
                ) : (
                  <>
                    <CheckCircle2 className="w-4 h-4" />
                    <span>تأكيد التحويل وإرسال الإيصال</span>
                  </>
                )}
              </button>
            </>
          )}

          {/* STEP 3: SUCCESS */}
          {step === 'success' && (
            <div className="text-center py-4 space-y-4">
              <div className="w-16 h-16 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 flex items-center justify-center mx-auto">
                <CheckCircle2 className="w-8 h-8" />
              </div>

              <div>
                <h4 className="text-lg font-black text-white">تم إرسال إيصال الدفع بنجاح!</h4>
                <p className="text-xs text-zinc-400 mt-1 max-w-sm mx-auto leading-relaxed">
                  طلبك رقم <span className="text-white font-mono font-bold">{createdOrder?.order_id}</span> قيد المراجعة الفورية من قبل الإدارة، وسيتم تفعيل رابط الشراء فور التأكيد.
                </p>
              </div>

              <div className="p-4 rounded-2xl bg-[#0B0B0B] border border-zinc-800 text-xs text-zinc-300 space-y-1.5 text-right">
                <div className="flex justify-between">
                  <span className="text-zinc-500">المنتج:</span>
                  <span className="font-bold text-white">{product.name}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-zinc-500">المبلغ:</span>
                  <span className="font-bold text-emerald-400">{currentOrderFee} {currencySymbol}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-zinc-500">طريقة الدفع:</span>
                  <span className="font-bold text-white">{selectedMethod?.name}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-zinc-500">الحالة:</span>
                  <span className="font-bold text-[#FF9800]">قيد مراجعة الدفع ⏳</span>
                </div>
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  onClick={() => {
                    console.log('OrderModal: Closing modal via Orders button');
                    setActiveOrderModal(null);
                    setCurrentView('orders');
                  }}
                  className="flex-1 py-3 rounded-xl bg-[#E50914] text-white font-bold text-xs hover:bg-[#FF3344] transition-colors"
                >
                  الانتقال لصفحة طلباتي
                </button>
                <button
                  onClick={() => {
                    console.log('OrderModal: Closing modal via Close button');
                    setActiveOrderModal(null);
                  }}
                  className="px-5 py-3 rounded-xl bg-zinc-800 text-zinc-300 font-bold text-xs hover:text-white transition-colors"
                >
                  إغلاق
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
