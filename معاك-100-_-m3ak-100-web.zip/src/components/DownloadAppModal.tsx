import React, { useState, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import {
  Smartphone,
  Download,
  CheckCircle2,
  AlertCircle,
  Copy,
  Check,
  X,
  RefreshCw,
  Layers,
  FileCode,
  ShieldCheck,
  Sparkles
} from 'lucide-react';
import type { AppUpdate } from '../types';

export const DownloadAppModal: React.FC = () => {
  const {
    isDownloadModalOpen,
    setIsDownloadModalOpen,
    getLatestActiveAppUpdate,
    latestActiveAppUpdate,
    downloadLatestApk
  } = useApp();

  const [activeUpdate, setActiveUpdate] = useState<AppUpdate | null>(latestActiveAppUpdate);
  const [isLoading, setIsLoading] = useState(false);
  const [isDownloading, setIsDownloading] = useState(false);
  const [copiedLink, setCopiedLink] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  // Close on Escape key
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isDownloadModalOpen) {
        setIsDownloadModalOpen(false);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isDownloadModalOpen, setIsDownloadModalOpen]);

  // Fetch fresh active update when modal opens
  useEffect(() => {
    if (isDownloadModalOpen) {
      setErrorMsg('');
      setIsLoading(true);
      getLatestActiveAppUpdate()
        .then((res) => {
          if (res) {
            setActiveUpdate(res);
          } else if (latestActiveAppUpdate) {
            setActiveUpdate(latestActiveAppUpdate);
          }
        })
        .catch((err) => {
          console.warn('Failed to fetch latest active app update:', err);
          if (latestActiveAppUpdate) {
            setActiveUpdate(latestActiveAppUpdate);
          }
        })
        .finally(() => {
          setIsLoading(false);
        });
    }
  }, [isDownloadModalOpen, latestActiveAppUpdate]);

  if (!isDownloadModalOpen) return null;

  const handleDirectDownload = async () => {
    try {
      setIsDownloading(true);
      setErrorMsg('');

      const res = await downloadLatestApk();
      if (!res.success) {
        setErrorMsg(res.error || 'تعذر بدء التحميل. يرجى المحاولة لاحقاً.');
      }

      setTimeout(() => {
        setIsDownloading(false);
      }, 1500);
    } catch (e: any) {
      console.error('Download error:', e);
      setErrorMsg('تعذر بدء التحميل تلقائياً. يمكنك نسخ الرابط واستخدامه مباشرة.');
      setIsDownloading(false);
    }
  };

  const handleCopyLink = () => {
    if (activeUpdate?.apk_url) {
      navigator.clipboard.writeText(activeUpdate.apk_url);
      setCopiedLink(true);
      setTimeout(() => setCopiedLink(false), 2500);
    }
  };

  return (
    <div
      onClick={(e) => {
        if (e.target === e.currentTarget) {
          setIsDownloadModalOpen(false);
        }
      }}
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-fadeIn"
    >
      <div className="relative max-w-md w-full bg-[#141414] border border-[#2A2A2A] rounded-2xl overflow-hidden shadow-2xl shadow-emerald-500/10 p-5 sm:p-6 space-y-4">
        
        {/* Top Glow & Decorative Elements */}
        <div className="absolute top-0 right-1/2 translate-x-1/2 w-48 h-24 bg-emerald-500/15 blur-3xl rounded-full pointer-events-none -z-0" />

        {/* Close Button */}
        <button
          onClick={() => setIsDownloadModalOpen(false)}
          className="absolute top-4 left-4 p-2.5 rounded-full bg-zinc-900 border border-zinc-700 text-white hover:bg-zinc-800 hover:border-zinc-500 transition-colors z-20 shadow-md flex items-center justify-center"
          title="إغلاق النافذة"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header with App Icon */}
        <div className="flex items-center gap-3.5 relative z-10 pr-10">
          <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-emerald-500/20 via-emerald-500/10 to-transparent border border-emerald-500/30 flex items-center justify-center text-emerald-400 shadow-lg shadow-emerald-500/20 shrink-0">
            <Smartphone className="w-7 h-7" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-lg font-black text-white">تطبيق معاك 100</h2>
              <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 border border-emerald-500/30 text-emerald-400 text-[10px] font-bold">
                APK رسمي
              </span>
            </div>
            <p className="text-xs text-zinc-400 mt-0.5">
              أحدث إصدار مرفوع من لوحة التحكم.
            </p>
          </div>
        </div>

        {/* Error message */}
        {errorMsg && (
          <div className="p-3 bg-red-950/40 border border-red-500/40 rounded-xl text-xs text-red-300 flex items-start gap-2 animate-fadeIn relative z-10">
            <AlertCircle className="w-4 h-4 text-red-400 shrink-0 mt-0.5" />
            <span>{errorMsg}</span>
          </div>
        )}

        {/* Update Card */}
        {isLoading ? (
          <div className="py-8 text-center space-y-3 bg-[#0B0B0B] border border-zinc-800 rounded-xl p-5 relative z-10">
            <RefreshCw className="w-7 h-7 text-emerald-400 animate-spin mx-auto" />
            <p className="text-xs text-zinc-400 font-bold">جاري جلب بيانات آخر إصدار من السحابة...</p>
          </div>
        ) : activeUpdate ? (
          <div className="bg-[#0B0B0B] border border-zinc-800 rounded-xl p-4 space-y-3 relative z-10">
            {/* Version Meta Bar */}
            <div className="flex flex-wrap items-center justify-between gap-2 pb-2.5 border-b border-zinc-800/80">
              <div className="flex items-center gap-2">
                <span className="px-2.5 py-0.5 rounded-lg bg-emerald-500/20 text-emerald-300 font-mono font-black text-xs border border-emerald-500/40">
                  v{activeUpdate.version_name}
                </span>
                <span className="px-2 py-0.5 rounded-lg bg-zinc-900 text-zinc-400 font-mono text-[10px] border border-zinc-800">
                  كود: {activeUpdate.version_code}
                </span>
                {activeUpdate.file_size_mb && (
                  <span className="px-2 py-0.5 rounded-lg bg-blue-950/40 text-blue-300 font-mono text-[10px] border border-blue-500/30">
                    {activeUpdate.file_size_mb} MB
                  </span>
                )}
              </div>

              <div className="flex items-center gap-1.5 text-[11px] text-emerald-400 font-bold">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
                <span>جاهز</span>
              </div>
            </div>

            {/* Title & Description / Changelog */}
            <div className="space-y-1">
              <h3 className="text-xs font-bold text-white flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-emerald-400" />
                <span>{activeUpdate.update_title || 'أحدث إصدار نشط'}</span>
              </h3>
              {activeUpdate.update_description ? (
                <p className="text-xs text-zinc-400 leading-relaxed whitespace-pre-line bg-[#141414] p-2.5 rounded-lg border border-zinc-800/80 max-h-24 overflow-y-auto">
                  {activeUpdate.update_description}
                </p>
              ) : (
                <p className="text-xs text-zinc-500">
                  تحسينات عامة على السرعة والأداء وتجربة طلبات المنتجات.
                </p>
              )}
            </div>
          </div>
        ) : (
          <div className="text-center py-6 space-y-2 bg-[#0B0B0B] border border-zinc-800 rounded-xl p-4 relative z-10">
            <Smartphone className="w-8 h-8 text-zinc-600 mx-auto" />
            <p className="text-xs font-bold text-white">لا يوجد إصدار منشور حالياً</p>
            <p className="text-[11px] text-zinc-400">
              يرجى إضافة إصدار من لوحة التحكم.
            </p>
          </div>
        )}

        {/* Action Buttons */}
        <div className="space-y-2.5 relative z-10">
          <button
            onClick={handleDirectDownload}
            disabled={isDownloading || !activeUpdate}
            className="w-full py-3.5 rounded-xl bg-gradient-to-r from-emerald-600 via-emerald-500 to-teal-600 hover:from-emerald-500 hover:to-teal-500 disabled:opacity-50 text-white text-xs font-black transition-all flex items-center justify-center gap-2 shadow-lg shadow-emerald-600/30 group cursor-pointer"
          >
            {isDownloading ? (
              <>
                <RefreshCw className="w-4 h-4 animate-spin" />
                <span>جاري بدء التحميل...</span>
              </>
            ) : (
              <>
                <Download className="w-4 h-4 group-hover:scale-110 transition-transform" />
                <span>تحميل التطبيق الآن (APK)</span>
              </>
            )}
          </button>

          {activeUpdate?.apk_url && (
            <button
              onClick={handleCopyLink}
              className="w-full py-2 rounded-lg bg-zinc-900 hover:bg-zinc-800 text-zinc-300 hover:text-white border border-zinc-800 text-[11px] font-bold transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
            >
              {copiedLink ? (
                <>
                  <Check className="w-3.5 h-3.5 text-emerald-400" />
                  <span className="text-emerald-400">تم نسخ رابط التحميل!</span>
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5 text-zinc-400" />
                  <span>نسخ رابط التحميل المباشر</span>
                </>
              )}
            </button>
          )}
        </div>

        {/* Installation Tip Footer */}
        <div className="pt-2 border-t border-zinc-800/80 text-[10px] text-zinc-400 text-center relative z-10">
          💡 بعد اكتمال التحميل، اضغط على الملف المُنزل وثبّته على هاتفك بسهولة.
        </div>
      </div>
    </div>
  );
};
