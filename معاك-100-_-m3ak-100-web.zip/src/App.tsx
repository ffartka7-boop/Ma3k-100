import React from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { Header } from './components/Header';
import { Hero } from './components/Hero';
import { CategoryChips } from './components/CategoryChips';
import { BudgetCards } from './components/BudgetCards';
import { FeaturedProducts } from './components/FeaturedProducts';
import { ProductsView } from './components/ProductsView';
import { FavoritesView } from './components/FavoritesView';
import { OrdersView } from './components/OrdersView';
import { AboutSection } from './components/AboutSection';
import { Footer } from './components/Footer';
import { AuthModal } from './components/AuthModal';
import { ProductDetailsModal } from './components/ProductDetailsModal';
import { OrderModal } from './components/OrderModal';
import { SupportChatModal } from './components/SupportChatModal';
import { AdminDashboard } from './components/AdminDashboard';
import { GmailView } from './components/GmailView';
import { SheetsView } from './components/SheetsView';
import { DownloadAppModal } from './components/DownloadAppModal';

const MainContent: React.FC = () => {
  const { currentView } = useApp();

  return (
    <main className="min-h-[calc(100vh-80px)] flex flex-col justify-between">
      <div>
        {currentView === 'home' && (
          <>
            <Hero />
            <CategoryChips />
            <BudgetCards />
            <FeaturedProducts />
            <AboutSection />
          </>
        )}

        {currentView === 'products' && <ProductsView />}

        {currentView === 'favorites' && <FavoritesView />}

        {currentView === 'orders' && <OrdersView />}

        {currentView === 'about' && (
          <div className="py-8">
            <AboutSection />
          </div>
        )}

        {currentView === 'gmail' && <GmailView />}

        {currentView === 'sheets' && <SheetsView />}

        {currentView === 'admin' && <AdminDashboard />}
      </div>

      <Footer />

      {/* Global Interactive Modals */}
      <AuthModal />
      <ProductDetailsModal />
      <OrderModal />
      <SupportChatModal />
      <DownloadAppModal />
    </main>
  );
};

export default function App() {
  return (
    <AppProvider>
      <div className="min-h-screen bg-[#0B0B0B] text-white flex flex-col font-sans selection:bg-[#E50914] selection:text-white">
        <Header />
        <MainContent />
      </div>
    </AppProvider>
  );
}
