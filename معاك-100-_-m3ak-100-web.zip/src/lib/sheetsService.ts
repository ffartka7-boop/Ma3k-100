import { getCachedAccessToken } from './googleAuth';

export interface SpreadsheetFile {
  id: string;
  name: string;
  createdTime?: string;
  modifiedTime?: string;
  webViewLink?: string;
  owners?: { displayName: string; emailAddress: string }[];
}

export interface SheetTab {
  sheetId: number;
  title: string;
  index: number;
  gridProperties?: {
    rowCount: number;
    columnCount: number;
  };
}

export interface SpreadsheetMetadata {
  spreadsheetId: string;
  properties: {
    title: string;
    locale?: string;
    timeZone?: string;
  };
  sheets: {
    properties: SheetTab;
  }[];
  spreadsheetUrl: string;
}

export interface SheetValuesResponse {
  range: string;
  majorDimension: string;
  values: string[][];
}

const SHEETS_BASE_URL = 'https://sheets.googleapis.com/v4/spreadsheets';
const DRIVE_BASE_URL = 'https://www.googleapis.com/drive/v3';

/**
 * List all Google Spreadsheets from user's Drive
 */
export async function listSpreadsheets(token?: string): Promise<SpreadsheetFile[]> {
  const accessToken = token || getCachedAccessToken();
  if (!accessToken) throw new Error('مطلوب تسجيل الدخول بحساب Google للوصول إلى جداول البيانات.');

  const q = "mimeType='application/vnd.google-apps.spreadsheet' and trashed=false";
  const fields = 'files(id, name, createdTime, modifiedTime, webViewLink, owners)';
  const url = `${DRIVE_BASE_URL}/files?q=${encodeURIComponent(q)}&fields=${encodeURIComponent(fields)}&orderBy=modifiedTime desc&pageSize=30`;

  const res = await fetch(url, {
    headers: { Authorization: `Bearer ${accessToken}` }
  });

  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error?.message || `فشل جلب ملفات Google Sheets (${res.status})`);
  }

  const data = await res.json();
  return data.files || [];
}

/**
 * Fetch spreadsheet metadata including sheet tabs/names
 */
export async function getSpreadsheetMetadata(spreadsheetId: string, token?: string): Promise<SpreadsheetMetadata> {
  const accessToken = token || getCachedAccessToken();
  if (!accessToken) throw new Error('مطلوب تسجيل الدخول بحساب Google.');

  const url = `${SHEETS_BASE_URL}/${spreadsheetId}?fields=spreadsheetId,properties.title,sheets.properties,spreadsheetUrl`;
  const res = await fetch(url, {
    headers: { Authorization: `Bearer ${accessToken}` }
  });

  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error?.message || `فشل جلب بيانات جدول البيانات (${res.status})`);
  }

  return res.json();
}

/**
 * Read values from a given sheet range (e.g. "Sheet1!A1:Z100" or just tab title "الطلبات")
 */
export async function getSheetValues(
  spreadsheetId: string,
  range: string,
  token?: string
): Promise<SheetValuesResponse> {
  const accessToken = token || getCachedAccessToken();
  if (!accessToken) throw new Error('مطلوب تسجيل الدخول بحساب Google.');

  const encodedRange = encodeURIComponent(range);
  const url = `${SHEETS_BASE_URL}/${spreadsheetId}/values/${encodedRange}?valueRenderOption=FORMATTED_VALUE`;

  const res = await fetch(url, {
    headers: { Authorization: `Bearer ${accessToken}` }
  });

  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error?.message || `فشل قراءة خلايا جدول البيانات (${res.status})`);
  }

  const data = await res.json();
  return {
    range: data.range || range,
    majorDimension: data.majorDimension || 'ROWS',
    values: data.values || []
  };
}

/**
 * Append rows to an existing sheet
 */
export async function appendSheetValues(
  spreadsheetId: string,
  range: string,
  values: (string | number)[][],
  token?: string
): Promise<any> {
  const accessToken = token || getCachedAccessToken();
  if (!accessToken) throw new Error('مطلوب تسجيل الدخول بحساب Google.');

  const encodedRange = encodeURIComponent(range);
  const url = `${SHEETS_BASE_URL}/${spreadsheetId}/values/${encodedRange}:append?valueInputOption=USER_ENTERED&insertDataOption=INSERT_ROWS`;

  const res = await fetch(url, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${accessToken}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      range,
      majorDimension: 'ROWS',
      values
    })
  });

  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error?.message || `فشل إضافة البيانات للجدول (${res.status})`);
  }

  return res.json();
}

/**
 * Update cell values in a specified range
 */
export async function updateSheetValues(
  spreadsheetId: string,
  range: string,
  values: (string | number)[][],
  token?: string
): Promise<any> {
  const accessToken = token || getCachedAccessToken();
  if (!accessToken) throw new Error('مطلوب تسجيل الدخول بحساب Google.');

  const encodedRange = encodeURIComponent(range);
  const url = `${SHEETS_BASE_URL}/${spreadsheetId}/values/${encodedRange}?valueInputOption=USER_ENTERED`;

  const res = await fetch(url, {
    method: 'PUT',
    headers: {
      Authorization: `Bearer ${accessToken}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      range,
      majorDimension: 'ROWS',
      values
    })
  });

  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error?.message || `فشل تحديث البيانات في الجدول (${res.status})`);
  }

  return res.json();
}

/**
 * Create a new Google Spreadsheet with optional initial sheets and row data
 */
export async function createSpreadsheet(
  title: string,
  initialSheets: { title: string; headers?: string[]; rows?: (string | number)[][] }[] = [],
  token?: string
): Promise<SpreadsheetMetadata> {
  const accessToken = token || getCachedAccessToken();
  if (!accessToken) throw new Error('مطلوب تسجيل الدخول بحساب Google.');

  const sheetsConfig = initialSheets.length > 0
    ? initialSheets.map((s, idx) => ({
        properties: {
          sheetId: idx,
          title: s.title,
          index: idx
        }
      }))
    : [{ properties: { sheetId: 0, title: 'البيانات', index: 0 } }];

  const res = await fetch(SHEETS_BASE_URL, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${accessToken}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      properties: {
        title
      },
      sheets: sheetsConfig
    })
  });

  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error?.message || `فشل إنشاء جدول البيانات (${res.status})`);
  }

  const createdSheet: SpreadsheetMetadata = await res.json();

  // If initial rows/headers were provided, write them now
  for (const item of initialSheets) {
    const allRows: (string | number)[][] = [];
    if (item.headers && item.headers.length > 0) {
      allRows.push(item.headers);
    }
    if (item.rows && item.rows.length > 0) {
      allRows.push(...item.rows);
    }

    if (allRows.length > 0) {
      try {
        await updateSheetValues(createdSheet.spreadsheetId, `'${item.title}'!A1`, allRows, accessToken);
      } catch (err) {
        console.warn(`Initial rows write notice for sheet ${item.title}:`, err);
      }
    }
  }

  return createdSheet;
}

/**
 * Delete / trash a spreadsheet file via Google Drive API
 */
export async function deleteSpreadsheet(fileId: string, token?: string): Promise<void> {
  const accessToken = token || getCachedAccessToken();
  if (!accessToken) throw new Error('مطلوب تسجيل الدخول بحساب Google.');

  // Trashing is safer than permanent delete
  const url = `${DRIVE_BASE_URL}/files/${fileId}`;
  const res = await fetch(url, {
    method: 'PATCH',
    headers: {
      Authorization: `Bearer ${accessToken}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({ trashed: true })
  });

  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error?.message || `فشل حذف جدول البيانات (${res.status})`);
  }
}
