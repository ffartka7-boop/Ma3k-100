import React, { createContext, useContext, useState, useEffect, useMemo, ReactNode } from 'react';
import type { Product, Category, Budget, Store, Country, Order, Payment, PaymentMethod, ChatMessage, UserProfile, AppView, AppUpdate } from '../types';
import {
  supabase,
  SUPABASE_URL,
  DEFAULT_CATEGORIES,
  DEFAULT_BUDGETS,
  DEFAULT_STORES,
  DEFAULT_COUNTRIES,
  DEFAULT_PAYMENT_METHODS,
  INITIAL_PRODUCTS
} from '../lib/supabase';
import { signInWithGoogleWorkspace, logoutGoogle } from '../lib/googleAuth';
import { validateAndAnalyzeApkFile, sanitizeApkFileName, checkApkUrlHealth } from '../lib/apkValidator';

interface AppContextType {
  // Navigation & Views
  currentView: AppView;
  setCurrentView: (view: AppView) => void;

  // Data
  products: Product[];
  categories: Category[];
  budgets: Budget[];
  stores: Store[];
  countries: Country[];
  activeCountries: Country[];
  paymentMethods: PaymentMethod[];
  orders: Order[];
  payments: Payment[];
  chatMessages: ChatMessage[];
  favorites: string[];
  appUpdates: AppUpdate[];

  // User & Auth
  currentUser: UserProfile | null;
  isAdmin: boolean;
  signInWithGoogleReal: () => Promise<void>;
  loginWithGoogle: (email?: string, name?: string) => Promise<void>;
  loginWithEmail: (email: string, pass: string) => Promise<boolean>;
  signUpWithEmail: (name: string, email: string, pass: string) => Promise<boolean>;
  logout: () => void;
  setGuestUser: () => void;

  // Filters & State
  selectedBudget: number | null;
  setSelectedBudget: (budget: number | null) => void;
  selectedCategory: string | null;
  setSelectedCategory: (catId: string | null) => void;
  selectedStore: string | null;
  setSelectedStore: (store: string | null) => void;
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  selectedCountry: string;
  setSelectedCountry: (code: string) => void;
  activeCurrency: string;
  activeCurrencySymbol: string;
  orderFee: number;
  orderExpiryMinutes: number;

  // Actions
  toggleFavorite: (productId: string) => void;
  createOrder: (product: Product) => Promise<Order>;
  deleteOrder: (orderId: string) => Promise<void>;
  submitPayment: (orderId: string, method: string, senderWallet: string, txnId: string, receiptImage: string) => Promise<boolean>;
  deletePayment: (paymentId: string) => Promise<void>;
  sendChatMessage: (text: string, orderId?: string) => Promise<void>;

  // Admin Actions
  adminApprovePayment: (paymentId: string, orderId: string) => Promise<void>;
  adminRejectPayment: (paymentId: string, orderId: string, reason: string) => Promise<void>;
  adminUpsertProduct: (product: Product) => Promise<void>;
  adminDeleteProduct: (productId: string) => Promise<void>;
  adminToggleFeatured: (productId: string) => Promise<void>;
  adminUpsertPaymentMethod: (method: PaymentMethod) => Promise<void>;
  adminDeletePaymentMethod: (methodId: string) => Promise<void>;
  adminTogglePaymentMethodActive: (methodId: string) => Promise<void>;
  adminSeedPaymentMethodsToSupabase: () => Promise<{ success: boolean; count?: number; error?: string }>;
  isLiveSyncConnected: boolean;
  lastLiveEvent: { table: string; type: string; timestamp: number } | null;
  adminToggleCountryActive: (countryCode: string) => Promise<void>;
  adminUpsertCountry: (country: Country) => Promise<void>;
  adminDeleteCountry: (countryCode: string) => Promise<void>;
  adminUpdateSettings: (newFee: number, newExpiry: number, currency: string) => Promise<void>;
  adminUploadApk: (file: File, versionName: string, versionCode: number, title: string, description: string, isActive?: boolean) => Promise<{ success: boolean; error?: string; update?: AppUpdate }>;
  adminPublishCustomApkUrl: (apkUrl: string, versionName: string, versionCode: number, title: string, description: string, isActive?: boolean, fileSizeMb?: number) => Promise<{ success: boolean; error?: string; update?: AppUpdate }>;
  adminToggleAppUpdateActive: (updateId: string) => Promise<void>;
  adminDeleteAppUpdate: (updateId: string) => Promise<void>;
  adminSeedCountriesToSupabase: () => Promise<{ success: boolean; count?: number; error?: string }>;
  syncWithSupabase: () => Promise<void>;
  getLatestActiveAppUpdate: () => Promise<AppUpdate | null>;
  downloadLatestApk: () => Promise<{ success: boolean; update?: AppUpdate; error?: string }>;
  latestActiveAppUpdate: AppUpdate | null;

  // Modals
  isAuthModalOpen: boolean;
  setIsAuthModalOpen: (open: boolean) => void;
  isDownloadModalOpen: boolean;
  setIsDownloadModalOpen: (open: boolean) => void;
  activeProductModal: Product | null;
  setActiveProductModal: (prod: Product | null) => void;
  activeOrderModal: { product: Product; order?: Order; step?: 'confirm' | 'pay' | 'success' } | null;
  setActiveOrderModal: (val: { product: Product; order?: Order; step?: 'confirm' | 'pay' | 'success' } | null) => void;
  isChatModalOpen: boolean;
  setIsChatModalOpen: (open: boolean) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

const STORAGE_KEYS = {
  USER: 'm3ak_user',
  FAVORITES: 'm3ak_favorites',
  PRODUCTS: 'm3ak_local_products',
  ORDERS: 'm3ak_local_orders',
  PAYMENTS: 'm3ak_local_payments',
  COUNTRY: 'm3ak_selected_country',
  COUNTRIES: 'm3ak_countries',
  PAYMENT_METHODS: 'm3ak_payment_methods',
  CHAT: 'm3ak_chat_messages',
  SETTINGS: 'm3ak_settings',
  APP_UPDATES: 'm3ak_app_updates'
};

const OWNER_EMAIL = 'mohmdfartka00@gmail.com';
const OWNER_UUID = '279326f5-560f-3df1-b1e7-2b36e52c8038';

export const AppProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  // Views
  const [currentView, setCurrentView] = useState<'home' | 'products' | 'favorites' | 'orders' | 'about' | 'admin'>('home');

  // Core Data
  const [products, setProducts] = useState<Product[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.PRODUCTS);
    if (saved) {
      try {
        const parsed: Product[] = JSON.parse(saved);
        // Ensure SA and AE products are present from INITIAL_PRODUCTS
        const hasSa = parsed.some((p) => p.country_code === 'SA');
        const hasAe = parsed.some((p) => p.country_code === 'AE');
        if (!hasSa || !hasAe) {
          const missing = INITIAL_PRODUCTS.filter((ip) => !parsed.some((p) => p.id === ip.id));
          const merged = [...parsed, ...missing];
          localStorage.setItem(STORAGE_KEYS.PRODUCTS, JSON.stringify(merged));
          return merged;
        }
        return parsed;
      } catch {
        return INITIAL_PRODUCTS;
      }
    }
    return INITIAL_PRODUCTS;
  });
  const [categories] = useState<Category[]>(DEFAULT_CATEGORIES);
  const [budgets] = useState<Budget[]>(DEFAULT_BUDGETS);
  const [stores] = useState<Store[]>(DEFAULT_STORES);
  const [countries, setCountries] = useState<Country[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.COUNTRIES);
    if (saved) {
      try {
        const parsed: Country[] = JSON.parse(saved);
        // Exclude legacy 'ALL' completely
        const filtered = parsed.filter((c) => c.code !== 'ALL');
        // Ensure all default countries are present
        const missing = DEFAULT_COUNTRIES.filter((dc) => !filtered.some((f) => f.code === dc.code));
        const merged = [...filtered, ...missing];
        return merged;
      } catch {
        return DEFAULT_COUNTRIES;
      }
    }
    return DEFAULT_COUNTRIES;
  });
  const [paymentMethods, setPaymentMethods] = useState<PaymentMethod[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.PAYMENT_METHODS);
    if (saved) {
      try {
        const parsed: PaymentMethod[] = JSON.parse(saved);
        const hasSa = parsed.some((m) => m.country_code === 'SA');
        if (!hasSa) {
          const missing = DEFAULT_PAYMENT_METHODS.filter((dm) => !parsed.some((p) => p.id === dm.id));
          const merged = [...parsed, ...missing];
          localStorage.setItem(STORAGE_KEYS.PAYMENT_METHODS, JSON.stringify(merged));
          return merged;
        }
        return parsed;
      } catch {
        return DEFAULT_PAYMENT_METHODS;
      }
    }
    return DEFAULT_PAYMENT_METHODS;
  });

  const [orders, setOrders] = useState<Order[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.ORDERS);
    return saved ? JSON.parse(saved) : [];
  });

  const [payments, setPayments] = useState<Payment[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.PAYMENTS);
    return saved ? JSON.parse(saved) : [];
  });

  const [favorites, setFavorites] = useState<string[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.FAVORITES);
    return saved ? JSON.parse(saved) : [];
  });

  const [chatMessages, setChatMessages] = useState<ChatMessage[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.CHAT);
    return saved ? JSON.parse(saved) : [
      {
        message_id: 'welcome_msg',
        conversation_id: 'support',
        sender_id: 'admin',
        sender_name: 'خدمة العملاء (معاك 100) 🛡️',
        sender_role: 'ADMIN',
        message_text: 'أهلاً بك في منصة معاك 100! كيف يمكننا مساعدتك اليوم؟',
        timestamp: Date.now() - 3600000,
        is_read: true
      }
    ];
  });

  const [appUpdates, setAppUpdates] = useState<AppUpdate[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.APP_UPDATES);
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) {
          // Filter out legacy non-existent placeholder URL that was causing 404 NoSuchKey
          return parsed.filter((u: any) => !u.apk_url?.includes('releases/m3ak100_v1_0_0_code1.apk'));
        }
      } catch {
        return [];
      }
    }
    return [];
  });

  // User
  const [currentUser, setCurrentUser] = useState<UserProfile | null>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.USER);
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch {
        return null;
      }
    }
    // Default guest user
    return {
      id: 'guest_' + Math.random().toString(36).substring(2, 9),
      name: 'زائر معاك 100',
      email: 'guest@m3ak100.com',
      is_admin: false,
      role: 'guest',
      created_at: Date.now()
    };
  });

  // Filters
  const [selectedBudget, setSelectedBudget] = useState<number | null>(null);
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [selectedStore, setSelectedStore] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedCountry, setSelectedCountryState] = useState<string>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.COUNTRY);
    if (!saved || saved === 'ALL') {
      return 'EG';
    }
    return saved;
  });

  // Derived initial country metadata
  const initialCountryObj = countries.find((c) => c.code === selectedCountry) || countries[0] || DEFAULT_COUNTRIES[0];
  const [orderFee, setOrderFee] = useState<number>(initialCountryObj?.order_fee || 10);
  const [orderExpiryMinutes, setOrderExpiryMinutes] = useState<number>(30);
  const [activeCurrency, setActiveCurrency] = useState<string>(initialCountryObj?.currency_name_ar || initialCountryObj?.currency_code || 'جنيه');
  const [activeCurrencySymbol, setActiveCurrencySymbol] = useState<string>(initialCountryObj?.currency_symbol || 'ج.م');

  // Modals
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [isDownloadModalOpen, setIsDownloadModalOpen] = useState(false);
  const [activeProductModal, setActiveProductModal] = useState<Product | null>(null);
  const [activeOrderModal, setActiveOrderModal] = useState<{ product: Product; order?: Order; step?: 'confirm' | 'pay' | 'success' } | null>(null);
  const [isChatModalOpen, setIsChatModalOpen] = useState(false);
  const [isLiveSyncConnected, setIsLiveSyncConnected] = useState(true);
  const [lastLiveEvent, setLastLiveEvent] = useState<{ table: string; type: string; timestamp: number } | null>(null);

  // Latest active app update memo
  const latestActiveAppUpdate = useMemo(() => {
    const activeList = appUpdates.filter(u => u.is_active);
    if (activeList.length === 0) return null;
    return [...activeList].sort((a, b) => (b.created_at || 0) - (a.created_at || 0))[0];
  }, [appUpdates]);

  const getLatestActiveAppUpdate = async (): Promise<AppUpdate | null> => {
    try {
      // 1. Try querying where is_active = true
      let { data, error } = await supabase
        .from('app_updates')
        .select('*')
        .eq('is_active', true)
        .order('created_at', { ascending: false })
        .limit(1);

      // 2. If none found or error, query the absolute latest update in app_updates table
      if (error || !data || data.length === 0) {
        const { data: allData, error: allError } = await supabase
          .from('app_updates')
          .select('*')
          .order('created_at', { ascending: false })
          .limit(1);
        if (!allError && allData && allData.length > 0) {
          data = allData;
        }
      }

      if (data && data.length > 0) {
        const latest = data[0] as AppUpdate;
        if (latest.apk_url && !latest.apk_url.startsWith('http')) {
          latest.apk_url = `${SUPABASE_URL}/storage/v1/object/public/app-apks/${latest.apk_url}`;
        }

        setAppUpdates(prev => {
          if (!prev.some(u => u.id === latest.id)) {
            return [latest, ...prev];
          }
          return prev.map(u => u.id === latest.id ? latest : u);
        });
        return latest;
      }
    } catch (err) {
      console.warn('Supabase getLatestActiveAppUpdate query notice:', err);
    }

    return latestActiveAppUpdate;
  };

  const downloadLatestApk = async (): Promise<{ success: boolean; update?: AppUpdate; error?: string }> => {
    try {
      const update = await getLatestActiveAppUpdate();
      if (!update || !update.apk_url) {
        return {
          success: false,
          error: 'لا يوجد إصدار منشور ومتاح للتحميل حالياً. يمكنك رفعه من لوحة التحكم.'
        };
      }

      let finalUrl = update.apk_url.trim();
      if (!finalUrl.startsWith('http')) {
        finalUrl = `${SUPABASE_URL}/storage/v1/object/public/app-apks/${finalUrl}`;
      }

      // Check for legacy broken dummy URL
      if (finalUrl.includes('releases/m3ak100_v1_0_0_code1.apk')) {
        return {
          success: false,
          error: 'لم يتم رفع ملف APK فعلي لهذا الإصدار في لوحة التحكم بعد. يرجى رفع ملف APK جديد من لوحة الإدارة.'
        };
      }

      // Trigger browser download via anchor element with proper download attribute
      const cleanVer = (update.version_name || 'latest').replace(/[^a-zA-Z0-9._-]/g, '_');
      const downloadFileName = `m3ak100_v${cleanVer}.apk`;

      const link = document.createElement('a');
      link.href = finalUrl;
      link.download = downloadFileName;
      link.target = '_blank';
      link.rel = 'noopener noreferrer';
      document.body.appendChild(link);
      link.click();
      setTimeout(() => {
        document.body.removeChild(link);
      }, 500);

      return { success: true, update };
    } catch (e: any) {
      console.error('Error downloading APK:', e);
      return { success: false, error: e?.message || 'تعذر بدء تحميل ملف التطبيق' };
    }
  };

  const activeCountries = countries.filter((c) => c.is_active);

  const setSelectedCountry = (code: string) => {
    const cleanCode = (!code || code === 'ALL') ? 'EG' : code;
    const target = countries.find((c) => c.code === cleanCode) || activeCountries[0] || countries[0] || DEFAULT_COUNTRIES[0];
    setSelectedCountryState(target.code);
    localStorage.setItem(STORAGE_KEYS.COUNTRY, target.code);
    setActiveCurrency(target.currency_name_ar || target.currency_code);
    setActiveCurrencySymbol(target.currency_symbol);
    if (target.order_fee !== undefined) {
      setOrderFee(target.order_fee);
    }
  };

  const isAdmin = Boolean(currentUser && currentUser.email?.trim().toLowerCase() === OWNER_EMAIL);

  // Sync to localStorage
  useEffect(() => {
    if (currentUser) {
      localStorage.setItem(STORAGE_KEYS.USER, JSON.stringify(currentUser));
    } else {
      localStorage.removeItem(STORAGE_KEYS.USER);
    }
  }, [currentUser]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.FAVORITES, JSON.stringify(favorites));
  }, [favorites]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.ORDERS, JSON.stringify(orders));
  }, [orders]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.PAYMENTS, JSON.stringify(payments));
  }, [payments]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.PRODUCTS, JSON.stringify(products));
  }, [products]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.PAYMENT_METHODS, JSON.stringify(paymentMethods));
  }, [paymentMethods]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.CHAT, JSON.stringify(chatMessages));
  }, [chatMessages]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.COUNTRIES, JSON.stringify(countries));
  }, [countries]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.APP_UPDATES, JSON.stringify(appUpdates));
  }, [appUpdates]);

  // Initial fetch from Supabase
  const syncWithSupabase = async () => {
    try {
      // 1. Products
      const { data: prods, error: pErr } = await supabase.from('products').select('*');
      if (!pErr && prods && prods.length > 0) {
        setProducts(prods);
        localStorage.setItem(STORAGE_KEYS.PRODUCTS, JSON.stringify(prods));
      }

      // 2. Payment Methods
      const { data: methods, error: mErr } = await supabase.from('payment_methods').select('*').order('display_order', { ascending: true });
      if (!mErr && methods && methods.length > 0) {
        setPaymentMethods(methods);
        localStorage.setItem(STORAGE_KEYS.PAYMENT_METHODS, JSON.stringify(methods));
      }

      // 3. Orders (Always fetch all if admin, or user-specific)
      let query = supabase.from('orders').select('*').order('created_at', { ascending: false });
      if (!isAdmin && currentUser) {
        query = query.eq('user_id', currentUser.id);
      }
      const { data: ords, error: oErr } = await query;
      if (!oErr && ords) {
        setOrders(ords);
        localStorage.setItem(STORAGE_KEYS.ORDERS, JSON.stringify(ords));
      }

      // 4. Payments (Always fetch all if admin, or user-specific)
      let pQuery = supabase.from('payments').select('*').order('created_at', { ascending: false });
      if (!isAdmin && currentUser) {
        pQuery = pQuery.eq('user_id', currentUser.id);
      }
      const { data: pays, error: payErr } = await pQuery;
      if (!payErr && pays) {
        setPayments(pays);
        localStorage.setItem(STORAGE_KEYS.PAYMENTS, JSON.stringify(pays));
      }

      // 5. App Updates
      try {
        const { data: updates, error: uErr } = await supabase
          .from('app_updates')
          .select('*')
          .order('created_at', { ascending: false });
        if (!uErr && updates && updates.length > 0) {
          setAppUpdates(updates);
          localStorage.setItem(STORAGE_KEYS.APP_UPDATES, JSON.stringify(updates));
        }
      } catch (err) {
        console.warn('Supabase app_updates sync note:', err);
      }

      // 6. Countries Sync
      try {
        const { data: dbCountries, error: cErr } = await supabase
          .from('countries')
          .select('*');
        if (!cErr && dbCountries && dbCountries.length > 0) {
          setCountries(dbCountries);
          localStorage.setItem(STORAGE_KEYS.COUNTRIES, JSON.stringify(dbCountries));
        }
      } catch (err) {
        console.warn('Supabase countries sync note:', err);
      }

      // 7. Settings
      const { data: setts } = await supabase.from('settings').select('*');
      if (setts) {
        setts.forEach((s: { key: string; value: string }) => {
          if (s.key === 'orderFee') setOrderFee(parseFloat(s.value) || 10);
          if (s.key === 'orderExpiryMinutes') setOrderExpiryMinutes(parseInt(s.value) || 30);
          if (s.key === 'currency') setActiveCurrency(s.value);
        });
      }
    } catch (e) {
      console.warn('Supabase initial fetch notice (using local storage fallback):', e);
    }
  };

  useEffect(() => {
    syncWithSupabase();

    // Auto-sync polling every 5 seconds to ensure 100% realtime sync across Web & Android App
    const pollInterval = setInterval(() => {
      syncWithSupabase();
    }, 5000);

    // Subscribe to Realtime live updates from Supabase (instant sync between Web & Mobile App)
    const channel = supabase
      .channel('m3ak100-live-sync')
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'products' },
        (payload) => {
          setLastLiveEvent({ table: 'products', type: payload.eventType, timestamp: Date.now() });
          if (payload.eventType === 'INSERT') {
            setProducts(prev => {
              if (prev.some(p => p.id === (payload.new as Product).id)) return prev;
              return [payload.new as Product, ...prev];
            });
          } else if (payload.eventType === 'UPDATE') {
            setProducts(prev => prev.map(p => p.id === (payload.new as Product).id ? (payload.new as Product) : p));
          } else if (payload.eventType === 'DELETE') {
            setProducts(prev => prev.filter(p => p.id !== (payload.old as any).id));
          }
        }
      )
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'orders' },
        (payload) => {
          setLastLiveEvent({ table: 'orders', type: payload.eventType, timestamp: Date.now() });
          if (payload.eventType === 'INSERT') {
            setOrders(prev => {
              if (prev.some(o => o.order_id === (payload.new as Order).order_id)) return prev;
              return [payload.new as Order, ...prev];
            });
          } else if (payload.eventType === 'UPDATE') {
            setOrders(prev => prev.map(o => o.order_id === (payload.new as Order).order_id ? (payload.new as Order) : o));
          } else if (payload.eventType === 'DELETE') {
            setOrders(prev => prev.filter(o => o.order_id !== (payload.old as any).order_id));
          }
        }
      )
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'payments' },
        (payload) => {
          setLastLiveEvent({ table: 'payments', type: payload.eventType, timestamp: Date.now() });
          if (payload.eventType === 'INSERT') {
            setPayments(prev => {
              if (prev.some(p => p.payment_id === (payload.new as Payment).payment_id)) return prev;
              return [payload.new as Payment, ...prev];
            });
          } else if (payload.eventType === 'UPDATE') {
            setPayments(prev => prev.map(p => p.payment_id === (payload.new as Payment).payment_id ? (payload.new as Payment) : p));
          } else if (payload.eventType === 'DELETE') {
            setPayments(prev => prev.filter(p => p.payment_id !== (payload.old as any).payment_id));
          }
        }
      )
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'payment_methods' },
        (payload) => {
          setLastLiveEvent({ table: 'payment_methods', type: payload.eventType, timestamp: Date.now() });
          if (payload.eventType === 'INSERT') {
            const item = payload.new as PaymentMethod;
            setPaymentMethods(prev => {
              let next: PaymentMethod[];
              if (prev.some(m => m.id === item.id)) {
                next = prev.map(m => m.id === item.id ? item : m);
              } else {
                next = [...prev, item];
              }
              localStorage.setItem(STORAGE_KEYS.PAYMENT_METHODS, JSON.stringify(next));
              return next;
            });
          } else if (payload.eventType === 'UPDATE') {
            const updated = payload.new as PaymentMethod;
            setPaymentMethods(prev => {
              const next = prev.map(m => m.id === updated.id ? updated : m);
              localStorage.setItem(STORAGE_KEYS.PAYMENT_METHODS, JSON.stringify(next));
              return next;
            });
          } else if (payload.eventType === 'DELETE') {
            const oldId = (payload.old as any)?.id;
            if (oldId) {
              setPaymentMethods(prev => {
                const next = prev.filter(m => m.id !== oldId);
                localStorage.setItem(STORAGE_KEYS.PAYMENT_METHODS, JSON.stringify(next));
                return next;
              });
            }
          }
        }
      )
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'app_updates' },
        (payload) => {
          setLastLiveEvent({ table: 'app_updates', type: payload.eventType, timestamp: Date.now() });
          if (payload.eventType === 'INSERT') {
            setAppUpdates(prev => {
              if (prev.some(u => u.id === (payload.new as AppUpdate).id)) return prev;
              return [payload.new as AppUpdate, ...prev];
            });
          } else if (payload.eventType === 'UPDATE') {
            setAppUpdates(prev => prev.map(u => u.id === (payload.new as AppUpdate).id ? (payload.new as AppUpdate) : u));
          } else if (payload.eventType === 'DELETE') {
            setAppUpdates(prev => prev.filter(u => u.id !== (payload.old as any).id));
          }
        }
      )
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'countries' },
        (payload) => {
          setLastLiveEvent({ table: 'countries', type: payload.eventType, timestamp: Date.now() });
          if (payload.eventType === 'INSERT') {
            setCountries(prev => {
              if (prev.some(c => c.code === (payload.new as Country).code)) return prev;
              return [...prev, payload.new as Country];
            });
          } else if (payload.eventType === 'UPDATE') {
            setCountries(prev => prev.map(c => c.code === (payload.new as Country).code ? (payload.new as Country) : c));
          } else if (payload.eventType === 'DELETE') {
            setCountries(prev => prev.filter(c => c.code !== (payload.old as any).code));
          }
        }
      )
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'settings' },
        (payload) => {
          setLastLiveEvent({ table: 'settings', type: payload.eventType, timestamp: Date.now() });
          if (payload.new) {
            const s = payload.new as { key: string; value: string };
            if (s.key === 'orderFee') setOrderFee(parseFloat(s.value) || 10);
            if (s.key === 'orderExpiryMinutes') setOrderExpiryMinutes(parseInt(s.value) || 30);
            if (s.key === 'currency') setActiveCurrency(s.value);
          }
        }
      )
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'chat_messages' },
        (payload) => {
          setLastLiveEvent({ table: 'chat_messages', type: payload.eventType, timestamp: Date.now() });
          if (payload.eventType === 'INSERT') {
            const msg = payload.new as ChatMessage;
            setChatMessages(prev => {
              if (prev.some(m => m.message_id === msg.message_id)) return prev;
              return [...prev, msg];
            });
          }
        }
      )
      .subscribe((status) => {
        if (status === 'SUBSCRIBED') {
          setIsLiveSyncConnected(true);
        } else if (status === 'CHANNEL_ERROR' || status === 'CLOSED') {
          setIsLiveSyncConnected(false);
        }
      });

    return () => {
      clearInterval(pollInterval);
      supabase.removeChannel(channel);
    };
  }, [currentUser?.id, isAdmin]);

  // Supabase Auth Listeners & Real-Time Auth State
  useEffect(() => {
    // Check active session from Supabase
    supabase.auth.getSession().then(({ data: { session } }) => {
      if (session?.user) {
        applySupabaseSessionUser(session.user);
      }
    }).catch(err => console.warn('Supabase session load error:', err));

    // Listen to real auth state changes (login, logout, token refresh)
    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      if (session?.user) {
        applySupabaseSessionUser(session.user);
      } else if (_event === 'SIGNED_OUT') {
        setCurrentUser(null);
        localStorage.removeItem(STORAGE_KEYS.USER);
      }
    });

    return () => {
      subscription.unsubscribe();
    };
  }, []);

  const applySupabaseSessionUser = (sbUser: any) => {
    const email = (sbUser.email || '').trim().toLowerCase();
    const isOwner = email === OWNER_EMAIL;
    const profile: UserProfile = {
      id: sbUser.id || (isOwner ? OWNER_UUID : 'usr_' + Math.random().toString(36).substring(2, 9)),
      name: sbUser.user_metadata?.full_name || sbUser.user_metadata?.name || (isOwner ? 'المالك والمدير العام 👑' : email.split('@')[0]),
      email: email,
      avatar_url: sbUser.user_metadata?.avatar_url || sbUser.user_metadata?.picture || (isOwner ? '' : `https://api.dicebear.com/7.x/initials/svg?seed=${email}`),
      is_admin: isOwner,
      role: isOwner ? 'admin' : 'user',
      created_at: sbUser.created_at ? new Date(sbUser.created_at).getTime() : Date.now()
    };
    setCurrentUser(profile);
    localStorage.setItem(STORAGE_KEYS.USER, JSON.stringify(profile));
  };

  // Real Google OAuth with Gmail Workspace support
  const signInWithGoogleReal = async () => {
    try {
      const { user: fbUser, accessToken } = await signInWithGoogleWorkspace();
      const email = (fbUser.email || '').trim().toLowerCase();
      const isOwner = email === OWNER_EMAIL;
      const profile: UserProfile = {
        id: fbUser.uid || (isOwner ? OWNER_UUID : 'usr_' + Math.random().toString(36).substring(2, 9)),
        name: isOwner ? 'المالك والمدير العام 👑' : (fbUser.displayName || email.split('@')[0] || 'مستخدم Google'),
        email: email,
        avatar_url: fbUser.photoURL || (isOwner ? '' : `https://api.dicebear.com/7.x/initials/svg?seed=${email}`),
        is_admin: isOwner,
        role: isOwner ? 'admin' : 'user',
        created_at: Date.now()
      };
      setCurrentUser(profile);
      localStorage.setItem(STORAGE_KEYS.USER, JSON.stringify(profile));
      setIsAuthModalOpen(false);

      // Persist to Supabase Database
      try {
        await supabase.from('users').upsert({
          id: profile.id,
          name: profile.name,
          email: profile.email,
          avatar_url: profile.avatar_url || '',
          is_admin: profile.is_admin,
          role: profile.role,
          country_code: selectedCountry,
          updated_at: new Date().toISOString()
        }, { onConflict: 'email' });
      } catch (e) {
        console.warn('User upsert notice:', e);
      }
    } catch (err: any) {
      console.warn('Google Workspace login popup notice:', err);
      // Fallback to Supabase OAuth redirect if needed
      try {
        const redirectUrl = window.location.origin;
        const { data, error } = await supabase.auth.signInWithOAuth({
          provider: 'google',
          options: {
            redirectTo: redirectUrl,
            queryParams: {
              prompt: 'select_account',
              access_type: 'offline'
            }
          }
        });
        if (error) throw error;
        if (data?.url) {
          window.location.href = data.url;
        }
      } catch (fallbackErr) {
        throw err;
      }
    }
  };

  // Auth Methods
  const loginWithGoogle = async (email?: string, name?: string) => {
    const userEmail = (email || '').trim().toLowerCase();
    const isOwner = userEmail === OWNER_EMAIL;
    const userProfile: UserProfile = {
      id: isOwner ? OWNER_UUID : 'usr_' + Math.random().toString(36).substring(2, 9),
      name: isOwner ? 'المالك والمدير العام 👑' : (name || (userEmail ? userEmail.split('@')[0] : 'مستخدم Google')),
      email: userEmail,
      avatar_url: isOwner ? '' : `https://api.dicebear.com/7.x/initials/svg?seed=${name || userEmail}`,
      is_admin: isOwner,
      role: isOwner ? 'admin' : 'user',
      created_at: Date.now()
    };
    setCurrentUser(userProfile);
    localStorage.setItem(STORAGE_KEYS.USER, JSON.stringify(userProfile));
    setIsAuthModalOpen(false);

    // Persist to Supabase Database (table 'users')
    try {
      await supabase.from('users').upsert({
        id: userProfile.id,
        name: userProfile.name,
        email: userProfile.email,
        avatar_url: userProfile.avatar_url || '',
        is_admin: userProfile.is_admin,
        role: userProfile.role,
        country_code: selectedCountry,
        updated_at: new Date().toISOString()
      }, { onConflict: 'email' });
    } catch (e) {
      console.warn('User upsert notice:', e);
    }
  };

  const loginWithEmail = async (email: string, pass: string): Promise<boolean> => {
    throw new Error('تسجيل الدخول بكلمة المرور ملغي تماماً لأسباب أمنية. يرجى تسجيل الدخول حصرياً عبر حساب Google.');
  };

  const signUpWithEmail = async (name: string, email: string, pass: string): Promise<boolean> => {
    throw new Error('إنشاء الحساب بكلمة المرور ملغي تماماً لأسباب أمنية. يرجى الدخول حصرياً عبر حساب Google.');
  };

  const logout = () => {
    supabase.auth.signOut().catch(() => {});
    logoutGoogle().catch(() => {});
    setCurrentUser(null);
    localStorage.removeItem(STORAGE_KEYS.USER);
    if (currentView === 'admin' || currentView === 'gmail') {
      setCurrentView('home');
    }
  };

  const setGuestUser = async () => {
    const randNumber = Math.floor(100000 + Math.random() * 900000);
    const guestId = `GST-${randNumber}`;
    const guestName = `زائر #${randNumber}`;
    const guestEmail = `guest_${randNumber}@m3ak100.com`;

    const guest: UserProfile = {
      id: guestId,
      name: guestName,
      email: guestEmail,
      avatar_url: `https://api.dicebear.com/7.x/initials/svg?seed=${randNumber}`,
      is_admin: false,
      role: 'guest',
      created_at: Date.now()
    };
    setCurrentUser(guest);
    localStorage.setItem(STORAGE_KEYS.USER, JSON.stringify(guest));
    setIsAuthModalOpen(false);

    try {
      await supabase.from('users').upsert({
        id: guest.id,
        name: guest.name,
        email: guest.email,
        avatar_url: guest.avatar_url || '',
        is_admin: false,
        role: 'guest',
        country_code: selectedCountry,
        updated_at: new Date().toISOString()
      }, { onConflict: 'email' });
    } catch (e) {
      console.warn('Guest upsert notice:', e);
    }
  };

  // Favorites
  const toggleFavorite = (productId: string) => {
    setFavorites(prev => {
      const exists = prev.includes(productId);
      const next = exists ? prev.filter(id => id !== productId) : [...prev, productId];
      // Sync with Supabase favorites if logged in
      if (currentUser && currentUser.role !== 'guest') {
        if (exists) {
          supabase.from('favorites').delete().eq('user_id', currentUser.id).eq('product_id', productId).then();
        } else {
          supabase.from('favorites').insert({
            id: `${currentUser.id}_${productId}`,
            user_id: currentUser.id,
            product_id: productId,
            created_at: Date.now()
          }).then();
        }
      }
      return next;
    });
  };

  // Orders
  const createOrder = async (product: Product): Promise<Order> => {
    const user = currentUser || {
      id: 'guest_' + Math.random().toString(36).substring(2, 9),
      name: 'عميل معاك 100',
      email: 'guest@m3ak100.com',
      is_admin: false,
      role: 'guest'
    };

    const dateStr = new Date().toISOString().slice(0, 10).replace(/-/g, '');
    const randSeq = Math.floor(100000 + Math.random() * 900000);
    const orderId = `FK-${dateStr}-${randSeq}`;
    const now = Date.now();
    const expiresAt = now + orderExpiryMinutes * 60 * 1000;

    const countryObj = countries.find(c => c.code === (product.country_code || selectedCountry)) || countries[0];
    const specificFee = countryObj?.order_fee !== undefined ? countryObj.order_fee : orderFee;

    const newOrder: Order = {
      order_id: orderId,
      user_id: user.id,
      user_name: user.name,
      user_phone: user.phone || '',
      product_id: product.id,
      product_name: product.name,
      product_image: product.image_url,
      product_price: product.price,
      order_fee: specificFee,
      payment_status: 'PENDING_PAYMENT',
      created_at: now,
      original_product_url: product.original_product_url,
      affiliate_url: product.affiliate_url,
      store_name: product.store_name,
      redirect_status: 'NotRedirected',
      expires_at: expiresAt,
      coupon_code: product.coupon_code || '',
      country_code: product.country_code || (selectedCountry !== 'ALL' ? selectedCountry : 'EG')
    };

    setOrders(prev => [newOrder, ...prev]);

    // Push to Supabase with robust upsert
    try {
      const { error: upsertErr } = await supabase.from('orders').upsert({
        order_id: newOrder.order_id,
        user_id: newOrder.user_id,
        user_name: newOrder.user_name,
        user_phone: newOrder.user_phone,
        product_id: newOrder.product_id,
        product_name: newOrder.product_name,
        product_image: newOrder.product_image,
        product_price: newOrder.product_price,
        order_fee: newOrder.order_fee,
        payment_status: newOrder.payment_status,
        created_at: newOrder.created_at,
        original_product_url: newOrder.original_product_url,
        affiliate_url: newOrder.affiliate_url,
        store_name: newOrder.store_name,
        redirect_status: newOrder.redirect_status,
        expires_at: newOrder.expires_at,
        coupon_code: newOrder.coupon_code
      }, { onConflict: 'order_id' });

      if (upsertErr) {
        console.error('Supabase order sync error:', upsertErr);
      }
    } catch (e) {
      console.warn('Order sync exception:', e);
    }

    return newOrder;
  };

  const deleteOrder = async (orderId: string) => {
    setOrders(prev => prev.filter(o => o.order_id !== orderId));
    setPayments(prev => prev.filter(p => p.order_id !== orderId));

    try {
      await supabase.from('payments').delete().eq('order_id', orderId);
      await supabase.from('orders').delete().eq('order_id', orderId);
    } catch (e) {
      console.warn('Order delete notice:', e);
    }
  };

  // Submit Payment
  const submitPayment = async (
    orderId: string,
    method: string,
    senderWallet: string,
    txnId: string,
    receiptImage: string
  ): Promise<boolean> => {
    const order = orders.find(o => o.order_id === orderId);
    if (!order) return false;

    const paymentId = 'PAY-' + Math.random().toString(36).substring(2, 9).toUpperCase();
    const now = Date.now();

    const newPayment: Payment = {
      payment_id: paymentId,
      order_id: orderId,
      user_id: order.user_id,
      user_name: order.user_name,
      user_email: currentUser?.email,
      user_phone: senderWallet,
      product_name: order.product_name,
      amount: order.order_fee,
      status: 'PAYMENT_REVIEW',
      payment_method: method,
      sender_wallet: senderWallet,
      transaction_id: txnId,
      transfer_date_time: new Date().toLocaleString('ar-EG'),
      receipt_image_url: receiptImage,
      created_at: now,
      expires_at: order.expires_at,
      country_code: order.country_code || (selectedCountry !== 'ALL' ? selectedCountry : 'EG')
    };

    setPayments(prev => [newPayment, ...prev]);

    // Update order status
    setOrders(prev => prev.map(o => o.order_id === orderId ? { ...o, payment_status: 'PAYMENT_REVIEW', user_phone: senderWallet } : o));

    // Save to Supabase
    try {
      console.log('Attempting to upsert payment with receipt URL length:', newPayment.receipt_image_url?.length);
      
      // Upload receipt to Supabase Storage if it's a data URL
      let uploadedReceiptUrl = newPayment.receipt_image_url;
      if (newPayment.receipt_image_url?.startsWith('data:')) {
          const response = await fetch(newPayment.receipt_image_url);
          const blob = await response.blob();
          const fileName = `receipts/${orderId}_${paymentId}.jpg`;
          
          const { data, error: uploadErr } = await supabase.storage
            .from('receipts')
            .upload(fileName, blob, { contentType: 'image/jpeg', upsert: true });
            
          if (uploadErr) {
              console.error('Supabase storage upload error:', uploadErr);
          } else {
              const { data: publicUrlData } = supabase.storage
                .from('receipts')
                .getPublicUrl(fileName);
              uploadedReceiptUrl = publicUrlData.publicUrl;
          }
      }

      const { error: payErr } = await supabase.from('payments').upsert({
        payment_id: newPayment.payment_id,
        order_id: newPayment.order_id,
        user_id: newPayment.user_id,
        user_name: newPayment.user_name,
        user_email: newPayment.user_email || '',
        user_phone: newPayment.user_phone || '',
        product_name: newPayment.product_name,
        amount: newPayment.amount,
        status: newPayment.status,
        payment_method: newPayment.payment_method,
        sender_wallet: newPayment.sender_wallet,
        transaction_id: newPayment.transaction_id,
        transfer_date_time: newPayment.transfer_date_time,
        receipt_image_url: uploadedReceiptUrl,
        created_at: newPayment.created_at,
        expires_at: newPayment.expires_at
      }, { onConflict: 'payment_id' });

      if (payErr) {
        console.error('Supabase payment sync error:', payErr);
      } else {
        console.log('Payment upsert successful');
      }

      const { error: ordUpErr } = await supabase.from('orders').update({
        payment_status: 'PAYMENT_REVIEW',
        user_phone: senderWallet
      }).eq('order_id', orderId);

      if (ordUpErr) {
        console.error('Supabase order update error:', ordUpErr);
      }
    } catch (e) {
      console.warn('Payment sync exception:', e);
    }

    return true;
  };

  const deletePayment = async (paymentId: string) => {
    const payment = payments.find(p => p.payment_id === paymentId);
    setPayments(prev => prev.filter(p => p.payment_id !== paymentId));

    if (payment) {
      setOrders(prev => prev.map(o => {
        if (o.order_id === payment.order_id && (o.payment_status === 'PAYMENT_REVIEW' || o.payment_status === 'REJECTED')) {
          return { ...o, payment_status: 'PENDING_PAYMENT' };
        }
        return o;
      }));

      try {
        await supabase.from('payments').delete().eq('payment_id', paymentId);
        await supabase.from('orders').update({ payment_status: 'PENDING_PAYMENT' }).eq('order_id', payment.order_id);
      } catch (e) {
        console.warn('Payment delete notice:', e);
      }
    } else {
      try {
        await supabase.from('payments').delete().eq('payment_id', paymentId);
      } catch (e) {
        console.warn('Payment delete notice:', e);
      }
    }
  };

  // Support Chat
  const sendChatMessage = async (text: string, orderId?: string) => {
    if (!text.trim()) return;
    const user = currentUser || { id: 'guest', name: 'عميل' };
    const now = Date.now();
    const newMsg: ChatMessage = {
      message_id: 'msg_' + Math.random().toString(36).substring(2, 9),
      conversation_id: user.id,
      order_id: orderId,
      sender_id: user.id,
      sender_name: user.name,
      sender_role: isAdmin ? 'ADMIN' : 'USER',
      message_text: text.trim(),
      timestamp: now,
      is_read: false
    };

    setChatMessages(prev => [...prev, newMsg]);

    try {
      await supabase.from('chat_messages').insert({
        message_id: newMsg.message_id,
        conversation_id: newMsg.conversation_id,
        order_id: newMsg.order_id || null,
        sender_id: newMsg.sender_id,
        sender_name: newMsg.sender_name,
        sender_role: newMsg.sender_role,
        message_text: newMsg.message_text,
        timestamp: newMsg.timestamp,
        is_read: false
      });
    } catch (e) {
      console.warn('Chat insert notice:', e);
    }
  };

  // Admin Actions
  const adminApprovePayment = async (paymentId: string, orderId: string) => {
    const now = Date.now();
    setPayments(prev => prev.map(p => p.payment_id === paymentId ? { ...p, status: 'APPROVED', reviewed_at: now, reviewed_by_admin_name: 'إدارة معاك 100' } : p));
    setOrders(prev => prev.map(o => o.order_id === orderId ? { ...o, payment_status: 'APPROVED' } : o));

    try {
      await supabase.from('payments').update({
        status: 'APPROVED',
        reviewed_at: now,
        reviewed_by_admin_name: 'إدارة معاك 100'
      }).eq('payment_id', paymentId);

      await supabase.from('orders').update({
        payment_status: 'APPROVED'
      }).eq('order_id', orderId);
    } catch (e) {
      console.warn('Payment approval notice:', e);
    }
  };

  const adminRejectPayment = async (paymentId: string, orderId: string, reason: string) => {
    const now = Date.now();
    setPayments(prev => prev.map(p => p.payment_id === paymentId ? { ...p, status: 'REJECTED', rejection_reason: reason, reviewed_at: now } : p));
    setOrders(prev => prev.map(o => o.order_id === orderId ? { ...o, payment_status: 'REJECTED', rejection_reason: reason } : o));

    try {
      await supabase.from('payments').update({
        status: 'REJECTED',
        rejection_reason: reason,
        reviewed_at: now
      }).eq('payment_id', paymentId);

      await supabase.from('orders').update({
        payment_status: 'REJECTED',
        rejection_reason: reason
      }).eq('order_id', orderId);
    } catch (e) {
      console.warn('Payment rejection notice:', e);
    }
  };

  const adminUpsertProduct = async (product: Product) => {
    setProducts(prev => {
      const idx = prev.findIndex(p => p.id === product.id);
      if (idx >= 0) {
        const next = [...prev];
        next[idx] = product;
        return next;
      }
      return [product, ...prev];
    });

    try {
      await supabase.from('products').upsert(product);
    } catch (e) {
      console.warn('Product upsert notice:', e);
    }
  };

  const adminDeleteProduct = async (productId: string) => {
    setProducts(prev => prev.filter(p => p.id !== productId));
    try {
      await supabase.from('products').delete().eq('id', productId);
    } catch (e) {
      console.warn('Product delete notice:', e);
    }
  };

  const adminToggleFeatured = async (productId: string) => {
    setProducts(prev => prev.map(p => {
      if (p.id === productId) {
        const updated = { ...p, is_featured: !p.is_featured };
        supabase.from('products').update({ is_featured: updated.is_featured }).eq('id', productId).then();
        return updated;
      }
      return p;
    }));
  };

  const adminUpsertPaymentMethod = async (method: PaymentMethod) => {
    setPaymentMethods(prev => {
      const idx = prev.findIndex(m => m.id === method.id);
      let next: PaymentMethod[];
      if (idx >= 0) {
        next = prev.map((m, i) => i === idx ? method : m);
      } else {
        next = [...prev, method];
      }
      localStorage.setItem(STORAGE_KEYS.PAYMENT_METHODS, JSON.stringify(next));
      return next;
    });

    try {
      await supabase.from('payment_methods').upsert(method, { onConflict: 'id' });
    } catch (e) {
      console.warn('Payment method upsert notice:', e);
    }
  };

  const adminDeletePaymentMethod = async (methodId: string) => {
    setPaymentMethods(prev => {
      const next = prev.filter(m => m.id !== methodId);
      localStorage.setItem(STORAGE_KEYS.PAYMENT_METHODS, JSON.stringify(next));
      return next;
    });
    try {
      await supabase.from('payment_methods').delete().eq('id', methodId);
    } catch (e) {
      console.warn('Payment method delete notice:', e);
    }
  };

  const adminTogglePaymentMethodActive = async (methodId: string) => {
    let newStatus = true;
    setPaymentMethods(prev => {
      const next = prev.map(m => {
        if (m.id === methodId) {
          newStatus = !m.is_enabled;
          return { ...m, is_enabled: !m.is_enabled };
        }
        return m;
      });
      localStorage.setItem(STORAGE_KEYS.PAYMENT_METHODS, JSON.stringify(next));
      return next;
    });

    try {
      await supabase.from('payment_methods').update({ is_enabled: newStatus }).eq('id', methodId);
    } catch (e) {
      console.warn('Payment method toggle notice:', e);
    }
  };

  const adminSeedPaymentMethodsToSupabase = async (): Promise<{ success: boolean; count?: number; error?: string }> => {
    try {
      const { error } = await supabase
        .from('payment_methods')
        .upsert(DEFAULT_PAYMENT_METHODS, { onConflict: 'id' });

      if (error) {
        return { success: false, error: error.message };
      }

      setPaymentMethods(prev => {
        const merged = [...DEFAULT_PAYMENT_METHODS];
        prev.forEach(p => {
          if (!merged.some(m => m.id === p.id)) {
            merged.push(p);
          }
        });
        localStorage.setItem(STORAGE_KEYS.PAYMENT_METHODS, JSON.stringify(merged));
        return merged;
      });

      return { success: true, count: DEFAULT_PAYMENT_METHODS.length };
    } catch (e: any) {
      return { success: false, error: e?.message || 'فشل المزامنة مع Supabase' };
    }
  };

  const adminToggleCountryActive = async (countryCode: string) => {
    let newStatus = true;
    setCountries(prev => {
      const next = prev.map(c => {
        if (c.code === countryCode) {
          newStatus = !c.is_active;
          return { ...c, is_active: !c.is_active };
        }
        return c;
      });
      localStorage.setItem(STORAGE_KEYS.COUNTRIES, JSON.stringify(next));

      // If current selectedCountry was disabled, fall back to first active country
      const currentActive = next.find(c => c.code === selectedCountry && c.is_active);
      if (!currentActive) {
        const firstActive = next.find(c => c.is_active);
        if (firstActive) {
          setSelectedCountry(firstActive.code);
        }
      }
      return next;
    });

    try {
      await supabase.from('countries').update({ is_active: newStatus }).eq('code', countryCode);
    } catch (e) {
      console.warn('Supabase country toggle update notice:', e);
    }
  };

  const adminUpsertCountry = async (country: Country) => {
    setCountries(prev => {
      const idx = prev.findIndex(c => c.code === country.code);
      const next = idx >= 0 ? prev.map((c, i) => i === idx ? country : c) : [...prev, country];
      localStorage.setItem(STORAGE_KEYS.COUNTRIES, JSON.stringify(next));
      return next;
    });

    try {
      await supabase.from('countries').upsert(country, { onConflict: 'code' });
    } catch (e) {
      console.warn('Supabase country upsert notice:', e);
    }
  };

  const adminDeleteCountry = async (countryCode: string) => {
    setCountries(prev => {
      const next = prev.filter(c => c.code !== countryCode);
      localStorage.setItem(STORAGE_KEYS.COUNTRIES, JSON.stringify(next));
      return next;
    });

    try {
      await supabase.from('countries').delete().eq('code', countryCode);
    } catch (e) {
      console.warn('Supabase country delete notice:', e);
    }
  };

  const adminSeedCountriesToSupabase = async (): Promise<{ success: boolean; count?: number; error?: string }> => {
    try {
      const { error } = await supabase.from('countries').upsert(DEFAULT_COUNTRIES, { onConflict: 'code' });
      if (error) {
        console.warn('Supabase countries seeding notice:', error.message);
        return { success: false, error: error.message };
      }
      setCountries(DEFAULT_COUNTRIES);
      localStorage.setItem(STORAGE_KEYS.COUNTRIES, JSON.stringify(DEFAULT_COUNTRIES));
      return { success: true, count: DEFAULT_COUNTRIES.length };
    } catch (e: any) {
      return { success: false, error: e?.message || 'فشلت تهيئة الدول' };
    }
  };

  const adminUpdateSettings = async (newFee: number, newExpiry: number, currency: string) => {
    setOrderFee(newFee);
    setOrderExpiryMinutes(newExpiry);
    setActiveCurrency(currency);

    try {
      await supabase.from('settings').upsert([
        { key: 'orderFee', value: newFee.toString() },
        { key: 'orderExpiryMinutes', value: newExpiry.toString() },
        { key: 'currency', value: currency }
      ]);
    } catch (e) {
      console.warn('Settings update notice:', e);
    }
  };

  const adminUploadApk = async (
    file: File,
    versionName: string,
    versionCode: number,
    title: string,
    description: string,
    isActive: boolean = true
  ): Promise<{ success: boolean; error?: string; update?: AppUpdate }> => {
    try {
      if (!file) {
        return { success: false, error: 'لم يتم اختيار أي ملف للرفع' };
      }

      // 1. Run browser-side binary APK inspection & compatibility check
      const analysis = await validateAndAnalyzeApkFile(file, versionName);
      if (!analysis.isValidApk) {
        return {
          success: false,
          error: 'الملف المحدد ليس حزمة أندرويد APK صالحة. يرجى التأكد من اختيار ملف حقيقي بصيغة .apk'
        };
      }

      const cleanFileName = sanitizeApkFileName(file.name, versionName);
      const filePath = `releases/${Date.now()}_${cleanFileName}`;

      console.log(`[Supabase Storage] Starting APK upload to bucket 'app-apks': ${filePath} (${analysis.fileSizeMb} MB)...`);

      // 2. Execute actual upload to Supabase Storage bucket 'app-apks'
      const { data: uploadData, error: uploadErr } = await supabase.storage
        .from('app-apks')
        .upload(filePath, file, {
          contentType: 'application/vnd.android.package-archive',
          cacheControl: '3600',
          upsert: true
        });

      // 3. Strict verification: halt if upload fails
      if (uploadErr || !uploadData) {
        console.error('[Supabase Storage] APK upload failed:', uploadErr);
        const rawMsg = uploadErr?.message || 'تعذر إتمام عملية الرفع إلى Storage';
        let friendlyError = `فشل في رفع ملف الـ APK إلى Supabase Storage: ${rawMsg}`;
        if (rawMsg.toLowerCase().includes('bucket not found')) {
          friendlyError = `حاوية التخزين (Bucket) باسم 'app-apks' غير موجودة في مشروع Supabase. يرجى إنشاء Bucket باسم app-apks وجعله Public في لوحة Supabase.`;
        } else if (rawMsg.toLowerCase().includes('row-level security') || rawMsg.toLowerCase().includes('policy')) {
          friendlyError = `سياسة الأمان (RLS Policy) تمنع الرفع لحاوية app-apks. يرجى تطبيق كود SQL الموضح في لوحة التحكم لإعطاء صلاحيات الرفع والتحميل.`;
        }
        return { success: false, error: friendlyError };
      }

      console.log('[Supabase Storage] APK uploaded successfully:', uploadData);

      // 4. Obtain public URL only AFTER successful upload
      const { data: publicUrlData } = supabase.storage
        .from('app-apks')
        .getPublicUrl(filePath);

      if (!publicUrlData || !publicUrlData.publicUrl) {
        return {
          success: false,
          error: 'تم رفع الملف ولكن تعذر استخراج الرابط العام (Public URL) من Supabase Storage'
        };
      }

      const apkUrl = publicUrlData.publicUrl;
      const updateId = 'update_' + Date.now() + '_' + Math.random().toString(36).substring(2, 7);
      const now = Date.now();

      // Deactivate others if this is set to active
      if (isActive) {
        setAppUpdates(prev => prev.map(u => ({ ...u, is_active: false })));
        try {
          await supabase.from('app_updates').update({ is_active: false }).neq('id', updateId);
        } catch {}
      }

      const newUpdate: AppUpdate = {
        id: updateId,
        version_name: versionName.trim(),
        version_code: versionCode,
        apk_url: apkUrl,
        update_title: title.trim(),
        update_description: description.trim(),
        is_active: isActive,
        created_at: now,
        file_size_mb: analysis.fileSizeMb
      };

      // 5. Save release record to Supabase table 'app_updates'
      try {
        const { error: dbErr } = await supabase.from('app_updates').upsert({
          id: newUpdate.id,
          version_name: newUpdate.version_name,
          version_code: newUpdate.version_code,
          apk_url: newUpdate.apk_url,
          update_title: newUpdate.update_title,
          update_description: newUpdate.update_description,
          is_active: newUpdate.is_active,
          created_at: newUpdate.created_at,
          file_size_mb: newUpdate.file_size_mb
        }, { onConflict: 'id' });

        if (dbErr) {
          console.warn('Supabase app_updates table upsert note (table might need creation):', dbErr.message);
        }
      } catch (err) {
        console.warn('Failed to upsert to app_updates table:', err);
      }

      // 6. Update local state
      setAppUpdates(prev => [newUpdate, ...prev.filter(u => u.id !== newUpdate.id)]);
      localStorage.setItem(STORAGE_KEYS.APP_UPDATES, JSON.stringify([newUpdate, ...appUpdates]));

      return { success: true, update: newUpdate };
    } catch (e: any) {
      console.error('adminUploadApk exception:', e);
      return { success: false, error: e?.message || 'حدث خطأ غير متوقع أثناء معالجة رفع ملف APK' };
    }
  };

  const adminPublishCustomApkUrl = async (
    apkUrl: string,
    versionName: string,
    versionCode: number,
    title: string,
    description: string,
    isActive: boolean = true,
    fileSizeMb?: number
  ): Promise<{ success: boolean; error?: string; update?: AppUpdate }> => {
    try {
      if (!apkUrl.trim() || !apkUrl.startsWith('http')) {
        return { success: false, error: 'يرجى إدخال رابط مباشر صالح يبدأ بـ https://' };
      }

      const updateId = 'update_' + Date.now() + '_' + Math.random().toString(36).substring(2, 7);
      const now = Date.now();

      if (isActive) {
        setAppUpdates(prev => prev.map(u => ({ ...u, is_active: false })));
        try {
          await supabase.from('app_updates').update({ is_active: false }).neq('id', updateId);
        } catch {}
      }

      const newUpdate: AppUpdate = {
        id: updateId,
        version_name: versionName.trim(),
        version_code: versionCode,
        apk_url: apkUrl.trim(),
        update_title: title.trim(),
        update_description: description.trim(),
        is_active: isActive,
        created_at: now,
        file_size_mb: fileSizeMb || 18.0
      };

      try {
        const { error: dbErr } = await supabase.from('app_updates').upsert({
          id: newUpdate.id,
          version_name: newUpdate.version_name,
          version_code: newUpdate.version_code,
          apk_url: newUpdate.apk_url,
          update_title: newUpdate.update_title,
          update_description: newUpdate.update_description,
          is_active: newUpdate.is_active,
          created_at: newUpdate.created_at,
          file_size_mb: newUpdate.file_size_mb
        }, { onConflict: 'id' });

        if (dbErr) {
          console.warn('Supabase app_updates custom URL upsert note:', dbErr.message);
        }
      } catch (err) {
        console.warn('Failed to upsert custom URL to app_updates table:', err);
      }

      setAppUpdates(prev => [newUpdate, ...prev.filter(u => u.id !== newUpdate.id)]);
      localStorage.setItem(STORAGE_KEYS.APP_UPDATES, JSON.stringify([newUpdate, ...appUpdates]));

      return { success: true, update: newUpdate };
    } catch (e: any) {
      return { success: false, error: e?.message || 'تعذر حفظ الرابط المباشر' };
    }
  };

  const adminToggleAppUpdateActive = async (updateId: string) => {
    let newStatus = true;
    setAppUpdates(prev => prev.map(u => {
      if (u.id === updateId) {
        newStatus = !u.is_active;
        return { ...u, is_active: newStatus };
      }
      return u;
    }));

    try {
      await supabase.from('app_updates').update({ is_active: newStatus }).eq('id', updateId);
    } catch (e) {
      console.warn('App update toggle notice:', e);
    }
  };

  const adminDeleteAppUpdate = async (updateId: string) => {
    setAppUpdates(prev => prev.filter(u => u.id !== updateId));
    try {
      await supabase.from('app_updates').delete().eq('id', updateId);
    } catch (e) {
      console.warn('App update delete notice:', e);
    }
  };

  return (
    <AppContext.Provider
      value={{
        currentView,
        setCurrentView,
        products,
        categories,
        budgets,
        stores,
        countries,
        activeCountries,
        paymentMethods,
        orders,
        payments,
        chatMessages,
        favorites,
        appUpdates,
        currentUser,
        isAdmin,
        signInWithGoogleReal,
        loginWithGoogle,
        loginWithEmail,
        signUpWithEmail,
        logout,
        setGuestUser,
        selectedBudget,
        setSelectedBudget,
        selectedCategory,
        setSelectedCategory,
        selectedStore,
        setSelectedStore,
        searchQuery,
        setSearchQuery,
        selectedCountry,
        setSelectedCountry,
        activeCurrency,
        activeCurrencySymbol,
        orderFee,
        orderExpiryMinutes,
        toggleFavorite,
        createOrder,
        deleteOrder,
        submitPayment,
        deletePayment,
        sendChatMessage,
        adminApprovePayment,
        adminRejectPayment,
        adminUpsertProduct,
        adminDeleteProduct,
        adminToggleFeatured,
        adminUpsertPaymentMethod,
        adminDeletePaymentMethod,
        adminTogglePaymentMethodActive,
        adminSeedPaymentMethodsToSupabase,
        isLiveSyncConnected,
        lastLiveEvent,
        adminToggleCountryActive,
        adminUpsertCountry,
        adminDeleteCountry,
        adminUpdateSettings,
        adminUploadApk,
        adminPublishCustomApkUrl,
        adminToggleAppUpdateActive,
        adminDeleteAppUpdate,
        adminSeedCountriesToSupabase,
        syncWithSupabase,
        getLatestActiveAppUpdate,
        downloadLatestApk,
        latestActiveAppUpdate,
        isAuthModalOpen,
        setIsAuthModalOpen,
        isDownloadModalOpen,
        setIsDownloadModalOpen,
        activeProductModal,
        setActiveProductModal,
        activeOrderModal,
        setActiveOrderModal,
        isChatModalOpen,
        setIsChatModalOpen
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
