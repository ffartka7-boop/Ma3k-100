export interface Product {
  id: string;
  name: string;
  image_url: string;
  additional_images_json?: string;
  price: number;
  description: string;
  category_id: string;
  budget: number;
  store_name: string;
  store_logo?: string;
  original_product_url: string;
  affiliate_url: string;
  is_featured: boolean;
  is_available: boolean;
  views_count?: number;
  order_count?: number;
  country_code?: string;
  coupon_code?: string;
  created_at?: number | string;
  updated_at?: number | string;
}

export interface Category {
  id: string;
  name: string;
  icon: string;
  is_active: boolean;
}

export interface Budget {
  amount: number;
  title: string;
  is_active: boolean;
}

export interface Store {
  id: string;
  name: string;
  logo: string;
  website_url: string;
  is_active: boolean;
}

export interface Country {
  code: string;
  name_ar: string;
  full_name_ar?: string;
  flag_emoji: string;
  currency_code: string;
  currency_symbol: string;
  currency_name_ar?: string;
  order_fee?: number;
  is_active: boolean;
  is_default: boolean;
}

export interface Order {
  order_id: string;
  user_id: string;
  user_name: string;
  user_phone: string;
  product_id: string;
  product_name: string;
  product_image: string;
  product_price: number;
  order_fee: number;
  payment_status: 'PENDING_PAYMENT' | 'PAYMENT_REVIEW' | 'APPROVED' | 'REJECTED' | 'EXPIRED' | 'Paid';
  created_at: number;
  original_product_url: string;
  affiliate_url: string;
  store_name: string;
  redirect_status?: string;
  expires_at?: number;
  rejection_reason?: string;
  coupon_code?: string;
  country_code?: string;
}

export interface Payment {
  payment_id: string;
  order_id: string;
  user_id: string;
  user_name: string;
  user_email?: string;
  user_phone?: string;
  product_name: string;
  amount: number;
  status: 'PENDING_PAYMENT' | 'PAYMENT_REVIEW' | 'APPROVED' | 'REJECTED' | 'EXPIRED';
  payment_method: string;
  sender_wallet: string;
  transaction_id: string;
  transfer_date_time: string;
  receipt_image_url: string;
  rejection_reason?: string;
  reviewed_by_admin_id?: string;
  reviewed_by_admin_name?: string;
  reviewed_at?: number;
  created_at: number;
  expires_at?: number;
  country_code?: string;
}

export interface PaymentMethod {
  id: string;
  name: string;
  wallet_number: string;
  owner_name: string;
  instructions: string;
  icon_type: string;
  is_enabled: boolean;
  min_amount?: number;
  max_amount?: number;
  display_order?: number;
  country_code?: string;
}

export interface ChatMessage {
  message_id: string;
  conversation_id: string;
  order_id?: string;
  sender_id: string;
  sender_name: string;
  sender_role: 'USER' | 'ADMIN';
  message_text: string;
  timestamp: number;
  is_read: boolean;
}

export interface UserProfile {
  id: string;
  name: string;
  email: string;
  avatar_url?: string;
  phone?: string;
  is_admin: boolean;
  role: string;
  created_at?: number;
}

export interface ModeratorUser {
  email: string;
  name?: string;
  added_at: number;
  added_by?: string;
  role: 'moderator';
}

export interface AppUpdate {
  id: string;
  version_name: string;
  version_code: number;
  apk_url: string;
  update_title: string;
  update_description: string;
  is_active: boolean;
  created_at: number | string;
  file_size_mb?: number;
}

export type AppView = 'home' | 'products' | 'favorites' | 'orders' | 'about' | 'admin' | 'gmail';
