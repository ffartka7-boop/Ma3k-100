export interface CountryDetails {
  code: string;
  name: string;
  fullName: string;
  flag: string;
  currencyCode: string;
  currencySymbol: string;
  currencyName: string;
  defaultFee: number;
}

export const COUNTRIES_DATABASE: Record<string, CountryDetails> = {
  EG: {
    code: 'EG',
    name: 'مصر',
    fullName: 'جمهورية مصر العربية',
    flag: '🇪🇬',
    currencyCode: 'EGP',
    currencySymbol: 'ج.م',
    currencyName: 'جنيه',
    defaultFee: 10,
  },
  SA: {
    code: 'SA',
    name: 'السعودية',
    fullName: 'المملكة العربية السعودية',
    flag: '🇸🇦',
    currencyCode: 'SAR',
    currencySymbol: 'ر.س',
    currencyName: 'ريال',
    defaultFee: 10,
  },
  AE: {
    code: 'AE',
    name: 'الإمارات',
    fullName: 'الإمارات العربية المتحدة',
    flag: '🇦🇪',
    currencyCode: 'AED',
    currencySymbol: 'د.إ',
    currencyName: 'درهم',
    defaultFee: 10,
  },
  KW: {
    code: 'KW',
    name: 'الكويت',
    fullName: 'دولة الكويت',
    flag: '🇰🇼',
    currencyCode: 'KWD',
    currencySymbol: 'د.ك',
    currencyName: 'دينار كويتي',
    defaultFee: 1,
  },
  QA: {
    code: 'QA',
    name: 'قطر',
    fullName: 'دولة قطر',
    flag: '🇶🇦',
    currencyCode: 'QAR',
    currencySymbol: 'ر.ق',
    currencyName: 'ريال قطري',
    defaultFee: 10,
  },
  BH: {
    code: 'BH',
    name: 'البحرين',
    fullName: 'مملكة البحرين',
    flag: '🇧🇭',
    currencyCode: 'BHD',
    currencySymbol: 'د.ب',
    currencyName: 'دينار بحريني',
    defaultFee: 1,
  },
  OM: {
    code: 'OM',
    name: 'عُمان',
    fullName: 'سلطنة عُمان',
    flag: '🇴🇲',
    currencyCode: 'OMR',
    currencySymbol: 'ر.ع',
    currencyName: 'ريال عماني',
    defaultFee: 1,
  },
  JO: {
    code: 'JO',
    name: 'الأردن',
    fullName: 'المملكة الأردنية الهاشمية',
    flag: '🇯🇴',
    currencyCode: 'JOD',
    currencySymbol: 'د.أ',
    currencyName: 'دينار أردني',
    defaultFee: 2,
  },
  IQ: {
    code: 'IQ',
    name: 'العراق',
    fullName: 'جمهورية العراق',
    flag: '🇮🇶',
    currencyCode: 'IQD',
    currencySymbol: 'د.ع',
    currencyName: 'دينار عراقي',
    defaultFee: 5000,
  },
  MA: {
    code: 'MA',
    name: 'المغرب',
    fullName: 'المملكة المغربية',
    flag: '🇲🇦',
    currencyCode: 'MAD',
    currencySymbol: 'د.م',
    currencyName: 'درهم مغربي',
    defaultFee: 25,
  },
  DZ: {
    code: 'DZ',
    name: 'الجزائر',
    fullName: 'الجمهورية الجزائرية',
    flag: '🇩🇿',
    currencyCode: 'DZD',
    currencySymbol: 'د.ج',
    currencyName: 'دينار جزائري',
    defaultFee: 500,
  },
  TN: {
    code: 'TN',
    name: 'تونس',
    fullName: 'الجمهورية التونسية',
    flag: '🇹🇳',
    currencyCode: 'TND',
    currencySymbol: 'د.ت',
    currencyName: 'دينار تونسي',
    defaultFee: 5,
  },
  LY: {
    code: 'LY',
    name: 'ليبيا',
    fullName: 'دولة ليبيا',
    flag: '🇱🇾',
    currencyCode: 'LYD',
    currencySymbol: 'د.ل',
    currencyName: 'دينار ليبي',
    defaultFee: 10,
  },
  LB: {
    code: 'LB',
    name: 'لبنان',
    fullName: 'الجمهورية اللبنانية',
    flag: '🇱🇧',
    currencyCode: 'LBP',
    currencySymbol: 'ل.ل',
    currencyName: 'ليرة لبنانية',
    defaultFee: 100000,
  }
};

export const getCountryDetails = (countryCode?: string): CountryDetails => {
  const code = (countryCode || 'EG').toUpperCase();
  if (COUNTRIES_DATABASE[code]) {
    return COUNTRIES_DATABASE[code];
  }
  return COUNTRIES_DATABASE['EG'];
};
