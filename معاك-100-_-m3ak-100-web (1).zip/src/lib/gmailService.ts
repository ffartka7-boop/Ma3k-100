import { getCachedAccessToken } from './googleAuth';

export interface GmailUserProfile {
  emailAddress: string;
  messagesTotal: number;
  threadsTotal: number;
  historyId: string;
}

export interface GmailMessageHeader {
  name: string;
  value: string;
}

export interface GmailMessageSummary {
  id: string;
  threadId: string;
  snippet: string;
  subject: string;
  from: string;
  to: string;
  date: string;
  unread: boolean;
  starred: boolean;
  labelIds: string[];
}

export interface GmailMessageDetail extends GmailMessageSummary {
  body: string;
  htmlBody?: string;
  headers: GmailMessageHeader[];
}

export interface GmailLabel {
  id: string;
  name: string;
  type: string;
  messagesTotal?: number;
  messagesUnread?: number;
}

const GMAIL_BASE_URL = 'https://gmail.googleapis.com/gmail/v1/users/me';

// Base64url helper for RFC 2822 emails
function encodeBase64Url(str: string): string {
  const utf8Bytes = encodeURIComponent(str).replace(/%([0-9A-F]{2})/g, (_, p1) =>
    String.fromCharCode(parseInt(p1, 16))
  );
  return btoa(utf8Bytes).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
}

function decodeBase64Url(base64UrlStr: string): string {
  try {
    let base64 = base64UrlStr.replace(/-/g, '+').replace(/_/g, '/');
    while (base64.length % 4) {
      base64 += '=';
    }
    const decoded = atob(base64);
    return decodeURIComponent(
      Array.prototype.map
        .call(decoded, (c: string) => '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2))
        .join('')
    );
  } catch (e) {
    try {
      return atob(base64UrlStr.replace(/-/g, '+').replace(/_/g, '/'));
    } catch {
      return '';
    }
  }
}

export async function fetchGmailProfile(token?: string): Promise<GmailUserProfile> {
  const accessToken = token || getCachedAccessToken();
  if (!accessToken) throw new Error('مطلوب تسجيل الدخول بحساب Google للوصول لخدمة Gmail.');

  const res = await fetch(`${GMAIL_BASE_URL}/profile`, {
    headers: { Authorization: `Bearer ${accessToken}` }
  });

  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error?.message || `فشل جلب بيانات الحساب (${res.status})`);
  }

  return res.json();
}

export async function fetchGmailLabels(token?: string): Promise<GmailLabel[]> {
  const accessToken = token || getCachedAccessToken();
  if (!accessToken) throw new Error('مطلوب تسجيل الدخول بحساب Google للوصول لخدمة Gmail.');

  const res = await fetch(`${GMAIL_BASE_URL}/labels`, {
    headers: { Authorization: `Bearer ${accessToken}` }
  });

  if (!res.ok) {
    throw new Error(`فشل جلب التصنيفات (${res.status})`);
  }

  const data = await res.json();
  return data.labels || [];
}

export async function listGmailMessages(
  options: {
    q?: string;
    labelIds?: string[];
    maxResults?: number;
    pageToken?: string;
  } = {},
  token?: string
): Promise<{ messages: GmailMessageSummary[]; nextPageToken?: string; resultSizeEstimate?: number }> {
  const accessToken = token || getCachedAccessToken();
  if (!accessToken) throw new Error('مطلوب تسجيل الدخول بحساب Google للوصول لخدمة Gmail.');

  const params = new URLSearchParams();
  if (options.q) params.set('q', options.q);
  if (options.maxResults) params.set('maxResults', String(options.maxResults));
  if (options.pageToken) params.set('pageToken', options.pageToken);
  if (options.labelIds && options.labelIds.length > 0) {
    options.labelIds.forEach((lbl) => params.append('labelIds', lbl));
  }

  const url = `${GMAIL_BASE_URL}/messages?${params.toString()}`;
  const res = await fetch(url, {
    headers: { Authorization: `Bearer ${accessToken}` }
  });

  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error?.message || `فشل استرجاع الرسائل (${res.status})`);
  }

  const data = await res.json();
  const rawList: { id: string; threadId: string }[] = data.messages || [];

  if (rawList.length === 0) {
    return { messages: [], nextPageToken: data.nextPageToken, resultSizeEstimate: 0 };
  }

  // Fetch summaries in parallel for fast rendering (up to 15 at a time)
  const summaries = await Promise.all(
    rawList.slice(0, 20).map(async (item) => {
      try {
        const detailRes = await fetch(
          `${GMAIL_BASE_URL}/messages/${item.id}?format=metadata&metadataHeaders=Subject&metadataHeaders=From&metadataHeaders=To&metadataHeaders=Date`,
          {
            headers: { Authorization: `Bearer ${accessToken}` }
          }
        );
        if (!detailRes.ok) return null;
        const detail = await detailRes.json();
        const headers: GmailMessageHeader[] = detail.payload?.headers || [];

        const getHeader = (name: string) =>
          headers.find((h) => h.name.toLowerCase() === name.toLowerCase())?.value || '';

        const labelIds: string[] = detail.labelIds || [];
        const unread = labelIds.includes('UNREAD');
        const starred = labelIds.includes('STARRED');

        return {
          id: detail.id,
          threadId: detail.threadId,
          snippet: detail.snippet || '',
          subject: getHeader('Subject') || '(بدون عنوان)',
          from: getHeader('From') || 'غير معروف',
          to: getHeader('To') || '',
          date: getHeader('Date') || '',
          unread,
          starred,
          labelIds
        } as GmailMessageSummary;
      } catch {
        return null;
      }
    })
  );

  return {
    messages: summaries.filter((m): m is GmailMessageSummary => m !== null),
    nextPageToken: data.nextPageToken,
    resultSizeEstimate: data.resultSizeEstimate
  };
}

export async function getGmailMessageDetail(messageId: string, token?: string): Promise<GmailMessageDetail> {
  const accessToken = token || getCachedAccessToken();
  if (!accessToken) throw new Error('مطلوب تسجيل الدخول بحساب Google للوصول لخدمة Gmail.');

  const res = await fetch(`${GMAIL_BASE_URL}/messages/${messageId}?format=full`, {
    headers: { Authorization: `Bearer ${accessToken}` }
  });

  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error?.message || `فشل قراءة الرسالة (${res.status})`);
  }

  const detail = await res.json();
  const headers: GmailMessageHeader[] = detail.payload?.headers || [];

  const getHeader = (name: string) =>
    headers.find((h) => h.name.toLowerCase() === name.toLowerCase())?.value || '';

  let body = '';
  let htmlBody = '';

  const extractBodyParts = (part: any) => {
    if (!part) return;
    if (part.mimeType === 'text/plain' && part.body?.data) {
      body += decodeBase64Url(part.body.data) + '\n';
    } else if (part.mimeType === 'text/html' && part.body?.data) {
      htmlBody += decodeBase64Url(part.body.data) + '\n';
    }

    if (part.parts && Array.isArray(part.parts)) {
      part.parts.forEach(extractBodyParts);
    }
  };

  extractBodyParts(detail.payload);

  if (!body && detail.payload?.body?.data) {
    body = decodeBase64Url(detail.payload.body.data);
  }

  const labelIds: string[] = detail.labelIds || [];
  const unread = labelIds.includes('UNREAD');
  const starred = labelIds.includes('STARRED');

  return {
    id: detail.id,
    threadId: detail.threadId,
    snippet: detail.snippet || '',
    subject: getHeader('Subject') || '(بدون عنوان)',
    from: getHeader('From') || 'غير معروف',
    to: getHeader('To') || '',
    date: getHeader('Date') || '',
    unread,
    starred,
    labelIds,
    body: body.trim() || detail.snippet || '',
    htmlBody: htmlBody.trim() || undefined,
    headers
  };
}

export async function sendGmailEmail(
  {
    to,
    subject,
    body,
    html
  }: {
    to: string;
    subject: string;
    body: string;
    html?: string;
  },
  token?: string
): Promise<{ id: string; threadId: string }> {
  const accessToken = token || getCachedAccessToken();
  if (!accessToken) throw new Error('مطلوب تسجيل الدخول بحساب Google لإرسال البريد.');

  const emailLines = [
    `To: ${to}`,
    `Subject: =?utf-8?B?${btoa(encodeURIComponent(subject))}?=`,
    'MIME-Version: 1.0',
    html ? 'Content-Type: text/html; charset=utf-8' : 'Content-Type: text/plain; charset=utf-8',
    '',
    html || body
  ];

  const raw = encodeBase64Url(emailLines.join('\r\n'));

  const res = await fetch(`${GMAIL_BASE_URL}/messages/send`, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${accessToken}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({ raw })
  });

  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error?.message || `فشل إرسال البريد (${res.status})`);
  }

  return res.json();
}

export async function createGmailDraft(
  {
    to,
    subject,
    body
  }: {
    to: string;
    subject: string;
    body: string;
  },
  token?: string
): Promise<{ id: string; message: any }> {
  const accessToken = token || getCachedAccessToken();
  if (!accessToken) throw new Error('مطلوب تسجيل الدخول بحساب Google لحفظ المسودة.');

  const emailLines = [
    `To: ${to}`,
    `Subject: =?utf-8?B?${btoa(encodeURIComponent(subject))}?=`,
    'MIME-Version: 1.0',
    'Content-Type: text/plain; charset=utf-8',
    '',
    body
  ];

  const raw = encodeBase64Url(emailLines.join('\r\n'));

  const res = await fetch(`${GMAIL_BASE_URL}/drafts`, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${accessToken}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      message: { raw }
    })
  });

  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error?.message || `فشل حفظ المسودة (${res.status})`);
  }

  return res.json();
}

export async function trashGmailMessage(messageId: string, token?: string): Promise<void> {
  const accessToken = token || getCachedAccessToken();
  if (!accessToken) throw new Error('مطلوب تسجيل الدخول بحساب Google لحذف الرسالة.');

  const res = await fetch(`${GMAIL_BASE_URL}/messages/${messageId}/trash`, {
    method: 'POST',
    headers: { Authorization: `Bearer ${accessToken}` }
  });

  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error?.message || `فشل نقل الرسالة إلى سلة المهملات (${res.status})`);
  }
}

export async function modifyGmailMessageLabels(
  messageId: string,
  addLabelIds: string[] = [],
  removeLabelIds: string[] = [],
  token?: string
): Promise<void> {
  const accessToken = token || getCachedAccessToken();
  if (!accessToken) throw new Error('مطلوب تسجيل الدخول بحساب Google.');

  const res = await fetch(`${GMAIL_BASE_URL}/messages/${messageId}/modify`, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${accessToken}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      addLabelIds,
      removeLabelIds
    })
  });

  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error?.message || 'فشل تحديث حالة الرسالة');
  }
}
