import React from 'react';
import { useApp } from '../context/AppContext';
import { Phone, MessageCircle, Shield, Mail, FileSpreadsheet, Smartphone, Download } from 'lucide-react';

export const Footer: React.FC = () => {
  const { setCurrentView, setIsChatModalOpen, setIsDownloadModalOpen, latestActiveAppUpdate } = useApp();

  return (
    <footer className="bg-[#0B0B0B] border-t border-[#222222] pt-14 pb-8 text-zinc-400">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-12">
          
          {/* Brand Info & App Download Button */}
          <div className="space-y-4">
            <div className="flex items-center gap-3 cursor-pointer" onClick={() => setCurrentView('home')}>
              <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-[#FF3344] to-[#B8000A] flex items-center justify-center p-[2px]">
                <div className="w-full h-full bg-[#0B0B0B]/40 rounded-2xl flex flex-col items-center justify-center">
                  <span className="text-white font-black text-xs leading-none">100</span>
                </div>
              </div>
              <div>
                <span className="text-white font-black text-lg">معاك 100</span>
                <span className="text-[#FF3344] text-[10px] font-bold block">M3AK 100</span>
              </div>
            </div>

            <p className="text-xs leading-relaxed text-zinc-400">
              تساعدك منصة <strong>معاك 100 | M3AK 100</strong> على اكتشاف منتجات مناسبة لميزانيتك من متاجر أصلية موثوقة، وتسهل عليك خطوة الطلب وتفعيل أكواد الخصم الحصرية.
            </p>

            {/* Android APK Download Card in Footer */}
            <div className="pt-2">
              <button
                onClick={() => setIsDownloadModalOpen(true)}
                className="w-full flex items-center justify-between p-3 rounded-2xl bg-gradient-to-r from-emerald-950/70 to-zinc-900 border border-emerald-500/40 hover:border-emerald-400 transition-all text-white group shadow-md"
              >
                <div className="flex items-center gap-2.5">
                  <div className="w-8 h-8 rounded-xl bg-emerald-500/20 border border-emerald-500/30 flex items-center justify-center text-emerald-400 group-hover:scale-105 transition-transform">
                    <Smartphone className="w-4 h-4" />
                  </div>
                  <div className="text-right">
                    <span className="text-xs font-bold block">تطبيق Android</span>
                    <span className="text-[10px] text-emerald-400 font-mono">
                      {latestActiveAppUpdate ? `v${latestActiveAppUpdate.version_name} • APK` : 'تحميل مجاني'}
                    </span>
                  </div>
                </div>
                <div className="p-1.5 rounded-lg bg-emerald-500/20 text-emerald-400 group-hover:bg-emerald-500 group-hover:text-white transition-colors">
                  <Download className="w-4 h-4" />
                </div>
              </button>
            </div>
          </div>

          {/* Column: استكشف */}
          <div>
            <h4 className="text-sm font-bold text-white mb-4">استكشف</h4>
            <ul className="space-y-2.5 text-xs">
              <li>
                <button
                  onClick={() => setCurrentView('products')}
                  className="hover:text-white transition-colors"
                >
                  كل المنتجات والتصنيفات
                </button>
              </li>
              <li>
                <button
                  onClick={() => setCurrentView('favorites')}
                  className="hover:text-white transition-colors"
                >
                  المفضلة
                </button>
              </li>
              <li>
                <button
                  onClick={() => setCurrentView('orders')}
                  className="hover:text-white transition-colors"
                >
                  طلباتي وسجل العمليات
                </button>
              </li>
              <li>
                <button
                  onClick={() => setCurrentView('about')}
                  className="hover:text-white transition-colors"
                >
                  من نحن
                </button>
              </li>
              <li>
                <button
                  onClick={() => setCurrentView('gmail')}
                  className="hover:text-red-400 transition-colors flex items-center gap-1.5"
                >
                  <Mail className="w-3.5 h-3.5 text-red-500" />
                  <span>بريد Gmail</span>
                </button>
              </li>
              <li>
                <button
                  onClick={() => setCurrentView('sheets')}
                  className="hover:text-emerald-400 transition-colors flex items-center gap-1.5"
                >
                  <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-500" />
                  <span>Google Sheets</span>
                </button>
              </li>
            </ul>
          </div>

          {/* Column: السياسات */}
          <div>
            <h4 className="text-sm font-bold text-white mb-4">السياسات</h4>
            <ul className="space-y-2.5 text-xs">
              <li className="hover:text-white transition-colors cursor-pointer">
                سياسة الخصوصية وأمان البيانات
              </li>
              <li className="hover:text-white transition-colors cursor-pointer">
                الشروط والأحكام الرسمية
              </li>
              <li className="hover:text-white transition-colors cursor-pointer">
                سياسة رسوم خدمة الطلب (10 جنيه)
              </li>
              <li className="hover:text-white transition-colors cursor-pointer">
                ضمان مطابقة الروابط مع المتاجر الأصلية
              </li>
            </ul>
          </div>

          {/* Column: تواصل معنا */}
          <div className="space-y-3 text-xs">
            <h4 className="text-sm font-bold text-white mb-4">تواصل معنا</h4>
            
            <a
              href="https://wa.me/201015042334"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-2 text-zinc-300 hover:text-white bg-[#161616] p-2.5 rounded-xl border border-zinc-800 transition-colors"
            >
              <Phone className="w-4 h-4 text-emerald-400" />
              <span>خدمة العملاء وواتساب: 01015042334</span>
            </a>

            <button
              onClick={() => setIsChatModalOpen(true)}
              className="w-full flex items-center gap-2 text-zinc-300 hover:text-white bg-[#161616] p-2.5 rounded-xl border border-zinc-800 transition-colors text-right"
            >
              <MessageCircle className="w-4 h-4 text-[#FF3344]" />
              <span>الدعم الفني والمحادثة المباشرة</span>
            </button>

            <div className="flex items-center gap-2 text-zinc-500 pt-1">
              <Shield className="w-3.5 h-3.5 text-emerald-400" />
              <span>جميع المعاملات والتحويلات مشفرة ومؤمنة بالكامل</span>
            </div>
          </div>
        </div>

        {/* Bottom Copyright matching Screenshot 4 */}
        <div className="pt-6 border-t border-[#1C1C1C] flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-zinc-500">
          <p>جميع الحقوق محفوظة — معاك 100 | M3AK 100 © 2026</p>
          <p className="flex items-center gap-2">
            <span>منصة تسوق ذكية بالذكاء الاصطناعي</span>
            <span>•</span>
            <span className="text-[#FF3344] font-bold">نسخة الويب السحابية الموحدة</span>
          </p>
        </div>
      </div>
    </footer>
  );
};
