import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { ProductCard } from './ProductCard';
import { CategoryChips } from './CategoryChips';
import { Search, Filter, ArrowUpDown, X, Sparkles } from 'lucide-react';

export const ProductsView: React.FC = () => {
  const {
    products,
    categories,
    budgets,
    stores,
    countries,
    selectedBudget,
    setSelectedBudget,
    selectedCategory,
    setSelectedCategory,
    selectedCountry,
    setSelectedCountry,
    searchQuery,
    setSearchQuery,
    activeCurrency,
    activeCurrencySymbol
  } = useApp();

  const [sortBy, setSortBy] = useState<'newest' | 'price-asc' | 'price-desc' | 'popular'>('newest');
  const [showFiltersMobile, setShowFiltersMobile] = useState(false);

  const currentCountry = countries.find(c => c.code === selectedCountry);

  // Filtering
  const filteredProducts = products.filter(p => {
    if (!p.is_available) return false;
    // Country Filter
    if (selectedCountry && selectedCountry !== 'ALL') {
      const pCountry = p.country_code || 'EG';
      if (pCountry !== selectedCountry) return false;
    }
    if (selectedBudget !== null && p.budget !== selectedBudget) return false;
    if (selectedCategory !== null && p.category_id !== selectedCategory) return false;
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const matchName = p.name.toLowerCase().includes(q);
      const matchDesc = p.description.toLowerCase().includes(q);
      if (!matchName && !matchDesc) return false;
    }
    return true;
  }).sort((a, b) => {
    if (sortBy === 'price-asc') return a.price - b.price;
    if (sortBy === 'price-desc') return b.price - a.price;
    if (sortBy === 'popular') return (b.order_count || 0) - (a.order_count || 0);
    return 0; // newest
  });

  const clearAllFilters = () => {
    setSelectedBudget(null);
    setSelectedCategory(null);
    setSearchQuery('');
  };

  const hasActiveFilters = selectedBudget !== null || selectedCategory !== null || searchQuery.trim().length > 0;

  return (
    <div className="max-w-7xl mx-auto px-2.5 sm:px-6 lg:px-8 py-5 sm:py-8 space-y-4 sm:space-y-6">
      {/* Top Bar: Title & Search */}
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-black text-white flex items-center gap-2">
            <span>كل المنتجات</span>
            {selectedCountry !== 'ALL' && currentCountry && (
              <span className="text-xs bg-[#E50914]/20 border border-[#E50914]/40 text-[#FF3344] px-2.5 py-0.5 rounded-full font-bold flex items-center gap-1">
                <span>{currentCountry.flag_emoji}</span>
                <span>{currentCountry.name_ar}</span>
              </span>
            )}
            <span className="text-xs bg-zinc-800 text-zinc-300 px-2.5 py-0.5 rounded-full font-bold">
              {filteredProducts.length} منتج
            </span>
          </h1>
          <p className="text-xs sm:text-sm text-zinc-400 mt-1">
            {selectedCountry === 'ALL'
              ? 'تسوق أفضل المنتجات الأصلية من جميع الدول حسب ميزانيتك'
              : `تسوق أفضل المنتجات الأصلية المتاحة للشحن داخل ${currentCountry?.name_ar || ''} بأسعار تبدأ من 100 ${activeCurrencySymbol}`}
          </p>
        </div>

        {/* Search Bar */}
        <div className="w-full md:w-80 relative">
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="ابحث بالاسم أو المتجر..."
            className="w-full bg-[#161616] text-white text-xs sm:text-sm rounded-full pl-10 pr-4 py-2.5 border border-[#2A2A2A] focus:outline-none focus:border-[#E50914] transition-colors"
          />
          <Search className="w-4 h-4 text-zinc-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute left-9 top-1/2 -translate-y-1/2 text-zinc-500 hover:text-white"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          )}
        </div>
      </div>

      {/* Category Chips Bar */}
      <CategoryChips />

      {/* Filter and Sort Bar */}
      <div className="bg-[#161616] border border-[#2A2A2A] rounded-2xl p-4 flex flex-wrap items-center justify-between gap-3">
        {/* Budget filters */}
        <div className="flex items-center gap-1.5 overflow-x-auto scrollbar-none py-1">
          <span className="text-xs text-zinc-500 font-bold ml-1">الميزانية:</span>
          <button
            onClick={() => setSelectedBudget(null)}
            className={`px-3 py-1 rounded-lg text-xs font-bold transition-colors ${
              selectedBudget === null
                ? 'bg-[#E50914] text-white'
                : 'bg-zinc-800 text-zinc-400 hover:text-white'
            }`}
          >
            الكل
          </button>
          {budgets.map(b => (
            <button
              key={b.amount}
              onClick={() => setSelectedBudget(selectedBudget === b.amount ? null : b.amount)}
              className={`px-3 py-1 rounded-lg text-xs font-bold transition-colors ${
                selectedBudget === b.amount
                  ? 'bg-[#E50914] text-white'
                  : 'bg-zinc-800 text-zinc-400 hover:text-white'
              }`}
            >
              {b.amount} {activeCurrency}
            </button>
          ))}
        </div>

        {/* Sort selector */}
        <div className="flex items-center gap-2">
          <ArrowUpDown className="w-3.5 h-3.5 text-zinc-400" />
          <select
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value as any)}
            className="bg-[#0B0B0B] text-zinc-300 text-xs rounded-xl px-3 py-1.5 border border-zinc-700 focus:outline-none focus:border-[#E50914]"
          >
            <option value="newest">الأحدث أولاً</option>
            <option value="price-asc">الأقل سعراً</option>
            <option value="price-desc">الأعلى سعراً</option>
            <option value="popular">الأكثر طلباً</option>
          </select>

          {hasActiveFilters && (
            <button
              onClick={clearAllFilters}
              className="text-xs text-[#FF3344] hover:underline font-bold px-2"
            >
              مسح الفلاتر ✕
            </button>
          )}
        </div>
      </div>

      {/* Products Grid */}
      {filteredProducts.length === 0 ? (
        <div className="text-center py-20 px-4 bg-[#161616] border border-[#2A2A2A] rounded-3xl space-y-4">
          <div className="w-16 h-16 rounded-2xl bg-zinc-800/80 text-zinc-500 flex items-center justify-center mx-auto">
            <Filter className="w-8 h-8" />
          </div>
          <h3 className="text-lg font-bold text-white">لا توجد منتجات مطابقة لهذه الفلاتر</h3>
          <p className="text-xs sm:text-sm text-zinc-400 max-w-sm mx-auto leading-relaxed">
            جرب اختيار ميزانية أخرى أو مسح البحث لعرض المنتجات المتوفرة.
          </p>
          <button
            onClick={clearAllFilters}
            className="px-6 py-2.5 rounded-full bg-[#E50914] text-white text-xs font-bold hover:bg-[#FF3344] transition-colors inline-block"
          >
            عرض كل المنتجات
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 2xl:grid-cols-7 gap-2 sm:gap-3.5">
          {filteredProducts.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      )}
    </div>
  );
};
