import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import {
  ShieldCheck,
  CheckCircle2,
  XCircle,
  Clock,
  Plus,
  Trash2,
  Edit,
  Star,
  RefreshCw,
  Search,
  Eye,
  EyeOff,
  Radio,
  Signal,
  Settings,
  DollarSign,
  TrendingUp,
  Store,
  Lock,
  ExternalLink,
  ChevronDown,
  X,
  Globe,
  Smartphone,
  Upload,
  Download,
  Copy,
  Check,
  Layers,
  FileCode,
  AlertCircle,
  Info,
  Activity,
  Cpu,
  CheckCheck,
  Save,
  Users,
  UserPlus,
  UserCheck,
  Power,
  Zap,
  Sparkles,
  ShieldAlert
} from 'lucide-react';
import type { Product, Payment, PaymentMethod, AppUpdate } from '../types';
import { getCountryDetails } from '../utils/country';
import { validateAndAnalyzeApkFile, checkApkUrlHealth, type ApkAnalysisResult } from '../lib/apkValidator';

export const AdminDashboard: React.FC = () => {
  const {
    currentUser,
    isAdmin,
    isOwner,
    moderators,
    isPaymentGatewayEnabled,
    adminTogglePaymentGateway,
    adminAddModerator,
    adminRemoveModerator,
    loginWithGoogle,
    signInWithGoogleReal,
    setCurrentView,
    products,
    categories,
    budgets,
    orders,
    payments,
    paymentMethods,
    deletePayment,
    adminApprovePayment,
    adminRejectPayment,
    adminUpsertProduct,
    adminDeleteProduct,
    adminToggleFeatured,
    adminUpsertPaymentMethod,
    adminDeletePaymentMethod,
    adminTogglePaymentMethodActive,
    adminSeedPaymentMethodsToSupabase,
    adminSyncPaymentMethodsToSupabase,
    adminResetDefaultPaymentMethods,
    isLiveSyncConnected,
    lastLiveEvent,
    countries,
    adminToggleCountryActive,
    adminSeedCountriesToSupabase,
    adminUpdateSettings,
    adminUpdateCountrySettings,
    getOrderFeeForCountry,
    getOrderExpiryForCountry,
    settingsMap,
    appUpdates,
    adminUploadApk,
    adminPublishCustomApkUrl,
    adminToggleAppUpdateActive,
    adminDeleteAppUpdate,
    syncWithSupabase,
    orderFee,
    orderExpiryMinutes,
    activeCurrency
  } = useApp();

  // Tabs
  const [activeTab, setActiveTab] = useState<'payments' | 'products' | 'methods' | 'countries' | 'app_updates' | 'admins' | 'settings' | 'stats'>('payments');

  // Moderator management state
  const [newModEmail, setNewModEmail] = useState('');
  const [newModName, setNewModName] = useState('');
  const [isAddingMod, setIsAddingMod] = useState(false);
  const [modStatusMsg, setModStatusMsg] = useState<{ type: 'success' | 'error'; text: string } | null>(null);
  const [isTogglingGateway, setIsTogglingGateway] = useState(false);
  const [gatewayMsg, setGatewayMsg] = useState('');

  // App updates state
  const [apkSourceMode, setApkSourceMode] = useState<'file' | 'custom_url'>('file');
  const [selectedApkFile, setSelectedApkFile] = useState<File | null>(null);
  const [apkCustomUrl, setApkCustomUrl] = useState('');
  const [apkAnalysis, setApkAnalysis] = useState<ApkAnalysisResult | null>(null);
  const [isAnalyzingApk, setIsAnalyzingApk] = useState(false);
  const [urlHealthStatus, setUrlHealthStatus] = useState<Record<string, { status: 'checking' | 'ok' | 'error'; statusCode?: number; errorMsg?: string }>>({});
  const [isSeedingCountries, setIsSeedingCountries] = useState(false);
  const [seedingCountriesMsg, setSeedingCountriesMsg] = useState('');
  const [apkVersionName, setApkVersionName] = useState('');
  const [apkVersionCode, setApkVersionCode] = useState('');
  const [apkUpdateTitle, setApkUpdateTitle] = useState('');
  const [apkUpdateDescription, setApkUpdateDescription] = useState('');
  const [apkIsActive, setApkIsActive] = useState(true);
  const [isUploadingApk, setIsUploadingApk] = useState(false);
  const [apkUploadSuccessMsg, setApkUploadSuccessMsg] = useState('');
  const [apkUploadErrorMsg, setApkUploadErrorMsg] = useState('');
  const [copiedApkUrlId, setCopiedApkUrlId] = useState<string | null>(null);
  const [deletingUpdate, setDeletingUpdate] = useState<AppUpdate | null>(null);
  const [isDeletingUpdateLoading, setIsDeletingUpdateLoading] = useState(false);
  const [showStorageSetupSql, setShowStorageSetupSql] = useState(false);
  const [copiedSql, setCopiedSql] = useState(false);

  // Payment filters & zoom
  const [paymentFilter, setPaymentFilter] = useState<'ALL' | 'PAYMENT_REVIEW' | 'APPROVED' | 'REJECTED'>('ALL');
  const [paymentSearch, setPaymentSearch] = useState('');
  const [inspectingReceipt, setInspectingReceipt] = useState<Payment | null>(null);
  const [rejectingPayment, setRejectingPayment] = useState<Payment | null>(null);
  const [rejectReason, setRejectReason] = useState('صورة الإيصال غير واضحة');
  const [deletingPayment, setDeletingPayment] = useState<Payment | null>(null);
  const [isDeletingPaymentLoading, setIsDeletingPaymentLoading] = useState(false);

  // Product modal
  const [isProductModalOpen, setIsProductModalOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [pName, setPName] = useState('');
  const [pPrice, setPPrice] = useState('100');
  const [pBudget, setPBudget] = useState('100');
  const [pCountryCode, setPCountryCode] = useState('EG');
  const [pCategory, setPCategory] = useState('cat_elec');
  const [pStore, setPStore] = useState('سوق مصر');
  const [pImgUrl, setPImgUrl] = useState('');
  const [pAdditionalImages, setPAdditionalImages] = useState<string[]>(['', '', '', '', '', '']);
  const [pAffiliateUrl, setPAffiliateUrl] = useState('');
  const [pCouponCode, setPCouponCode] = useState('');
  const [pDesc, setPDesc] = useState('');
  const [pIsFeatured, setPIsFeatured] = useState(false);
  const [productSearch, setProductSearch] = useState('');

  // Payment method modal & management
  const [isMethodModalOpen, setIsMethodModalOpen] = useState(false);
  const [editingMethod, setEditingMethod] = useState<PaymentMethod | null>(null);
  const [mName, setMName] = useState('');
  const [mNumber, setMNumber] = useState('');
  const [mOwner, setMOwner] = useState('إدارة معاك 100');
  const [mInstructions, setMInstructions] = useState('');
  const [mIconType, setMIconType] = useState('vodafone');
  const [mCountryCode, setMCountryCode] = useState('EG');
  const [mIsEnabled, setMIsEnabled] = useState(true);
  const [deletingMethod, setDeletingMethod] = useState<PaymentMethod | null>(null);
  const [isDeletingMethodLoading, setIsDeletingMethodLoading] = useState(false);
  const [isSeedingMethods, setIsSeedingMethods] = useState(false);
  const [seedingMethodsMsg, setSeedingMethodsMsg] = useState('');
  const [methodCountryFilter, setMethodCountryFilter] = useState<string>('ALL');
  const [methodStatusFilter, setMethodStatusFilter] = useState<'ALL' | 'ACTIVE' | 'DISABLED'>('ALL');

  // Settings form
  const [settingsCountry, setSettingsCountry] = useState<string>('EG');
  const [newFee, setNewFee] = useState(() => getOrderFeeForCountry('EG').toString());
  const [newExpiry, setNewExpiry] = useState(() => getOrderExpiryForCountry('EG').toString());
  const [newCurrency, setNewCurrency] = useState('جنيه');
  const [isSavingSettings, setIsSavingSettings] = useState(false);
  const [settingsSavedMsg, setSettingsSavedMsg] = useState('');
  const [isSyncing, setIsSyncing] = useState(false);

  // Update form values whenever selected settings country changes
  const handleSelectSettingsCountry = (code: string) => {
    setSettingsCountry(code);
    const countryObj = countries.find(c => c.code === code);
    const fee = getOrderFeeForCountry(code);
    const expiry = getOrderExpiryForCountry(code);
    setNewFee(fee.toString());
    setNewExpiry(expiry.toString());
    setNewCurrency(countryObj?.currency_name_ar || countryObj?.currency_code || 'جنيه');
    setSettingsSavedMsg('');
  };

  // Strict Security Gate - ONLY owner or authorized moderators
  if (!isAdmin) {
    const handleGoogleOwnerLogin = async () => {
      try {
        await signInWithGoogleReal();
      } catch {
        await loginWithGoogle('mohmdfartka00@gmail.com', 'محمد (المالك والمدير العام)');
      }
    };

    return (
      <div className="max-w-md mx-auto px-4 py-20 text-center">
        <div className="bg-[#161616] border border-[#2A2A2A] rounded-3xl p-8 space-y-6 shadow-2xl">
          <div className="w-16 h-16 rounded-2xl bg-red-500/10 text-[#FF3344] flex items-center justify-center mx-auto border border-red-500/20">
            <Lock className="w-8 h-8" />
          </div>

          <div>
            <span className="inline-block px-3 py-1 rounded-full bg-emerald-500/15 text-emerald-400 text-xs font-bold border border-emerald-500/30 mb-2">
              لوحة إدارة محمية ومقفلة 🛡️
            </span>
            <h2 className="text-xl font-black text-white">الوصول مقيد لمالك المنصة والمشرفين المصرح لهم</h2>
            <p className="text-xs text-zinc-400 mt-2 leading-relaxed">
              هذه اللوحة محمية وتتطلب الدخول بحساب Google المعتمد للمالك أو أحد المشرفين الذين تم منحهم الصلاحية:
            </p>
            <div className="mt-3 p-2.5 rounded-xl bg-zinc-900 border border-zinc-800 text-xs font-mono text-emerald-400 font-bold dir-ltr text-center select-all">
              mohmdfartka00@gmail.com (حساب المالك الرئيسي)
            </div>
          </div>

          <div className="space-y-3 pt-2">
            <button
              onClick={handleGoogleOwnerLogin}
              className="w-full py-3.5 px-4 rounded-xl bg-white hover:bg-zinc-100 text-zinc-900 text-xs sm:text-sm font-bold flex items-center justify-center gap-3 transition-all shadow-lg shadow-white/5"
            >
              <svg className="w-4 h-4" viewBox="0 0 24 24">
                <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
                <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
                <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z" />
                <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z" />
              </svg>
              <span>دخول الإدارة عبر حساب Google</span>
            </button>

            <button
              onClick={() => setCurrentView('home')}
              className="w-full py-2.5 text-xs text-zinc-400 hover:text-white transition-colors"
            >
              العودة إلى الصفحة الرئيسية للمتجر
            </button>
          </div>
        </div>
      </div>
    );
  }

  // Handle open add product
  const handleOpenAddProduct = () => {
    setEditingProduct(null);
    setPName('');
    setPPrice('100');
    setPBudget('100');
    setPCountryCode('EG');
    setPCategory('cat_elec');
    setPStore('سوق مصر');
    setPImgUrl('');
    setPAdditionalImages(['', '', '', '', '', '']);
    setPAffiliateUrl('');
    setPCouponCode('');
    setPDesc('');
    setPIsFeatured(false);
    setIsProductModalOpen(true);
  };

  const handleOpenEditProduct = (p: Product) => {
    setEditingProduct(p);
    setPName(p.name);
    setPPrice(p.price.toString());
    setPBudget(p.budget.toString());
    setPCountryCode(p.country_code || 'EG');
    setPCategory(p.category_id);
    setPStore(p.store_name);
    setPImgUrl(p.image_url);
    try {
      const parsed = p.additional_images_json ? JSON.parse(p.additional_images_json) : [];
      // Pad to at least 6 empty inputs
      while (parsed.length < 6) parsed.push('');
      setPAdditionalImages(parsed);
    } catch {
      setPAdditionalImages(['', '', '', '', '', '']);
    }
    setPAffiliateUrl(p.affiliate_url);
    setPCouponCode(p.coupon_code || '');
    setPDesc(p.description);
    setPIsFeatured(p.is_featured);
    setIsProductModalOpen(true);
  };

  const handleSaveProduct = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!pName.trim()) return;

    const validAdditionalImages = pAdditionalImages.map(u => u.trim()).filter(Boolean);

    const prod: Product = {
      id: editingProduct?.id || 'prod_' + Math.random().toString(36).substring(2, 9),
      name: pName.trim(),
      price: parseFloat(pPrice) || 100,
      budget: parseInt(pBudget) || 100,
      category_id: pCategory,
      store_name: '',
      image_url: pImgUrl.trim() || 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=600',
      additional_images_json: validAdditionalImages.length > 0 ? JSON.stringify(validAdditionalImages) : undefined,
      original_product_url: pAffiliateUrl.trim() || 'https://egypt.souq.com',
      affiliate_url: pAffiliateUrl.trim() || 'https://egypt.souq.com',
      coupon_code: pCouponCode.trim() || undefined,
      description: pDesc.trim() || 'منتج أصلي عالي الجودة متوفر عبر المتجر.',
      is_featured: pIsFeatured,
      is_available: true,
      views_count: editingProduct?.views_count || 100,
      order_count: editingProduct?.order_count || 10,
      country_code: pCountryCode
    };

    await adminUpsertProduct(prod);
    setIsProductModalOpen(false);
  };

  // Payment Methods Handlers
  const handleOpenAddMethod = () => {
    setEditingMethod(null);
    setMName('');
    setMNumber('');
    setMOwner('إدارة معاك 100');
    setMInstructions('');
    setMIconType('vodafone');
    setMCountryCode('EG');
    setMIsEnabled(true);
    setIsMethodModalOpen(true);
  };

  const handleOpenEditMethod = (m: PaymentMethod) => {
    setEditingMethod(m);
    setMName(m.name);
    setMNumber(m.wallet_number);
    setMOwner(m.owner_name);
    setMInstructions(m.instructions);
    setMIconType(m.icon_type);
    setMCountryCode(m.country_code || 'EG');
    setMIsEnabled(m.is_enabled !== false);
    setIsMethodModalOpen(true);
  };

  const handleSaveMethod = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!mName.trim() || !mNumber.trim()) return;

    const method: PaymentMethod = {
      id: editingMethod?.id || 'method_' + Math.random().toString(36).substring(2, 9),
      name: mName.trim(),
      wallet_number: mNumber.trim(),
      owner_name: mOwner.trim() || 'إدارة معاك 100',
      instructions: mInstructions.trim(),
      icon_type: mIconType,
      is_enabled: mIsEnabled,
      country_code: mCountryCode
    };

    await adminUpsertPaymentMethod(method);
    setIsMethodModalOpen(false);
  };

  const handleSeedPaymentMethods = async () => {
    setIsSeedingMethods(true);
    setSeedingMethodsMsg('');
    try {
      const res = await adminSyncPaymentMethodsToSupabase();
      if (res.success) {
        setSeedingMethodsMsg(`تمت مزامنة ونشر ${res.count || 0} من طرق الدفع والتعديلات الحالية بنجاح في Supabase وربطها بالبث المباشر للجميع!`);
      } else {
        setSeedingMethodsMsg(`تنبيه: ${res.error || 'فشلت المزامنة'}`);
      }
    } catch (e: any) {
      setSeedingMethodsMsg('حدث خطأ أثناء الاتصال بقاعدة البيانات');
    } finally {
      setIsSeedingMethods(false);
      setTimeout(() => setSeedingMethodsMsg(''), 5000);
    }
  };

  const handleResetDefaultPaymentMethods = async () => {
    if (!window.confirm('هل أنت متأكد من رغبتك في استعادة المحافظ الافتراضية المصنعية؟ سيؤدي ذلك لإعادة تعيين قائمة وسائل الدفع للافتراضيات.')) {
      return;
    }
    setIsSeedingMethods(true);
    setSeedingMethodsMsg('');
    try {
      const res = await adminResetDefaultPaymentMethods();
      if (res.success) {
        setSeedingMethodsMsg(`تمت استعادة المحافظ الافتراضية (${res.count || 0}) بنجاح.`);
      } else {
        setSeedingMethodsMsg(`تنبيه: ${res.error || 'فشلت الاستعادة'}`);
      }
    } catch (e: any) {
      setSeedingMethodsMsg('حدث خطأ أثناء الاتصال بقاعدة البيانات');
    } finally {
      setIsSeedingMethods(false);
      setTimeout(() => setSeedingMethodsMsg(''), 5000);
    }
  };

  // APK Handlers
  const handleApkFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (!file.name.toLowerCase().endsWith('.apk')) {
        setApkUploadErrorMsg('يرجى اختيار ملف بصيغة APK صالحة (.apk)');
        return;
      }
      setSelectedApkFile(file);
      setApkUploadErrorMsg('');
      setApkUploadSuccessMsg('');

      const match = file.name.match(/v?(\d+\.\d+(\.\d+)?)/i);
      const guessedVer = match ? match[1] : (apkVersionName || '1.0.0');
      if (match && !apkVersionName) {
        setApkVersionName(match[1]);
      }
      if (!apkVersionCode) {
        const nextCode = (appUpdates.length > 0 ? Math.max(...appUpdates.map(u => Number(u.version_code) || 0)) + 1 : 1).toString();
        setApkVersionCode(nextCode);
      }
      if (!apkUpdateTitle) {
        setApkUpdateTitle(`إصدار جديد ${match ? match[1] : ''}`);
      }

      // Run instant binary inspection
      try {
        setIsAnalyzingApk(true);
        const analysis = await validateAndAnalyzeApkFile(file, guessedVer);
        setApkAnalysis(analysis);
      } catch (e) {
        console.warn('APK binary analysis warning:', e);
      } finally {
        setIsAnalyzingApk(false);
      }
    }
  };

  const handleTestApkUrl = async (updateId: string, url: string) => {
    setUrlHealthStatus(prev => ({ ...prev, [updateId]: { status: 'checking' } }));
    try {
      const res = await checkApkUrlHealth(url);
      if (res.isHealthy) {
        setUrlHealthStatus(prev => ({
          ...prev,
          [updateId]: { status: 'ok', statusCode: res.status }
        }));
      } else {
        setUrlHealthStatus(prev => ({
          ...prev,
          [updateId]: { status: 'error', statusCode: res.status, errorMsg: res.message }
        }));
      }
    } catch (e: any) {
      setUrlHealthStatus(prev => ({
        ...prev,
        [updateId]: { status: 'error', errorMsg: e?.message || 'فحص الرابط فشل' }
      }));
    }
  };

  const handleSeedCountries = async () => {
    setIsSeedingCountries(true);
    setSeedingCountriesMsg('');
    const res = await adminSeedCountriesToSupabase();
    if (res.success) {
      setSeedingCountriesMsg(`تمت مزامنة وتهيئة ${res.count || 14} دولة في Supabase بنجاح!`);
      setTimeout(() => setSeedingCountriesMsg(''), 4000);
    } else {
      setSeedingCountriesMsg(`تعذر تهيئة الدول: ${res.error || 'يرجى مراجعة صلاحيات جدول countries'}`);
    }
    setIsSeedingCountries(false);
  };

  const handlePublishApkUpdate = async (e: React.FormEvent) => {
    e.preventDefault();

    if (apkSourceMode === 'file' && !selectedApkFile) {
      setApkUploadErrorMsg('يرجى اختيار ملف الـ APK أولاً.');
      return;
    }
    if (apkSourceMode === 'custom_url' && (!apkCustomUrl.trim() || !apkCustomUrl.startsWith('http'))) {
      setApkUploadErrorMsg('يرجى كتابة رابط مباشر صالح يبدأ بـ https://');
      return;
    }
    if (!apkVersionName.trim()) {
      setApkUploadErrorMsg('يرجى كتابة رقم / اسم الإصدار (مثال: 1.0.1).');
      return;
    }
    const codeNum = parseInt(apkVersionCode) || (appUpdates.length + 1);

    // Requirement 14: Check if versionCode is higher than existing versions
    const maxExistingCode = appUpdates.length > 0 ? Math.max(...appUpdates.map(u => Number(u.version_code) || 0)) : 0;
    if (codeNum <= maxExistingCode) {
      const confirmProceed = window.confirm(`تنبيه توافق الإصدارات (VersionCode Warning):\n\nرقم الإصدار الجديد (${codeNum}) أقل من أو مساوٍ لأعلى رقم إصدار حالي (${maxExistingCode}). هذا قد يمنع بعض هواتف أندرويد من قبول التحديث فوق النسخة السابقة.\n\nهل أنت متأكد من رغبتك في المتابعة والنشر على أي حال؟`);
      if (!confirmProceed) {
        return;
      }
    }

    if (!apkUpdateTitle.trim()) {
      setApkUploadErrorMsg('يرجى كتابة عنوان للتحديث.');
      return;
    }

    try {
      setIsUploadingApk(true);
      setApkUploadErrorMsg('');
      setApkUploadSuccessMsg('');

      let res: { success: boolean; error?: string; update?: AppUpdate };

      if (apkSourceMode === 'file' && selectedApkFile) {
        res = await adminUploadApk(
          selectedApkFile,
          apkVersionName.trim(),
          codeNum,
          apkUpdateTitle.trim(),
          apkUpdateDescription.trim() || 'تحسينات عامة على استقرار وسرعة تطبيق معاك 100 وتوافق تام مع أندرويد.',
          apkIsActive
        );
      } else {
        res = await adminPublishCustomApkUrl(
          apkCustomUrl.trim(),
          apkVersionName.trim(),
          codeNum,
          apkUpdateTitle.trim(),
          apkUpdateDescription.trim() || 'تحسينات عامة على استقرار وسرعة تطبيق معاك 100 وتوافق تام مع أندرويد.',
          apkIsActive
        );
      }

      if (res.success) {
        setApkUploadSuccessMsg(`تم فحص ونشر الإصدار (${apkVersionName} - Code: ${codeNum}) وتفعيله للسحابة بنجاح!`);
        setSelectedApkFile(null);
        setApkCustomUrl('');
        setApkAnalysis(null);
        setApkVersionName('');
        setApkVersionCode('');
        setApkUpdateTitle('');
        setApkUpdateDescription('');
        setApkIsActive(true);
      } else {
        setApkUploadErrorMsg(res.error || 'تعذر نشر التحديث إلى السحابة.');
      }
    } catch (err: any) {
      setApkUploadErrorMsg(err?.message || 'حدث خطأ غير متوقع أثناء الرفع.');
    } finally {
      setIsUploadingApk(false);
    }
  };

  const handleCopyApkUrl = (update: AppUpdate) => {
    if (update.apk_url) {
      navigator.clipboard.writeText(update.apk_url);
      setCopiedApkUrlId(update.id);
      setTimeout(() => setCopiedApkUrlId(null), 2500);
    }
  };

  // Payment Gateway Killswitch Handler
  const handleTogglePaymentGateway = async () => {
    try {
      setIsTogglingGateway(true);
      const newStatus = !isPaymentGatewayEnabled;
      await adminTogglePaymentGateway(newStatus);
      setGatewayMsg(
        newStatus
          ? 'تم تفعيل بوابة الدفع ورسوم الخدمة بنجاح ✅ (يطلب من العميل إرفاق الإيصال للمراجعة)'
          : 'تم إيقاف رسوم الدفع وبوابة التحويل بنجاح 🚀 (الطلبات الآن تعمل بنظام التفعيل المباشر والمجاني فوراً)'
      );
      setTimeout(() => setGatewayMsg(''), 5000);
    } catch (err: any) {
      setGatewayMsg('خطأ أثناء تعديل حالة بوابة الدفع: ' + (err?.message || 'غير معروف'));
    } finally {
      setIsTogglingGateway(false);
    }
  };

  // Moderator Management Handlers
  const handleAddModerator = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newModEmail.trim()) {
      setModStatusMsg({ type: 'error', text: 'يرجى إدخال البريد الإلكتروني (Gmail) للمشرف.' });
      return;
    }
    try {
      setIsAddingMod(true);
      setModStatusMsg(null);
      const res = await adminAddModerator(newModEmail.trim(), newModName.trim());
      if (res.success) {
        setModStatusMsg({
          type: 'success',
          text: `تم منح صلاحية الإشراف للحساب (${newModEmail.trim()}) بنجاح ومزامنته سحابياً!`
        });
        setNewModEmail('');
        setNewModName('');
      } else {
        setModStatusMsg({ type: 'error', text: res.error || 'تعذر إضافة المشرف.' });
      }
    } catch (err: any) {
      setModStatusMsg({ type: 'error', text: err?.message || 'حدث خطأ غير متوقع أثناء إضافة المشرف.' });
    } finally {
      setIsAddingMod(false);
    }
  };

  const handleRemoveModerator = async (email: string) => {
    if (email.toLowerCase() === 'mohmdfartka00@gmail.com') {
      alert('خطأ أمني: حساب المالك الرئيسي محمي بشكل دائم ولا يمكن إزالته أو التنازل عن ملكيته!');
      return;
    }
    if (!window.confirm(`هل أنت متأكد من سحب صلاحية الإشراف وحذف المشرف (${email})؟`)) return;
    try {
      const res = await adminRemoveModerator(email);
      if (res.success) {
        setModStatusMsg({ type: 'success', text: `تم سحب الصلاحية وحذف المشرف (${email}) بنجاح.` });
        setTimeout(() => setModStatusMsg(null), 4000);
      } else {
        setModStatusMsg({ type: 'error', text: res.error || 'تعذر حذف المشرف.' });
      }
    } catch (err: any) {
      setModStatusMsg({ type: 'error', text: err?.message || 'خطأ أثناء الحذف.' });
    }
  };

  // Metrics
  const totalRevenue = orders.filter(o => o.payment_status === 'APPROVED' || o.payment_status === 'Paid').length * orderFee;
  const pendingCount = payments.filter(p => p.status === 'PAYMENT_REVIEW').length;
  const approvedCount = payments.filter(p => p.status === 'APPROVED').length;
  const rejectedCount = payments.filter(p => p.status === 'REJECTED').length;

  const filteredPayments = payments.filter(p => {
    const matchesStatus = paymentFilter === 'ALL' || p.status === paymentFilter;
    const matchesQuery = !paymentSearch.trim() ||
      p.order_id.toLowerCase().includes(paymentSearch.toLowerCase()) ||
      p.sender_wallet.includes(paymentSearch) ||
      p.transaction_id.includes(paymentSearch);
    return matchesStatus && matchesQuery;
  });

  const filteredProducts = products.filter(p =>
    !productSearch.trim() ||
    p.name.toLowerCase().includes(productSearch.toLowerCase())
  );

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
      {/* Top Header Card */}
      <div className="bg-[#161616] border border-[#2A2A2A] rounded-3xl p-6 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1 flex-wrap">
            {isOwner ? (
              <span className="bg-amber-500/20 text-amber-300 text-xs font-bold px-3 py-1 rounded-full border border-amber-500/40 flex items-center gap-1.5 shadow-sm">
                <span>👑</span>
                <span>المالك والمدير العام (حساب محمي)</span>
              </span>
            ) : (
              <span className="bg-blue-500/20 text-blue-300 text-xs font-bold px-3 py-1 rounded-full border border-blue-500/40 flex items-center gap-1.5 shadow-sm">
                <ShieldCheck className="w-3.5 h-3.5" />
                <span>مشرف لوحة التحكم (صلاحية إدارية)</span>
              </span>
            )}
            <span className="text-xs text-zinc-400 font-mono">{currentUser?.email || 'mohmdfartka00@gmail.com'}</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-black text-white">إدارة منصة معاك 100</h1>
          <p className="text-xs text-zinc-400 mt-1">
            مراجعة وتأكيد إيصالات التحويل، التحكم بالمنتجات، إدارة بوابات الرسوم، وإدارة المشرفين والصلاحيات
          </p>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          {/* Quick Payment Gateway State Switch */}
          <button
            onClick={handleTogglePaymentGateway}
            disabled={isTogglingGateway}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold flex items-center gap-2 transition-all border shadow-md disabled:opacity-50 ${
              isPaymentGatewayEnabled
                ? 'bg-amber-500/15 border-amber-500/30 text-amber-300 hover:bg-amber-500/25'
                : 'bg-emerald-500/15 border-emerald-500/30 text-emerald-300 hover:bg-emerald-500/25'
            }`}
            title="التحكم في تفعيل أو إلغاء رسوم الـ 10 جنيه وبوابة الدفع"
          >
            <Power className={`w-3.5 h-3.5 ${isPaymentGatewayEnabled ? 'text-amber-400' : 'text-emerald-400'}`} />
            <span>
              {isTogglingGateway
                ? 'جاري التعديل...'
                : isPaymentGatewayEnabled
                  ? 'بوابة الدفع: مفعلة (رسوم)'
                  : 'بوابة الدفع: معطلة (مجاني)'}
            </span>
          </button>

          <button
            onClick={async () => {
              setIsSyncing(true);
              await syncWithSupabase();
              setIsSyncing(false);
            }}
            disabled={isSyncing}
            className="px-4 py-2 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-white text-xs font-bold border border-zinc-700 flex items-center gap-1.5 transition-colors disabled:opacity-50"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isSyncing ? 'animate-spin' : ''}`} />
            <span>مزامنة سحابية</span>
          </button>
        </div>
      </div>

      {/* Gateway Message Feedback */}
      {gatewayMsg && (
        <div className={`p-4 rounded-2xl text-xs font-bold flex items-center gap-2.5 animate-fadeIn border ${
          isPaymentGatewayEnabled
            ? 'bg-amber-950/40 border-amber-500/40 text-amber-200'
            : 'bg-emerald-950/40 border-emerald-500/40 text-emerald-200'
        }`}>
          <Sparkles className="w-4 h-4 shrink-0" />
          <span>{gatewayMsg}</span>
        </div>
      )}

      {/* Navigation Tabs */}
      <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none border-b border-zinc-800">
        {[
          { id: 'payments', label: `مراجعة المدفوعات (${pendingCount} معلق)`, icon: DollarSign },
          { id: 'products', label: `المنتجات والأفيليت (${products.length})`, icon: Store },
          { id: 'methods', label: 'بوابات الدفع والمحافظ', icon: ShieldCheck },
          { id: 'countries', label: `الدول المدعومة (${countries.length})`, icon: Globe },
          { id: 'app_updates', label: `إدارة إصدارات التطبيق (${appUpdates.length})`, icon: Smartphone },
          { id: 'admins', label: `المشرفون والصلاحيات (${moderators.length + 1})`, icon: Users },
          { id: 'stats', label: 'الإحصائيات المالية', icon: TrendingUp },
          { id: 'settings', label: 'إعدادات الرسوم والمهلة', icon: Settings }
        ].map(tab => {
          const Icon = tab.icon;
          const isSel = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`px-4 py-2.5 rounded-2xl text-xs sm:text-sm font-bold whitespace-nowrap transition-all flex items-center gap-2 ${
                isSel
                  ? 'bg-[#E50914] text-white shadow-lg shadow-[#E50914]/20'
                  : 'bg-[#161616] text-zinc-400 hover:text-white hover:bg-zinc-800 border border-[#2A2A2A]'
              }`}
            >
              <Icon className="w-4 h-4" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* TAB 1: PAYMENTS REVIEW */}
      {activeTab === 'payments' && (
        <div className="space-y-4">
          {/* Filter Bar */}
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 bg-[#161616] p-4 rounded-2xl border border-[#2A2A2A]">
            <div className="flex items-center gap-2 overflow-x-auto">
              {[
                { id: 'ALL', label: `الكل (${payments.length})` },
                { id: 'PAYMENT_REVIEW', label: `قيد المراجعة (${pendingCount})` },
                { id: 'APPROVED', label: `مقبولة (${approvedCount})` },
                { id: 'REJECTED', label: `مرفوضة (${rejectedCount})` }
              ].map(f => (
                <button
                  key={f.id}
                  onClick={() => setPaymentFilter(f.id as any)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition-colors ${
                    paymentFilter === f.id
                      ? 'bg-zinc-200 text-black'
                      : 'bg-zinc-900 text-zinc-400 hover:text-white'
                  }`}
                >
                  {f.label}
                </button>
              ))}
            </div>

            <div className="relative flex-1 sm:max-w-xs">
              <input
                type="text"
                value={paymentSearch}
                onChange={(e) => setPaymentSearch(e.target.value)}
                placeholder="بحث برقم الطلب أو المحفظة..."
                className="w-full bg-[#0B0B0B] text-white text-xs rounded-xl pl-8 pr-3 py-2 border border-zinc-800 focus:outline-none focus:border-[#E50914]"
              />
              <Search className="w-3.5 h-3.5 text-zinc-500 absolute left-2.5 top-1/2 -translate-y-1/2 pointer-events-none" />
            </div>
          </div>

          {/* Payments List */}
          {filteredPayments.length === 0 ? (
            <div className="text-center py-16 bg-[#161616] rounded-3xl border border-[#2A2A2A]">
              <p className="text-sm text-zinc-400">لا توجد طلبات دفع في هذا التصنيف حالياً</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {filteredPayments.map(p => {
                const isUnderReview = p.status === 'PAYMENT_REVIEW';
                const isApproved = p.status === 'APPROVED';
                const isRejected = p.status === 'REJECTED';
                const country = getCountryDetails(p.country_code);

                return (
                  <div
                    key={p.payment_id}
                    className={`bg-[#161616] border rounded-2xl p-4 sm:p-5 space-y-3.5 transition-all ${
                      isUnderReview
                        ? 'border-amber-500/50 shadow-md shadow-amber-500/5'
                        : isApproved
                        ? 'border-emerald-500/30'
                        : 'border-red-500/30'
                    }`}
                  >
                    <div className="flex items-center justify-between pb-2 border-b border-zinc-800">
                      <div className="flex items-center gap-2">
                        <div>
                          <span className="text-[10px] text-zinc-500 block">رقم الطلب</span>
                          <span className="text-sm font-black text-white font-mono">{p.order_id}</span>
                        </div>
                        <span className="px-2 py-0.5 rounded-full bg-zinc-900 border border-zinc-700 text-white text-[10px] font-bold flex items-center gap-1">
                          <span>{country.flag}</span>
                          <span>{country.name}</span>
                        </span>
                      </div>

                      <div className="flex items-center gap-2">
                        <span
                          className={`text-[11px] font-bold px-2.5 py-0.5 rounded-full ${
                            isUnderReview
                              ? 'bg-amber-500/20 text-amber-300'
                              : isApproved
                              ? 'bg-emerald-500/20 text-emerald-400'
                              : 'bg-red-500/20 text-red-400'
                          }`}
                        >
                          {isUnderReview && '⏳ قيد المراجعة'}
                          {isApproved && '✅ مقبولة ومفعلة'}
                          {isRejected && '❌ مرفوضة'}
                        </span>

                        <button
                          onClick={() => setDeletingPayment(p)}
                          className="p-1.5 rounded-lg bg-zinc-900 hover:bg-red-500/20 text-zinc-400 hover:text-red-400 border border-zinc-800 hover:border-red-500/30 transition-all flex items-center gap-1 text-xs"
                          title="حذف هذا الإيصال / المعاملة"
                        >
                          <Trash2 className="w-3.5 h-3.5 text-red-400" />
                          <span className="text-[10px] font-bold hidden sm:inline">حذف</span>
                        </button>
                      </div>
                    </div>

                    <div className="space-y-1.5 text-xs text-zinc-300">
                      <div className="flex justify-between">
                        <span className="text-zinc-500">السلعة:</span>
                        <span className="text-white font-bold truncate max-w-[200px]">{p.product_name}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-zinc-500">وسيلة التحويل:</span>
                        <span className="text-white font-bold">{p.payment_method}</span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-zinc-500">محفظة العميل المرسل:</span>
                        <div className="flex items-center gap-1.5">
                          <span className="text-emerald-400 font-mono font-bold">{p.sender_wallet}</span>
                          {p.sender_wallet && (
                            <a
                              href={`https://wa.me/2${p.sender_wallet.replace(/\D/g, '')}`}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="text-[10px] bg-emerald-500/20 text-emerald-400 hover:bg-emerald-500 hover:text-black px-1.5 py-0.5 rounded transition-colors font-bold"
                              title="محادثة واتساب مباشرة مع العميل"
                            >
                              واتساب
                            </a>
                          )}
                        </div>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-zinc-500">رقم العملية (Txn ID):</span>
                        <span className="text-white font-mono font-bold bg-zinc-900 px-1.5 py-0.5 rounded select-all">{p.transaction_id}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-zinc-500">المبلغ:</span>
                        <span className="text-white font-black">{p.amount} {activeCurrency}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-zinc-500">التاريخ:</span>
                        <span className="text-zinc-400">{p.transfer_date_time}</span>
                      </div>
                    </div>

                    {/* Receipt Preview Thumbnail */}
                    {(p.receipt_image_url || p.image_url) && (
                      <div
                        onClick={() => setInspectingReceipt(p)}
                        className="flex items-center gap-3 p-2 bg-[#0B0B0B] rounded-xl border border-zinc-800 hover:border-zinc-600 cursor-pointer transition-colors"
                      >
                        <img
                          src={p.receipt_image_url || p.image_url}
                          alt="Receipt"
                          className="w-12 h-12 object-cover rounded-lg"
                        />
                        <div className="text-xs">
                          <span className="text-white font-bold block">عرض صورة الإيصال 🔍</span>
                          <span className="text-[10px] text-zinc-400">اضغط للمعاينة والتكبير</span>
                        </div>
                      </div>
                    )}

                    {/* Action Buttons */}
                    <div className="pt-2 flex items-center gap-2">
                      <button
                        onClick={() => adminApprovePayment(p.payment_id, p.order_id)}
                        disabled={isApproved}
                        className="flex-1 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold transition-colors disabled:opacity-30 flex items-center justify-center gap-1"
                      >
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        <span>قبول وتفعيل</span>
                      </button>

                      <button
                        onClick={() => setRejectingPayment(p)}
                        disabled={isRejected}
                        className="flex-1 py-2 rounded-xl bg-red-600 hover:bg-red-500 text-white text-xs font-bold transition-colors disabled:opacity-30 flex items-center justify-center gap-1"
                      >
                        <XCircle className="w-3.5 h-3.5" />
                        <span>رفض الإيصال</span>
                      </button>

                      <button
                        onClick={() => setDeletingPayment(p)}
                        className="py-2 px-3 rounded-xl bg-zinc-900 hover:bg-red-500/20 text-zinc-400 hover:text-red-400 border border-zinc-800 hover:border-red-500/30 text-xs font-bold transition-colors flex items-center justify-center gap-1"
                        title="حذف المعاملة"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* TAB 2: PRODUCTS MANAGEMENT */}
      {activeTab === 'products' && (
        <div className="space-y-4">
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 bg-[#161616] p-4 rounded-2xl border border-[#2A2A2A]">
            <div className="relative flex-1 sm:max-w-xs">
              <input
                type="text"
                value={productSearch}
                onChange={(e) => setProductSearch(e.target.value)}
                placeholder="بحث في المنتجات..."
                className="w-full bg-[#0B0B0B] text-white text-xs rounded-xl pl-8 pr-3 py-2 border border-zinc-800 focus:outline-none focus:border-[#E50914]"
              />
              <Search className="w-3.5 h-3.5 text-zinc-500 absolute left-2.5 top-1/2 -translate-y-1/2 pointer-events-none" />
            </div>

            <button
              onClick={handleOpenAddProduct}
              className="px-5 py-2.5 rounded-xl bg-[#E50914] hover:bg-[#FF3344] text-white text-xs font-bold flex items-center justify-center gap-2 transition-colors shadow-md"
            >
              <Plus className="w-4 h-4" />
              <span>إضافة منتج جديد</span>
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredProducts.map(prod => {
              const country = getCountryDetails(prod.country_code);
              return (
              <div
                key={prod.id}
                className="bg-[#161616] border border-[#2A2A2A] rounded-2xl overflow-hidden p-4 space-y-3 relative group"
              >
                <div className="flex items-center gap-3">
                  <div className="w-16 h-16 rounded-xl bg-black border border-zinc-800 p-1 flex items-center justify-center shrink-0 overflow-hidden">
                    <img
                      src={prod.image_url}
                      alt={prod.name}
                      className="w-full h-full object-contain rounded-lg"
                      referrerPolicy="no-referrer"
                    />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-1.5 mb-1 flex-wrap">
                      <span className="text-[10px] bg-black border border-zinc-700 text-white px-1.5 py-0.5 rounded font-bold flex items-center gap-1">
                        <span>{country.flag}</span>
                        <span>{country.name}</span>
                      </span>
                      <span className="text-[10px] bg-zinc-800 text-zinc-300 px-2 py-0.5 rounded font-bold">
                        ميزانية {prod.budget}
                      </span>
                      {prod.is_featured && (
                        <span className="text-[10px] bg-[#FFD700] text-black px-1.5 py-0.5 rounded font-bold">
                          ⭐ مميز
                        </span>
                      )}
                    </div>
                    <h4 className="text-sm font-bold text-white truncate">{prod.name}</h4>
                    <p className="text-xs text-zinc-400">{prod.price} {country.currencySymbol}</p>
                  </div>
                </div>

                {prod.coupon_code && (
                  <div className="p-2 bg-emerald-950/30 rounded-lg text-[11px] text-emerald-300 font-bold border border-emerald-500/20 flex justify-between">
                    <span>كود الخصم:</span>
                    <span className="text-white font-mono">{prod.coupon_code}</span>
                  </div>
                )}

                <div className="flex items-center justify-between pt-2 border-t border-zinc-800 text-xs">
                  <button
                    onClick={() => adminToggleFeatured(prod.id)}
                    className={`p-1.5 rounded-lg border flex items-center gap-1 ${
                      prod.is_featured
                        ? 'bg-[#FFD700]/20 text-[#FFD700] border-[#FFD700]/40'
                        : 'bg-zinc-800 text-zinc-400 border-zinc-700'
                    }`}
                    title="تمييز في الصفحة الرئيسية"
                  >
                    <Star className="w-3.5 h-3.5 fill-current" />
                  </button>

                  <div className="flex items-center gap-1.5">
                    <button
                      onClick={() => handleOpenEditProduct(prod)}
                      className="px-3 py-1.5 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-white font-bold flex items-center gap-1"
                    >
                      <Edit className="w-3 h-3" />
                      <span>تعديل</span>
                    </button>
                    <button
                      onClick={() => {
                        if (confirm(`هل أنت متأكد من حذف المنتج: ${prod.name}؟`)) {
                          adminDeleteProduct(prod.id);
                        }
                      }}
                      className="p-1.5 rounded-lg bg-red-950/50 hover:bg-red-900 text-red-400 border border-red-800"
                      title="حذف"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>
              );
            })}
          </div>
        </div>
      )}

      {/* TAB 3: PAYMENT GATEWAYS & WALLETS */}
      {activeTab === 'methods' && (
        <div className="space-y-5">
          {/* Header & Main Actions */}
          <div className="bg-[#161616] p-5 rounded-3xl border border-[#2A2A2A] flex flex-col md:flex-row justify-between items-start md:items-center gap-4 shadow-xl">
            <div>
              <div className="flex items-center gap-2.5 flex-wrap">
                <h3 className="text-base font-black text-white flex items-center gap-2">
                  <span>بوابات الدفع والمحافظ الإلكترونية 💳</span>
                </h3>
                <div className="flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-emerald-500/15 border border-emerald-500/30 text-emerald-400 text-[10px] font-bold">
                  <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping"></span>
                  <span>بث مباشر متصل بالواجهة والتطبيق</span>
                </div>
              </div>
              <p className="text-xs text-zinc-400 mt-1 leading-relaxed max-w-2xl">
                تحكم كامل في إضافة، تعديل، إخفاء/إظهار، وحذف وسائل الدفع. أي تغيير يُحفظ مباشرة في Supabase وينعكس فوراً في واجهة الموقع وتطبيق الأندرويد دون الحاجة لتحديث الصفحة.
              </p>
            </div>

            <div className="flex items-center gap-2 w-full md:w-auto flex-wrap">
              <button
                type="button"
                onClick={handleSeedPaymentMethods}
                disabled={isSeedingMethods}
                className="px-3.5 py-2 rounded-xl bg-emerald-600/20 hover:bg-emerald-600/30 text-emerald-300 hover:text-emerald-200 text-xs font-bold border border-emerald-500/40 flex items-center gap-1.5 transition-colors disabled:opacity-50"
                title="مزامنة ونشر جميع المحافظ والتعديلات الحالية وحفظها سحابياً لجميع العملاء والتطبيق"
              >
                <RefreshCw className={`w-3.5 h-3.5 text-emerald-400 ${isSeedingMethods ? 'animate-spin' : ''}`} />
                <span>{isSeedingMethods ? 'جاري المزامنة والنشر...' : 'مزامنة ونشر المحافظ مع سوبابيز 🔄'}</span>
              </button>

              <button
                type="button"
                onClick={handleOpenAddMethod}
                className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold flex items-center gap-1.5 shadow-lg shadow-emerald-600/20 transition-all"
              >
                <Plus className="w-4 h-4" />
                <span>إضافة وسيلة دفع جديدة</span>
              </button>

              <button
                type="button"
                onClick={handleResetDefaultPaymentMethods}
                disabled={isSeedingMethods}
                className="px-2.5 py-2 rounded-xl bg-zinc-900 hover:bg-zinc-800 text-zinc-400 hover:text-zinc-300 text-[11px] font-bold border border-zinc-800 flex items-center gap-1 transition-colors"
                title="إعادة ضبط واستعادة المحافظ الافتراضية الأولية فقط عند الحاجة"
              >
                <span>استعادة الافتراضية</span>
              </button>
            </div>
          </div>

          {/* Seeding status message */}
          {seedingMethodsMsg && (
            <div className={`p-3.5 rounded-2xl text-xs font-bold flex items-center gap-2 animate-fadeIn ${
              seedingMethodsMsg.includes('نجاح')
                ? 'bg-emerald-950/40 border border-emerald-500/40 text-emerald-300'
                : 'bg-red-950/40 border border-red-500/40 text-red-300'
            }`}>
              <CheckCircle2 className="w-4 h-4 shrink-0" />
              <span>{seedingMethodsMsg}</span>
            </div>
          )}

          {/* Real-time Broadcast & Synchronization Sync Center */}
          <div className="bg-[#121212] border border-zinc-800/80 rounded-2xl p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-xs">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 flex items-center justify-center shrink-0">
                <Radio className="w-4 h-4 animate-pulse" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <span className="font-bold text-white">الربط المباشر الموحد (Web Store & Mobile App):</span>
                  <span className="px-2 py-0.5 rounded-md bg-emerald-500/20 text-emerald-300 text-[10px] font-mono font-bold">
                    Supabase Realtime Channel
                  </span>
                </div>
                <p className="text-zinc-400 text-[11px] mt-0.5">
                  الموقع وتطبيق الهاتف المحمول يشتركان في نفس الجداول لحظياً. إخفاء أو حذف أي وسيلة دفع هنا يخفيها فوراً في نافذة الدفع لجميع الزبائن.
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2 shrink-0 self-end sm:self-center">
              <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-zinc-900 border border-zinc-800 text-[11px]">
                <span className={`w-2 h-2 rounded-full ${isLiveSyncConnected ? 'bg-emerald-400 animate-pulse' : 'bg-amber-400'}`}></span>
                <span className="text-zinc-300 font-bold">{isLiveSyncConnected ? 'بث مباشر نشط 🟢' : 'جاري الاتصال...'}</span>
              </div>
              {lastLiveEvent && (
                <div className="hidden lg:flex items-center gap-1 text-[10px] text-zinc-500 font-mono">
                  <span>آخر حدث:</span>
                  <span className="text-emerald-400 font-bold">{lastLiveEvent.table}</span>
                  <span>({lastLiveEvent.type})</span>
                </div>
              )}
            </div>
          </div>

          {/* Filters Bar: Country & Status */}
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 bg-[#161616] p-3 rounded-2xl border border-zinc-800">
            {/* Status Filter */}
            <div className="flex items-center gap-1.5 overflow-x-auto pb-1 sm:pb-0">
              <button
                type="button"
                onClick={() => setMethodStatusFilter('ALL')}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-colors shrink-0 ${
                  methodStatusFilter === 'ALL'
                    ? 'bg-zinc-700 text-white shadow'
                    : 'text-zinc-400 hover:text-white hover:bg-zinc-800'
                }`}
              >
                الكل ({paymentMethods.length})
              </button>
              <button
                type="button"
                onClick={() => setMethodStatusFilter('ACTIVE')}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-colors flex items-center gap-1 shrink-0 ${
                  methodStatusFilter === 'ACTIVE'
                    ? 'bg-emerald-600 text-white shadow'
                    : 'text-emerald-400 hover:bg-emerald-500/10'
                }`}
              >
                <Eye className="w-3.5 h-3.5" />
                <span>الظاهرة والمفعلة ({paymentMethods.filter(m => m.is_enabled).length})</span>
              </button>
              <button
                type="button"
                onClick={() => setMethodStatusFilter('DISABLED')}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-colors flex items-center gap-1 shrink-0 ${
                  methodStatusFilter === 'DISABLED'
                    ? 'bg-amber-600 text-white shadow'
                    : 'text-amber-400 hover:bg-amber-500/10'
                }`}
              >
                <EyeOff className="w-3.5 h-3.5" />
                <span>المخفية والمعطلة ({paymentMethods.filter(m => !m.is_enabled).length})</span>
              </button>
            </div>

            {/* Country Filter Dropdown / Pills */}
            <div className="flex items-center gap-2 shrink-0">
              <span className="text-xs text-zinc-400 font-bold hidden sm:inline">الدولة:</span>
              <select
                value={methodCountryFilter}
                onChange={(e) => setMethodCountryFilter(e.target.value)}
                className="bg-[#0B0B0B] text-white text-xs font-bold rounded-xl px-3 py-1.5 border border-zinc-700 focus:outline-none focus:border-[#E50914]"
              >
                <option value="ALL">جميع الدول ({paymentMethods.length})</option>
                {countries.map(c => {
                  const count = paymentMethods.filter(m => (m.country_code || 'EG') === c.code).length;
                  return (
                    <option key={c.code} value={c.code}>
                      {c.flag_emoji} {c.name_ar} ({count})
                    </option>
                  );
                })}
              </select>
            </div>
          </div>

          {/* Payment Methods Cards Grid */}
          {(() => {
            const filteredMethods = paymentMethods.filter(m => {
              const matchesCountry = methodCountryFilter === 'ALL' || (m.country_code || 'EG') === methodCountryFilter;
              const matchesStatus =
                methodStatusFilter === 'ALL' ||
                (methodStatusFilter === 'ACTIVE' && m.is_enabled) ||
                (methodStatusFilter === 'DISABLED' && !m.is_enabled);
              return matchesCountry && matchesStatus;
            });

            if (filteredMethods.length === 0) {
              return (
                <div className="bg-[#161616] border border-zinc-800 rounded-3xl p-12 text-center space-y-3">
                  <div className="w-12 h-12 rounded-2xl bg-zinc-800 text-zinc-500 flex items-center justify-center mx-auto">
                    <EyeOff className="w-6 h-6" />
                  </div>
                  <h4 className="text-sm font-bold text-white">لا توجد وسائل دفع مطابقة للفلتر المحدد</h4>
                  <p className="text-xs text-zinc-400 max-w-sm mx-auto">
                    يمكنك تغيير الفلتر أو الضغط على زر "إضافة وسيلة دفع جديدة" أو استعادة المحافظ عبر زر "مزامنة المحافظ مع سوبابيز".
                  </p>
                  <button
                    type="button"
                    onClick={() => {
                      setMethodCountryFilter('ALL');
                      setMethodStatusFilter('ALL');
                    }}
                    className="px-4 py-2 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-white text-xs font-bold"
                  >
                    إعادة ضبط الفلاتر
                  </button>
                </div>
              );
            }

            return (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {filteredMethods.map(m => {
                  const mCountry = getCountryDetails(m.country_code || 'EG');
                  const isEnabled = m.is_enabled !== false;

                  return (
                    <div
                      key={m.id}
                      className={`bg-[#161616] border rounded-3xl p-5 space-y-4 transition-all ${
                        isEnabled
                          ? 'border-[#2A2A2A] shadow-lg hover:border-zinc-700'
                          : 'border-amber-500/30 bg-[#161616]/70 opacity-80'
                      }`}
                    >
                      {/* Top Meta: Country & Visibility Badge */}
                      <div className="flex items-start justify-between gap-2">
                        <div className="space-y-1">
                          <div className="flex items-center gap-2 flex-wrap">
                            <span className="text-[11px] bg-zinc-900 border border-zinc-700 text-white px-2.5 py-0.5 rounded-full font-bold flex items-center gap-1.5 shadow-sm">
                              <span>{mCountry.flag}</span>
                              <span>{mCountry.name}</span>
                              <span className="text-[10px] text-zinc-500 font-mono">({m.country_code || 'EG'})</span>
                            </span>

                            {isEnabled ? (
                              <span className="text-[10px] font-bold px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 flex items-center gap-1">
                                <Eye className="w-3 h-3" />
                                <span>ظاهرة ومفعلة للعملاء</span>
                              </span>
                            ) : (
                              <span className="text-[10px] font-bold px-2.5 py-0.5 rounded-full bg-amber-500/20 text-amber-400 border border-amber-500/30 flex items-center gap-1">
                                <EyeOff className="w-3 h-3" />
                                <span>مخفية عن العملاء (معطلة)</span>
                              </span>
                            )}
                          </div>

                          <h4 className="text-base font-black text-white pt-1">{m.name}</h4>
                        </div>
                      </div>

                      {/* Wallet Number & Owner Details */}
                      <div className="p-3.5 rounded-2xl bg-[#0B0B0B] border border-zinc-800 space-y-1.5">
                        <div className="flex items-center justify-between">
                          <span className="text-xs text-zinc-400">رقم المحفظة / الحساب:</span>
                          <span className="text-sm font-mono font-black text-emerald-400 dir-ltr select-all">
                            {m.wallet_number}
                          </span>
                        </div>
                        <div className="flex items-center justify-between text-xs pt-1 border-t border-zinc-900">
                          <span className="text-zinc-500">اسم صاحب المحفظة:</span>
                          <span className="text-zinc-300 font-bold">{m.owner_name}</span>
                        </div>
                      </div>

                      {/* Instructions */}
                      {m.instructions && (
                        <p className="text-xs text-zinc-400 bg-zinc-900/50 p-3 rounded-2xl border border-zinc-800/80 leading-relaxed">
                          {m.instructions}
                        </p>
                      )}

                      {/* Action Buttons: Toggle, Edit, Delete */}
                      <div className="flex items-center justify-between gap-2 pt-3 border-t border-zinc-800/80 flex-wrap">
                        {/* Toggle Visibility Button (إخفاء / إظهار) */}
                        <button
                          type="button"
                          onClick={() => adminTogglePaymentMethodActive(m.id)}
                          className={`px-3 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 shadow-sm ${
                            isEnabled
                              ? 'bg-amber-500/15 hover:bg-amber-500/25 text-amber-300 border border-amber-500/30'
                              : 'bg-emerald-500/15 hover:bg-emerald-500/25 text-emerald-300 border border-emerald-500/30'
                          }`}
                          title={isEnabled ? 'إخفاء طريقة الدفع عن العملاء في واجهة الشراء دون حذفها' : 'إظهار وتفعيل طريقة الدفع للعملاء في واجهة الشراء فوراً'}
                        >
                          {isEnabled ? (
                            <>
                              <EyeOff className="w-3.5 h-3.5" />
                              <span>إخفاء عن الواجهة</span>
                            </>
                          ) : (
                            <>
                              <Eye className="w-3.5 h-3.5" />
                              <span>إظهار في الواجهة</span>
                            </>
                          )}
                        </button>

                        <div className="flex items-center gap-2">
                          {/* Edit Button */}
                          <button
                            type="button"
                            onClick={() => handleOpenEditMethod(m)}
                            className="px-3 py-2 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-zinc-200 hover:text-white text-xs font-bold border border-zinc-700 flex items-center gap-1.5 transition-colors"
                            title="تعديل اسم أو رقم أو تعليمات وسيلة الدفع"
                          >
                            <Edit className="w-3.5 h-3.5" />
                            <span>تعديل</span>
                          </button>

                          {/* Delete Button (زر حذف طريقة الدفع) */}
                          <button
                            type="button"
                            onClick={() => setDeletingMethod(m)}
                            className="px-3 py-2 rounded-xl bg-red-500/15 hover:bg-red-500/25 text-red-400 hover:text-red-300 border border-red-500/30 text-xs font-bold flex items-center gap-1.5 transition-colors"
                            title="حذف طريقة الدفع نهائياً من قاعدة البيانات والواجهة"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                            <span>حذف</span>
                          </button>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            );
          })()}
        </div>
      )}

      {/* TAB: COUNTRIES MANAGEMENT */}
      {activeTab === 'countries' && (
        <div className="space-y-4">
          <div className="bg-[#161616] p-4 rounded-2xl border border-[#2A2A2A] flex flex-col md:flex-row justify-between items-start md:items-center gap-3">
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-sm font-bold text-white">إدارة الـ 14 دولة المدعومة في المنصة 🌍</h3>
                <span className="text-[10px] bg-emerald-500/20 text-emerald-400 font-bold px-2 py-0.5 rounded-full border border-emerald-500/30">
                  متصل بـ Supabase
                </span>
              </div>
              <p className="text-xs text-zinc-400 mt-0.5">
                تتزامن حالة الدول، العملات، وأسعار الرسوم لحظياً مع قاعدة بيانات Supabase ومع تطبيق الهاتف المحمول.
              </p>
            </div>

            <div className="flex items-center gap-2 w-full md:w-auto">
              <button
                type="button"
                onClick={handleSeedCountries}
                disabled={isSeedingCountries}
                className="px-3 py-2 bg-emerald-600/90 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 shadow-md shadow-emerald-600/20 disabled:opacity-50"
                title="مزامنة وحفظ جميع الـ 14 دولة في جدول countries على Supabase"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${isSeedingCountries ? 'animate-spin' : ''}`} />
                <span>{isSeedingCountries ? 'جاري المزامنة...' : 'مزامنة الـ 14 دولة مع سوبابيز'}</span>
              </button>

              <span className="px-3 py-2 bg-zinc-800 text-zinc-300 rounded-xl text-xs font-bold shrink-0">
                المفعّلة: {countries.filter(c => c.is_active).length} / {countries.length}
              </span>
            </div>
          </div>

          {seedingCountriesMsg && (
            <div className={`p-3 rounded-xl text-xs flex items-center gap-2 animate-fadeIn ${
              seedingCountriesMsg.includes('بنجاح')
                ? 'bg-emerald-950/40 border border-emerald-500/40 text-emerald-300'
                : 'bg-red-950/40 border border-red-500/40 text-red-300'
            }`}>
              <CheckCircle2 className="w-4 h-4 shrink-0" />
              <span>{seedingCountriesMsg}</span>
            </div>
          )}

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {countries.map(country => (
              <div
                key={country.code}
                className={`bg-[#161616] border rounded-2xl p-4 space-y-3 transition-all ${
                  country.is_active ? 'border-zinc-700 shadow-lg' : 'border-zinc-800/60 opacity-60 bg-zinc-950/40'
                }`}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <span className="text-3xl">{country.flag_emoji}</span>
                    <div>
                      <h4 className="text-sm font-bold text-white flex items-center gap-2">
                        <span>{country.name_ar}</span>
                        <span className="text-[10px] font-mono bg-zinc-800 px-1.5 py-0.5 rounded text-zinc-300">{country.code}</span>
                      </h4>
                      <p className="text-xs text-zinc-400">{country.full_name_ar || country.name_ar}</p>
                    </div>
                  </div>

                  <button
                    onClick={() => adminToggleCountryActive(country.code)}
                    className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
                      country.is_active
                        ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 hover:bg-emerald-500/30'
                        : 'bg-zinc-800 text-zinc-400 border border-zinc-700 hover:bg-zinc-700 hover:text-white'
                    }`}
                  >
                    {country.is_active ? (
                      <>
                        <Eye className="w-3.5 h-3.5" />
                        <span>مفعلة (تظهر)</span>
                      </>
                    ) : (
                      <>
                        <XCircle className="w-3.5 h-3.5" />
                        <span>مخفية (معطلة)</span>
                      </>
                    )}
                  </button>
                </div>

                <div className="grid grid-cols-2 gap-2 pt-2 border-t border-zinc-800/80 text-xs">
                  <div className="bg-black/40 p-2 rounded-xl">
                    <span className="text-zinc-500 block text-[10px]">العملة المحلية:</span>
                    <strong className="text-white">{country.currency_name_ar || country.currency_code} ({country.currency_symbol})</strong>
                  </div>
                  <div className="bg-black/40 p-2 rounded-xl">
                    <span className="text-zinc-500 block text-[10px]">رسوم الطلب الافتراضية:</span>
                    <strong className="text-emerald-400">{country.order_fee || 10} {country.currency_symbol}</strong>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB: ADMINS & MODERATORS */}
      {activeTab === 'admins' && (
        <div className="space-y-6">
          {/* Header & Status message */}
          {modStatusMsg && (
            <div className={`p-4 rounded-2xl text-xs font-bold flex items-center gap-2.5 animate-fadeIn border ${
              modStatusMsg.type === 'success'
                ? 'bg-emerald-950/40 border-emerald-500/40 text-emerald-200'
                : 'bg-red-950/40 border-red-500/40 text-red-200'
            }`}>
              {modStatusMsg.type === 'success' ? (
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
              ) : (
                <AlertCircle className="w-4 h-4 text-red-400 shrink-0" />
              )}
              <span>{modStatusMsg.text}</span>
            </div>
          )}

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            {/* Left: Add Moderator Form */}
            <div className="lg:col-span-6 bg-[#161616] border border-[#2A2A2A] rounded-3xl p-6 space-y-5">
              <div className="flex items-center justify-between pb-3 border-b border-zinc-800">
                <div className="flex items-center gap-2.5">
                  <div className="w-9 h-9 rounded-xl bg-blue-500/10 text-blue-400 flex items-center justify-center border border-blue-500/20">
                    <UserPlus className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="text-base font-bold text-white">إضافة مشرف جديد للوحة التحكم 🛡️</h3>
                    <p className="text-xs text-zinc-400 mt-0.5">
                      منح صلاحية إدارة ومراجعة الطلبات والمنتجات لأي بريد إلكتروني
                    </p>
                  </div>
                </div>
                <span className="text-[10px] bg-blue-500/10 text-blue-400 border border-blue-500/20 px-2.5 py-1 rounded-full font-bold">
                  مشرف (Moderator)
                </span>
              </div>

              <form onSubmit={handleAddModerator} className="space-y-4">
                <div>
                  <label className="text-xs font-bold text-zinc-300 block mb-1.5">
                    البريد الإلكتروني للمشرف (Gmail): <span className="text-red-400">*</span>
                  </label>
                  <input
                    type="email"
                    required
                    placeholder="example@gmail.com"
                    value={newModEmail}
                    onChange={(e) => setNewModEmail(e.target.value)}
                    className="w-full bg-[#0B0B0B] text-white text-sm rounded-xl px-3.5 py-2.5 border border-zinc-700 focus:outline-none focus:border-[#E50914] dir-ltr text-left font-mono"
                  />
                  <p className="text-[11px] text-zinc-500 mt-1">
                    سيتمكن صاحب هذا البريد من الدخول عبر زر Google الرسمي ومباشرة مهام الإشراف فوراً.
                  </p>
                </div>

                <div>
                  <label className="text-xs font-bold text-zinc-300 block mb-1.5">
                    اسم المشرف أو المسمى الوظيفي (اختياري):
                  </label>
                  <input
                    type="text"
                    placeholder="مثال: أحمد - مسؤول خدمة العملاء"
                    value={newModName}
                    onChange={(e) => setNewModName(e.target.value)}
                    className="w-full bg-[#0B0B0B] text-white text-sm rounded-xl px-3.5 py-2.5 border border-zinc-700 focus:outline-none focus:border-[#E50914]"
                  />
                </div>

                <button
                  type="submit"
                  disabled={isAddingMod}
                  className="w-full py-3.5 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white text-xs font-bold transition-all shadow-md shadow-blue-600/20 flex items-center justify-center gap-2 disabled:opacity-50"
                >
                  {isAddingMod ? (
                    <>
                      <RefreshCw className="w-4 h-4 animate-spin" />
                      <span>جاري إضافة المشرف ومزامنته سحابياً...</span>
                    </>
                  ) : (
                    <>
                      <UserCheck className="w-4 h-4" />
                      <span>منح صلاحية الإشراف وحفظ الحساب</span>
                    </>
                  )}
                </button>
              </form>

              {/* Security Guard Guarantee Notice */}
              <div className="p-4 rounded-2xl bg-[#0B0B0B] border border-zinc-800 text-xs text-zinc-400 space-y-2">
                <div className="flex items-center gap-2 text-amber-300 font-bold">
                  <ShieldAlert className="w-4 h-4 text-amber-400 shrink-0" />
                  <span>ضمان حماية المالك الأصلي:</span>
                </div>
                <p className="text-[11px] leading-relaxed">
                  حساب المالك الأساسي (<code className="text-amber-300 font-mono">mohmdfartka00@gmail.com</code>) محمي بحصانة برمجية كاملة، ولا يملك أي مشرف حق حذفه أو سحب صلاحياته أو تغيير ملكية المتجر تحت أي ظرف.
                </p>
              </div>
            </div>

            {/* Right: Existing Admins & Moderators List */}
            <div className="lg:col-span-6 space-y-4">
              {/* Owner Permanent Card */}
              <div className="bg-gradient-to-br from-[#1c160e] to-[#161616] border border-amber-500/40 rounded-3xl p-5 shadow-lg shadow-amber-500/5 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="text-xl">👑</span>
                    <div>
                      <span className="text-xs font-black text-amber-300 block">مالك المنصة والمدير العام</span>
                      <span className="text-[10px] text-zinc-400">Owner & Super Admin (محمي دائمًا)</span>
                    </div>
                  </div>
                  <span className="px-2.5 py-1 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/40 text-[10px] font-bold">
                    حساب محمي 🔒
                  </span>
                </div>

                <div className="p-3 bg-[#0B0B0B] rounded-2xl border border-amber-500/20 flex items-center justify-between">
                  <div>
                    <span className="text-xs font-mono font-bold text-white block dir-ltr text-right">
                      mohmdfartka00@gmail.com
                    </span>
                    <span className="text-[10px] text-zinc-400">محمد (المالك الرئيسي)</span>
                  </div>
                  <span className="text-[10px] text-emerald-400 font-bold bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20">
                    نشط دائمًا
                  </span>
                </div>
              </div>

              {/* Moderators List */}
              <div className="bg-[#161616] border border-[#2A2A2A] rounded-3xl p-6 space-y-4">
                <div className="flex items-center justify-between pb-3 border-b border-zinc-800">
                  <div>
                    <h4 className="text-sm font-bold text-white">قائمة المشرفين المعتمدين ({moderators.length})</h4>
                    <p className="text-[11px] text-zinc-400">الحسابات التي تم منحها حق الدخول والإدارة</p>
                  </div>
                  <span className="text-[10px] text-zinc-500 font-mono">Sync with Cloud</span>
                </div>

                {moderators.length === 0 ? (
                  <div className="py-8 text-center bg-[#0B0B0B] rounded-2xl border border-dashed border-zinc-800 space-y-2">
                    <Users className="w-8 h-8 text-zinc-600 mx-auto" />
                    <p className="text-xs text-zinc-400">لا يوجد مشرفين إضافيين مضافين حالياً</p>
                    <p className="text-[10px] text-zinc-500">يمكن للمالك إضافة أي بريد إلكتروني من النموذج باليسار.</p>
                  </div>
                ) : (
                  <div className="space-y-2.5">
                    {moderators.map((mod) => (
                      <div
                        key={mod.email}
                        className="p-3.5 rounded-2xl bg-[#0B0B0B] border border-zinc-800 hover:border-zinc-700 transition-all flex items-center justify-between gap-3"
                      >
                        <div className="flex items-center gap-3">
                          <div className="w-9 h-9 rounded-xl bg-blue-500/10 text-blue-400 flex items-center justify-center border border-blue-500/20 shrink-0">
                            <ShieldCheck className="w-4 h-4" />
                          </div>
                          <div>
                            <div className="flex items-center gap-2">
                              <span className="text-xs font-bold text-white">{mod.name || 'مشرف معتمد'}</span>
                              <span className="text-[10px] bg-blue-500/15 text-blue-300 px-1.5 py-0.5 rounded font-mono">
                                Moderator
                              </span>
                            </div>
                            <span className="text-xs font-mono text-zinc-400 block mt-0.5 dir-ltr text-right">
                              {mod.email}
                            </span>
                            {mod.added_at && (
                              <span className="text-[10px] text-zinc-500 block">
                                أضيف في: {new Date(mod.added_at).toLocaleDateString('ar-EG')}
                              </span>
                            )}
                          </div>
                        </div>

                        {/* Remove button (Only owner or authorized admin can remove) */}
                        <button
                          type="button"
                          onClick={() => handleRemoveModerator(mod.email)}
                          className="px-3 py-1.5 rounded-xl bg-red-500/10 hover:bg-red-500/20 text-red-400 text-xs font-bold border border-red-500/20 transition-all flex items-center gap-1 shrink-0"
                          title="سحب صلاحية الإشراف وحذف الحساب"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                          <span>حذف المشرف</span>
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 4: STATS */}
      {activeTab === 'stats' && (
        <div className="space-y-6">
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            <div className="bg-[#161616] border border-emerald-500/30 p-5 rounded-2xl space-y-1">
              <p className="text-xs text-zinc-400">إجمالي الإيرادات المحصلة</p>
              <p className="text-2xl font-black text-emerald-400">{totalRevenue} {activeCurrency}</p>
            </div>
            <div className="bg-[#161616] border border-amber-500/30 p-5 rounded-2xl space-y-1">
              <p className="text-xs text-zinc-400">طلبات دفع قيد المراجعة</p>
              <p className="text-2xl font-black text-amber-300">{pendingCount}</p>
            </div>
            <div className="bg-[#161616] border border-zinc-800 p-5 rounded-2xl space-y-1">
              <p className="text-xs text-zinc-400">طلبات مدفوعة ومقبولة</p>
              <p className="text-2xl font-black text-white">{approvedCount}</p>
            </div>
            <div className="bg-[#161616] border border-red-500/30 p-5 rounded-2xl space-y-1">
              <p className="text-xs text-zinc-400">عمليات دفع مرفوضة</p>
              <p className="text-2xl font-black text-red-400">{rejectedCount}</p>
            </div>
          </div>
        </div>
      )}

      {/* TAB 5: SETTINGS */}
      {activeTab === 'settings' && (
        <div className="space-y-6">
          {/* Master Killswitch Card: Payment Gateway & Fee Bypass */}
          <div className={`p-6 rounded-3xl border transition-all ${
            isPaymentGatewayEnabled
              ? 'bg-[#18130e] border-amber-500/30'
              : 'bg-[#0f1712] border-emerald-500/30'
          }`}>
            <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
              <div className="flex items-start gap-3.5">
                <div className={`w-12 h-12 rounded-2xl flex items-center justify-center border shrink-0 ${
                  isPaymentGatewayEnabled
                    ? 'bg-amber-500/10 text-amber-400 border-amber-500/20'
                    : 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20'
                }`}>
                  <Zap className="w-6 h-6" />
                </div>
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <h3 className="text-lg font-black text-white">قاطع بوابة ورسوم الدفع (Master Switch) ⚡</h3>
                    <span className={`text-[10px] px-2.5 py-0.5 rounded-full font-black border ${
                      isPaymentGatewayEnabled
                        ? 'bg-amber-500/20 text-amber-300 border-amber-500/30'
                        : 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30'
                    }`}>
                      {isPaymentGatewayEnabled ? 'الرسوم مفعلة (10 جنيه)' : 'الرسوم معطلة (الطلبات مجانية فوراً)'}
                    </span>
                  </div>
                  <p className="text-xs text-zinc-400 leading-relaxed max-w-2xl">
                    {isPaymentGatewayEnabled
                      ? 'بوابة الدفع والرسوم (10 جنيه أو عملة الدولة) مفعلة حالياً. يُطلب من المستخدم إرفاق إيصال التحويل للمراجعة.'
                      : 'بوابة الدفع معطلة ومُلغاة. عند نقر المستخدم على "شراء الطلب"، يتم إعطاؤه الرابط المباشر للمنتج والكوبون فوراً بنقرة واحدة وبدون أي رسوم.'}
                  </p>
                </div>
              </div>

              <button
                type="button"
                disabled={isTogglingGateway}
                onClick={handleTogglePaymentGateway}
                className={`px-6 py-3.5 rounded-2xl text-xs sm:text-sm font-black transition-all flex items-center gap-2.5 shadow-lg disabled:opacity-50 shrink-0 ${
                  isPaymentGatewayEnabled
                    ? 'bg-gradient-to-r from-red-600 to-amber-600 hover:from-red-500 hover:to-amber-500 text-white shadow-red-600/20'
                    : 'bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white shadow-emerald-600/20'
                }`}
              >
                {isTogglingGateway ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin" />
                    <span>جاري التبديل...</span>
                  </>
                ) : isPaymentGatewayEnabled ? (
                  <>
                    <Power className="w-4 h-4" />
                    <span>إلغاء بوابة الدفع وجعل الطلبات مجانية 🚀</span>
                  </>
                ) : (
                  <>
                    <Power className="w-4 h-4" />
                    <span>إعادة تفعيل بوابة الدفع والرسوم 💳</span>
                  </>
                )}
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Main Country Settings Form */}
          <div className="lg:col-span-7 bg-[#161616] border border-[#2A2A2A] rounded-3xl p-6 space-y-5">
            <div className="flex items-center justify-between pb-3 border-b border-zinc-800">
              <div>
                <h3 className="text-base font-bold text-white">إعدادات المنصة ورسوم الخدمة للدول 🌍</h3>
                <p className="text-xs text-zinc-400 mt-0.5">
                  تحديد رسوم تفعيل الرابط ومدة صلاحية الطلب لكل دولة بشكل منفصل في جدول settings
                </p>
              </div>
              <span className="text-[10px] bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 px-2.5 py-1 rounded-full font-bold">
                Supabase Settings
              </span>
            </div>

            {settingsSavedMsg && (
              <div className="p-3 bg-emerald-950/40 border border-emerald-500/40 rounded-2xl text-xs text-emerald-300 flex items-center gap-2 animate-fadeIn">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>{settingsSavedMsg}</span>
              </div>
            )}

            <div className="space-y-4">
              <div>
                <label className="text-xs font-bold text-zinc-300 block mb-1.5">
                  اختر الدولة لتعديل إعداداتها:
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {countries.map(c => {
                    const isSelected = settingsCountry === c.code;
                    const cFee = getOrderFeeForCountry(c.code);
                    return (
                      <button
                        key={c.code}
                        type="button"
                        onClick={() => handleSelectSettingsCountry(c.code)}
                        className={`p-3 rounded-2xl border text-right transition-all flex flex-col gap-1 ${
                          isSelected
                            ? 'bg-[#E50914]/15 border-[#E50914] text-white shadow-lg shadow-[#E50914]/10'
                            : 'bg-[#0B0B0B] border-[#2A2A2A] text-zinc-400 hover:text-white hover:border-zinc-700'
                        }`}
                      >
                        <div className="flex items-center gap-1.5">
                          <span className="text-base">{c.flag_emoji}</span>
                          <span className="text-xs font-bold truncate">{c.name_ar}</span>
                        </div>
                        <span className="text-[10px] text-emerald-400 font-bold font-mono">
                          {cFee} {c.currency_symbol}
                        </span>
                      </button>
                    );
                  })}
                </div>
              </div>

              <div className="p-4 rounded-2xl bg-[#0B0B0B] border border-zinc-800 space-y-3.5">
                <div className="flex items-center justify-between pb-2 border-b border-zinc-800/80">
                  <span className="text-xs font-bold text-white flex items-center gap-1.5">
                    <span>تعديل إعدادات:</span>
                    <span className="text-[#FF3344] font-bold">
                      {countries.find(c => c.code === settingsCountry)?.flag_emoji} {countries.find(c => c.code === settingsCountry)?.name_ar} ({settingsCountry})
                    </span>
                  </span>
                  <span className="text-[10px] text-zinc-500 font-mono">
                    Key: orderFee_{settingsCountry}
                  </span>
                </div>

                <div>
                  <label className="text-xs font-bold text-zinc-300 block mb-1">
                    رسوم خدمة الطلب لدولة ({countries.find(c => c.code === settingsCountry)?.name_ar || settingsCountry}):
                  </label>
                  <div className="relative">
                    <input
                      type="number"
                      step="any"
                      min="0"
                      value={newFee}
                      onChange={(e) => setNewFee(e.target.value)}
                      className="w-full bg-[#161616] text-white text-sm rounded-xl px-3.5 py-2.5 border border-zinc-700 focus:outline-none focus:border-[#E50914]"
                    />
                    <span className="absolute left-3 top-2.5 text-xs text-zinc-400 font-bold">
                      {countries.find(c => c.code === settingsCountry)?.currency_symbol || 'ج.م'}
                    </span>
                  </div>
                </div>

                <div>
                  <label className="text-xs font-bold text-zinc-300 block mb-1">
                    مهلة صلاحية رابط الطلب (بالدقائق):
                  </label>
                  <div className="relative">
                    <input
                      type="number"
                      min="1"
                      value={newExpiry}
                      onChange={(e) => setNewExpiry(e.target.value)}
                      className="w-full bg-[#161616] text-white text-sm rounded-xl px-3.5 py-2.5 border border-zinc-700 focus:outline-none focus:border-[#E50914]"
                    />
                    <span className="absolute left-3 top-2.5 text-xs text-zinc-400 font-bold">
                      دقيقة
                    </span>
                  </div>
                </div>

                <div>
                  <label className="text-xs font-bold text-zinc-300 block mb-1">
                    اسم العملة:
                  </label>
                  <input
                    type="text"
                    value={newCurrency}
                    onChange={(e) => setNewCurrency(e.target.value)}
                    className="w-full bg-[#161616] text-white text-sm rounded-xl px-3.5 py-2.5 border border-zinc-700 focus:outline-none focus:border-[#E50914]"
                  />
                </div>
              </div>

              <button
                type="button"
                disabled={isSavingSettings}
                onClick={async () => {
                  try {
                    setIsSavingSettings(true);
                    const feeNum = parseFloat(newFee) || 10;
                    const expNum = parseInt(newExpiry, 10) || 30;
                    await adminUpdateCountrySettings(
                      settingsCountry,
                      feeNum,
                      expNum,
                      newCurrency.trim(),
                      countries.find(c => c.code === settingsCountry)?.currency_symbol
                    );
                    setSettingsSavedMsg(`تم حفظ إعدادات ${countries.find(c => c.code === settingsCountry)?.name_ar} (الرسوم: ${feeNum}، المدة: ${expNum} دقيقة) بنجاح ومزامنتها سحابياً!`);
                  } catch (e: any) {
                    alert('تعذر حفظ الإعدادات: ' + (e?.message || 'خطأ غير معروف'));
                  } finally {
                    setIsSavingSettings(false);
                  }
                }}
                className="w-full py-3.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold transition-all shadow-md shadow-emerald-600/20 flex items-center justify-center gap-2 disabled:opacity-50"
              >
                {isSavingSettings ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin" />
                    <span>جاري الحفظ في Supabase...</span>
                  </>
                ) : (
                  <>
                    <Save className="w-4 h-4" />
                    <span>حفظ وتطبيق إعدادات {countries.find(c => c.code === settingsCountry)?.name_ar} سحابياً</span>
                  </>
                )}
              </button>
            </div>
          </div>

          {/* Right Side: Countries Settings Matrix Overview */}
          <div className="lg:col-span-5 bg-[#161616] border border-[#2A2A2A] rounded-3xl p-6 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-zinc-800">
              <h4 className="text-sm font-bold text-white">ملخص إعدادات الدول الحالية</h4>
              <span className="text-[10px] text-zinc-500 font-mono">Real-time</span>
            </div>

            <div className="space-y-2.5">
              {countries.map(c => {
                const cFee = getOrderFeeForCountry(c.code);
                const cExpiry = getOrderExpiryForCountry(c.code);
                const isSelected = settingsCountry === c.code;

                return (
                  <div
                    key={c.code}
                    className={`p-3.5 rounded-2xl border transition-all flex items-center justify-between ${
                      isSelected
                        ? 'bg-zinc-900 border-zinc-700'
                        : 'bg-[#0B0B0B] border-zinc-800/80'
                    }`}
                  >
                    <div className="flex items-center gap-2.5">
                      <span className="text-xl">{c.flag_emoji}</span>
                      <div>
                        <div className="flex items-center gap-1.5">
                          <span className="text-xs font-bold text-white">{c.name_ar}</span>
                          <span className="text-[10px] font-mono text-zinc-500">({c.code})</span>
                        </div>
                        <span className="text-[11px] text-zinc-400 block mt-0.5">
                          مهلة الطلب: <strong className="text-zinc-200">{cExpiry} دقيقة</strong>
                        </span>
                      </div>
                    </div>

                    <div className="text-left flex flex-col items-end gap-1">
                      <span className="text-xs font-black text-emerald-400 font-mono">
                        {cFee} {c.currency_symbol}
                      </span>
                      <button
                        type="button"
                        onClick={() => handleSelectSettingsCountry(c.code)}
                        className="text-[10px] text-[#FF3344] hover:underline font-bold"
                      >
                        تعديل ✏️
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>

            <div className="p-3.5 rounded-2xl bg-[#0B0B0B] border border-zinc-800/80 text-[11px] text-zinc-400 space-y-1">
              <p className="font-bold text-zinc-300">ملاحظة التوحيد:</p>
              <p>يتم تخزين الرسوم ومُهل الصلاحية في جدول <code className="text-emerald-400 font-mono">settings</code> بمفاتيح ديناميكية (<code className="text-emerald-400 font-mono">orderFee_EG</code>, <code className="text-emerald-400 font-mono">orderFee_SA</code>, إلخ)، مما يضمن تطابقاً بنسبة 100% بين الموقع وتطبيق الأندرويد.</p>
            </div>
          </div>
        </div>
      </div>
      )}

      {/* TAB 5: APP VERSION MANAGEMENT */}
      {activeTab === 'app_updates' && (
        <div className="space-y-6">
          {/* Top Info Banner */}
          <div className="bg-gradient-to-r from-emerald-950/40 via-[#161616] to-[#161616] border border-emerald-500/20 rounded-3xl p-6">
            <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-4">
              <div className="flex items-center gap-4">
                <div className="w-14 h-14 rounded-2xl bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400 shrink-0">
                  <Smartphone className="w-7 h-7" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h2 className="text-lg font-black text-white">إدارة وتحديث إصدارات تطبيق الأندرويد (APK)</h2>
                    <span className="px-2.5 py-0.5 rounded-full bg-emerald-500/20 border border-emerald-500/30 text-emerald-400 text-[10px] font-bold">
                      Supabase Storage: app-apks
                    </span>
                  </div>
                  <p className="text-xs text-zinc-400 mt-1">
                    قم برفع حزم الـ APK الجديدة ونشرها لمستخدمي التطبيق مع سجل التغييرات والتحكم في تفعيل الإصدارات المتاحة للتحميل.
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-3 w-full lg:w-auto">
                <div className="bg-[#0B0B0B] border border-zinc-800 rounded-2xl px-4 py-2.5 flex-1 lg:flex-none">
                  <div className="text-[10px] text-zinc-400">الإصدار النشط حالياً</div>
                  <div className="text-sm font-black text-emerald-400 flex items-center gap-1.5 mt-0.5">
                    <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
                    {appUpdates.find(u => u.is_active)?.version_name || 'لا يوجد إصدار نشط'}
                    {appUpdates.find(u => u.is_active) && (
                      <span className="text-[10px] text-zinc-500 font-mono">
                        (Code: {appUpdates.find(u => u.is_active)?.version_code})
                      </span>
                    )}
                  </div>
                </div>

                <div className="bg-[#0B0B0B] border border-zinc-800 rounded-2xl px-4 py-2.5 flex-1 lg:flex-none">
                  <div className="text-[10px] text-zinc-400">إجمالي الإصدارات</div>
                  <div className="text-sm font-black text-white mt-0.5 font-mono">
                    {appUpdates.length} إصدارات
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* 2-Column Grid: Upload Form + History List */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            {/* Left: Upload Form (5 cols) */}
            <div className="lg:col-span-5 bg-[#161616] border border-[#2A2A2A] rounded-3xl p-6 space-y-5">
              <div className="flex items-center justify-between pb-3 border-b border-zinc-800">
                <div className="flex items-center gap-2">
                  <Upload className="w-4 h-4 text-[#E50914]" />
                  <h3 className="text-sm font-bold text-white">رفع ونشر إصدار جديد (APK)</h3>
                </div>
                <span className="text-[10px] bg-zinc-800 text-zinc-400 px-2 py-0.5 rounded-md font-mono">
                  معالج الحزم
                </span>
              </div>

              {/* Source Mode Toggle: Direct File vs External URL */}
              <div className="grid grid-cols-2 gap-1.5 p-1 bg-[#0B0B0B] border border-zinc-800 rounded-2xl">
                <button
                  type="button"
                  onClick={() => setApkSourceMode('file')}
                  className={`py-2 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 ${
                    apkSourceMode === 'file'
                      ? 'bg-[#E50914] text-white shadow-md'
                      : 'text-zinc-400 hover:text-white'
                  }`}
                >
                  <Upload className="w-3.5 h-3.5" />
                  <span>رفع ملف APK</span>
                </button>

                <button
                  type="button"
                  onClick={() => setApkSourceMode('custom_url')}
                  className={`py-2 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 ${
                    apkSourceMode === 'custom_url'
                      ? 'bg-[#E50914] text-white shadow-md'
                      : 'text-zinc-400 hover:text-white'
                  }`}
                >
                  <ExternalLink className="w-3.5 h-3.5" />
                  <span>رابط مباشر خارجي</span>
                </button>
              </div>

              {apkUploadSuccessMsg && (
                <div className="p-3.5 bg-emerald-950/40 border border-emerald-500/40 rounded-2xl text-xs text-emerald-300 flex items-start gap-2 animate-fadeIn">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                  <span>{apkUploadSuccessMsg}</span>
                </div>
              )}

              {apkUploadErrorMsg && (
                <div className="p-3.5 bg-red-950/40 border border-red-500/40 rounded-2xl text-xs text-red-300 flex items-start gap-2 animate-fadeIn">
                  <AlertCircle className="w-4 h-4 text-red-400 shrink-0 mt-0.5" />
                  <span>{apkUploadErrorMsg}</span>
                </div>
              )}

              <form onSubmit={handlePublishApkUpdate} className="space-y-4">
                {apkSourceMode === 'file' ? (
                  /* File Upload Box */
                  <div>
                    <label className="text-xs font-bold text-zinc-300 block mb-1.5">
                      ملف الـ APK <span className="text-red-400">*</span>
                    </label>
                    <label className={`border-2 border-dashed rounded-2xl p-5 flex flex-col items-center justify-center cursor-pointer transition-all ${
                      selectedApkFile
                        ? 'border-emerald-500/60 bg-emerald-500/5'
                        : 'border-zinc-700 hover:border-[#E50914] bg-[#0B0B0B]'
                    }`}>
                      <input
                        type="file"
                        accept=".apk,application/vnd.android.package-archive"
                        onChange={handleApkFileChange}
                        className="hidden"
                        disabled={isUploadingApk}
                      />
                      {selectedApkFile ? (
                        <div className="text-center space-y-1.5">
                          <div className="w-10 h-10 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center mx-auto">
                            <FileCode className="w-5 h-5" />
                          </div>
                          <p className="text-xs font-bold text-white max-w-[240px] truncate">
                            {selectedApkFile.name}
                          </p>
                          <p className="text-[11px] text-emerald-400 font-mono">
                            الحجم: {(selectedApkFile.size / (1024 * 1024)).toFixed(2)} MB
                          </p>
                          <span className="text-[10px] text-zinc-400 underline block pt-1 hover:text-white">
                            اضغط للتغيير
                          </span>
                        </div>
                      ) : (
                        <div className="text-center space-y-2">
                          <div className="w-10 h-10 rounded-xl bg-zinc-800 text-zinc-400 flex items-center justify-center mx-auto">
                            <Smartphone className="w-5 h-5" />
                          </div>
                          <div>
                            <p className="text-xs font-bold text-zinc-200">
                              اضغط لاختيار ملف الـ APK من جهازك
                            </p>
                            <p className="text-[10px] text-zinc-500 mt-0.5">
                              سيتم فحصه والتحقق من توافقه مع جميع إصدارات أندرويد تلقائياً
                            </p>
                          </div>
                        </div>
                      )}
                    </label>
                  </div>
                ) : (
                  /* Custom URL Input */
                  <div>
                    <label className="text-xs font-bold text-zinc-300 block mb-1.5">
                      رابط تحميل الـ APK المباشر <span className="text-red-400">*</span>
                    </label>
                    <input
                      type="url"
                      required
                      value={apkCustomUrl}
                      onChange={(e) => setApkCustomUrl(e.target.value)}
                      placeholder="https://your-domain.com/releases/app-v1.0.apk"
                      disabled={isUploadingApk}
                      className="w-full bg-[#0B0B0B] text-white text-xs rounded-xl p-3 border border-zinc-700 focus:outline-none focus:border-[#E50914] font-mono"
                    />
                    <p className="text-[10px] text-zinc-500 mt-1">
                      يدعم روابط التخزين السحابي المباشرة (Cloudflare R2, Google Cloud, MediaFire, أو السيرفر الخاص)
                    </p>
                  </div>
                )}

                {/* Real-time Android Compatibility & Package Diagnostic Inspector */}
                {isAnalyzingApk && (
                  <div className="p-3.5 bg-zinc-900 border border-zinc-800 rounded-2xl text-xs text-zinc-300 flex items-center gap-2">
                    <RefreshCw className="w-4 h-4 text-emerald-400 animate-spin" />
                    <span>جاري فحص وتدقيق هيكل حزمة الأندرويد والتوافقية...</span>
                  </div>
                )}

                {apkAnalysis && (
                  <div className="p-4 bg-zinc-950/80 border border-zinc-800 rounded-2xl space-y-2.5 text-xs">
                    <div className="flex items-center justify-between pb-2 border-b border-zinc-800">
                      <div className="flex items-center gap-2">
                        <Cpu className="w-4 h-4 text-emerald-400" />
                        <span className="font-bold text-white">معالج فحص توافقية حزمة الأندرويد</span>
                      </div>
                      <span className={`px-2 py-0.5 rounded-full font-mono text-[10px] font-bold ${
                        apkAnalysis.isValidApk ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30' : 'bg-red-500/20 text-red-300 border border-red-500/30'
                      }`}>
                        {apkAnalysis.isValidApk ? 'حزمة معتمدة وصالحة' : 'حزمة غير مكتملة'}
                      </span>
                    </div>

                    <div className="grid grid-cols-2 gap-2 text-[11px]">
                      <div className="bg-[#121212] p-2 rounded-xl border border-zinc-800/60">
                        <span className="text-zinc-500 block text-[10px]">دعم إصدارات Android:</span>
                        <span className="text-zinc-200 font-bold">{apkAnalysis.supportedAndroidRange}</span>
                      </div>
                      <div className="bg-[#121212] p-2 rounded-xl border border-zinc-800/60">
                        <span className="text-zinc-500 block text-[10px]">فحص الحزمة (Manifest & Dex):</span>
                        <span className="text-zinc-200 font-bold">{apkAnalysis.hasManifest && apkAnalysis.hasDex ? 'هيكل سليم ومعتمد' : 'حزمة أولية'}</span>
                      </div>
                      <div className="bg-[#121212] p-2 rounded-xl border border-zinc-800/60">
                        <span className="text-zinc-500 block text-[10px]">توقيع الأمان (Signature):</span>
                        <span className="text-emerald-400 font-bold">{apkAnalysis.signatureScheme}</span>
                      </div>
                      <div className="bg-[#121212] p-2 rounded-xl border border-zinc-800/60">
                        <span className="text-zinc-500 block text-[10px]">حجم الحزمة:</span>
                        <span className="text-white font-mono">{apkAnalysis.fileSizeMb} MB</span>
                      </div>
                    </div>

                    {apkAnalysis.summaryMessage && (
                      <div className="p-2 bg-emerald-950/20 border border-emerald-500/20 rounded-xl text-[10px] text-emerald-300 leading-relaxed">
                        {apkAnalysis.summaryMessage}
                      </div>
                    )}
                  </div>
                )}

                {/* Version Code & Name Grid */}
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-xs font-bold text-zinc-300 block mb-1">
                      رقم الإصدار (Version Code) <span className="text-red-400">*</span>
                    </label>
                    <input
                      type="number"
                      required
                      min="1"
                      value={apkVersionCode}
                      onChange={(e) => setApkVersionCode(e.target.value)}
                      placeholder="1, 2, 3..."
                      disabled={isUploadingApk}
                      className="w-full bg-[#0B0B0B] text-white text-xs rounded-xl p-2.5 border border-zinc-700 focus:outline-none focus:border-[#E50914] font-mono"
                    />
                    <span className="text-[10px] text-zinc-500 mt-1 block">رقم تسلسلي داخلي</span>
                  </div>

                  <div>
                    <label className="text-xs font-bold text-zinc-300 block mb-1">
                      اسم الإصدار (Version Name) <span className="text-red-400">*</span>
                    </label>
                    <input
                      type="text"
                      required
                      value={apkVersionName}
                      onChange={(e) => setApkVersionName(e.target.value)}
                      placeholder="مثال: 1.0.1"
                      disabled={isUploadingApk}
                      className="w-full bg-[#0B0B0B] text-white text-xs rounded-xl p-2.5 border border-zinc-700 focus:outline-none focus:border-[#E50914] font-mono font-bold"
                    />
                    <span className="text-[10px] text-zinc-500 mt-1 block">يظهر للمستخدمين</span>
                  </div>
                </div>

                {/* Update Title */}
                <div>
                  <label className="text-xs font-bold text-zinc-300 block mb-1">
                    عنوان التحديث <span className="text-red-400">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    value={apkUpdateTitle}
                    onChange={(e) => setApkUpdateTitle(e.target.value)}
                    placeholder="مثال: تحديث الأداء والتوافق مع هواتف أندرويد"
                    disabled={isUploadingApk}
                    className="w-full bg-[#0B0B0B] text-white text-xs rounded-xl p-2.5 border border-zinc-700 focus:outline-none focus:border-[#E50914]"
                  />
                </div>

                {/* Update Description / Changelog */}
                <div>
                  <label className="text-xs font-bold text-zinc-300 block mb-1">
                    وصف التحديث وسجل التغييرات (Changelog)
                  </label>
                  <textarea
                    rows={3}
                    value={apkUpdateDescription}
                    onChange={(e) => setApkUpdateDescription(e.target.value)}
                    placeholder="اكتب التغييرات في هذا الإصدار... (مثال: - دعم جميع هواتف أندرويد 5 حتى 15، - تسريع التحميل)"
                    disabled={isUploadingApk}
                    className="w-full bg-[#0B0B0B] text-white text-xs rounded-xl p-2.5 border border-zinc-700 focus:outline-none focus:border-[#E50914]"
                  />
                </div>

                {/* Active Toggle Switch */}
                <div className="flex items-center justify-between p-3 bg-[#0B0B0B] border border-zinc-800 rounded-2xl">
                  <div>
                    <span className="text-xs font-bold text-white block">
                      تفعيل هذا الإصدار فوراً للتحميل
                    </span>
                    <span className="text-[10px] text-zinc-500">
                      سيصبح الإصدار النشط المتاح لمستخدمي الموقع والتطبيق
                    </span>
                  </div>
                  <button
                    type="button"
                    onClick={() => setApkIsActive(!apkIsActive)}
                    disabled={isUploadingApk}
                    className={`w-12 h-6 flex items-center rounded-full p-1 transition-colors ${
                      apkIsActive ? 'bg-emerald-600 justify-end' : 'bg-zinc-700 justify-start'
                    }`}
                  >
                    <span className="bg-white w-4 h-4 rounded-full shadow-md"></span>
                  </button>
                </div>

                {/* Publish Button */}
                <button
                  type="submit"
                  disabled={isUploadingApk || (apkSourceMode === 'file' ? !selectedApkFile : !apkCustomUrl.trim())}
                  className="w-full py-3 rounded-xl bg-[#E50914] hover:bg-[#b80710] disabled:opacity-50 text-white text-xs font-bold transition-all flex items-center justify-center gap-2 shadow-lg shadow-[#E50914]/25"
                >
                  {isUploadingApk ? (
                    <>
                      <RefreshCw className="w-4 h-4 animate-spin" />
                      <span>جاري رفع الـ APK وحفظ البيانات في السحابة...</span>
                    </>
                  ) : (
                    <>
                      <Upload className="w-4 h-4" />
                      <span>{apkSourceMode === 'file' ? 'نشر ورفع الإصدار للسحابة' : 'نشر وتفعيل الرابط المباشر'}</span>
                    </>
                  )}
                </button>
              </form>
            </div>

            {/* Right: Previous Releases List (7 cols) */}
            <div className="lg:col-span-7 bg-[#161616] border border-[#2A2A2A] rounded-3xl p-6 space-y-4">
              <div className="flex items-center justify-between pb-3 border-b border-zinc-800">
                <div className="flex items-center gap-2">
                  <Layers className="w-4 h-4 text-emerald-400" />
                  <h3 className="text-sm font-bold text-white">قائمة الإصدارات والتحديثات السابقة</h3>
                </div>
                <span className="text-xs text-zinc-400">
                  {appUpdates.length} إصدار مسجل
                </span>
              </div>

              {appUpdates.length === 0 ? (
                <div className="text-center py-12 space-y-3 bg-[#0B0B0B] border border-zinc-800 rounded-2xl p-6">
                  <Smartphone className="w-10 h-10 text-zinc-600 mx-auto" />
                  <p className="text-xs text-zinc-400">لا توجد إصدارات مسجلة حتى الآن.</p>
                  <p className="text-[11px] text-zinc-500">قم برفع أول إصدار APK من خلال النموذج في الجانب الأيمن.</p>
                </div>
              ) : (
                <div className="space-y-3.5 max-h-[640px] overflow-y-auto pr-1">
                  {appUpdates.map(update => {
                    const isCopied = copiedApkUrlId === update.id;
                    const health = urlHealthStatus[update.id];
                    const dateStr = new Date(update.created_at).toLocaleDateString('ar-EG', {
                      year: 'numeric',
                      month: 'short',
                      day: 'numeric',
                      hour: '2-digit',
                      minute: '2-digit'
                    });

                    return (
                      <div
                        key={update.id}
                        className={`p-4 rounded-2xl border transition-all ${
                          update.is_active
                            ? 'bg-emerald-950/20 border-emerald-500/40 shadow-sm'
                            : 'bg-[#0B0B0B] border-zinc-800 opacity-80 hover:opacity-100'
                        }`}
                      >
                        {/* Header: Version, Code, Active Badge, Date */}
                        <div className="flex flex-wrap items-center justify-between gap-2 pb-2.5 border-b border-zinc-800/80">
                          <div className="flex items-center gap-2">
                            <span className="px-2.5 py-1 rounded-xl bg-zinc-800 text-white font-mono font-black text-xs border border-zinc-700">
                              v{update.version_name}
                            </span>
                            <span className="px-2 py-0.5 rounded-lg bg-zinc-900 text-zinc-400 font-mono text-[10px] border border-zinc-800">
                              كود: {update.version_code}
                            </span>
                            {update.file_size_mb && (
                              <span className="px-2 py-0.5 rounded-lg bg-blue-950/40 text-blue-300 font-mono text-[10px] border border-blue-500/30">
                                {update.file_size_mb} MB
                              </span>
                            )}
                          </div>

                          <div className="flex items-center gap-2">
                            <span className="text-[10px] text-zinc-500">
                              {dateStr}
                            </span>
                            <button
                              type="button"
                              onClick={() => adminToggleAppUpdateActive(update.id)}
                              className={`px-2.5 py-1 rounded-xl text-[10px] font-bold border transition-colors flex items-center gap-1 ${
                                update.is_active
                                  ? 'bg-emerald-500/20 text-emerald-400 border-emerald-500/40 hover:bg-emerald-500/30'
                                  : 'bg-zinc-800 text-zinc-400 border-zinc-700 hover:text-white'
                              }`}
                              title="اضغط للتبديل بين التفعيل والإلغاء"
                            >
                              <span className={`w-1.5 h-1.5 rounded-full ${update.is_active ? 'bg-emerald-400' : 'bg-zinc-500'}`}></span>
                              <span>{update.is_active ? 'مفعل (نشط)' : 'معطل'}</span>
                            </button>
                          </div>
                        </div>

                        {/* Title & Description */}
                        <div className="py-2.5 space-y-1">
                          <h4 className="text-xs font-bold text-white">
                            {update.update_title || 'تحديث تطبيق معاك 100'}
                          </h4>
                          {update.update_description && (
                            <p className="text-[11px] text-zinc-400 whitespace-pre-line leading-relaxed">
                              {update.update_description}
                            </p>
                          )}
                        </div>

                        {/* URL Health Pill if checked */}
                        {health && (
                          <div className={`mb-2.5 px-3 py-1.5 rounded-xl text-[10px] font-bold flex items-center gap-2 ${
                            health.status === 'ok'
                              ? 'bg-emerald-500/15 border border-emerald-500/30 text-emerald-300'
                              : health.status === 'checking'
                              ? 'bg-blue-500/15 border border-blue-500/30 text-blue-300'
                              : 'bg-red-500/15 border border-red-500/30 text-red-300'
                          }`}>
                            {health.status === 'checking' && <RefreshCw className="w-3 h-3 animate-spin" />}
                            {health.status === 'ok' && <CheckCircle2 className="w-3 h-3 text-emerald-400" />}
                            {health.status === 'error' && <AlertCircle className="w-3 h-3 text-red-400" />}
                            <span>
                              {health.status === 'checking'
                                ? 'جاري اختبار وصول الرابط...'
                                : health.status === 'ok'
                                ? `الرابط يعمل بنجاح (Status: ${health.statusCode || 200}) والتحميل متاح لجميع المستخدمين!`
                                : `تنبيه: الرابط يعطي خطأ (${health.statusCode || '404/Error'}). ${health.errorMsg || 'تأكد من إعداد سياسات Supabase Storage كعامة (Public) بالأسفل.'}`}
                            </span>
                          </div>
                        )}

                        {/* Actions bar */}
                        <div className="flex flex-wrap items-center justify-between gap-2 pt-2.5 border-t border-zinc-800/80">
                          <div className="flex items-center gap-2 flex-wrap">
                            {/* Download APK */}
                            <a
                              href={update.apk_url}
                              target="_blank"
                              rel="noreferrer"
                              download
                              className="px-3 py-1.5 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-white text-[11px] font-bold border border-zinc-700 flex items-center gap-1.5 transition-colors"
                            >
                              <Download className="w-3.5 h-3.5 text-emerald-400" />
                              <span>تحميل APK</span>
                            </a>

                            {/* Test URL Health Button */}
                            <button
                              type="button"
                              onClick={() => handleTestApkUrl(update.id, update.apk_url)}
                              className="px-3 py-1.5 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-zinc-300 hover:text-white text-[11px] font-bold border border-zinc-700 flex items-center gap-1.5 transition-colors"
                              title="فحص ما إذا كان رابط التحميل يعمل بدون 404"
                            >
                              <Activity className="w-3.5 h-3.5 text-blue-400" />
                              <span>فحص الرابط</span>
                            </button>

                            {/* Copy URL */}
                            <button
                              type="button"
                              onClick={() => handleCopyApkUrl(update)}
                              className="px-3 py-1.5 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-zinc-300 hover:text-white text-[11px] font-bold border border-zinc-700 flex items-center gap-1.5 transition-colors"
                            >
                              {isCopied ? (
                                <>
                                  <Check className="w-3.5 h-3.5 text-emerald-400" />
                                  <span className="text-emerald-400">تم النسخ!</span>
                                </>
                              ) : (
                                <>
                                  <Copy className="w-3.5 h-3.5 text-zinc-400" />
                                  <span>نسخ الرابط</span>
                                </>
                              )}
                            </button>
                          </div>

                          {/* Delete Update */}
                          <button
                            type="button"
                            onClick={() => setDeletingUpdate(update)}
                            className="p-1.5 rounded-xl text-zinc-500 hover:text-red-400 hover:bg-red-500/10 transition-colors"
                            title="حذف هذا الإصدار"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          </div>

          {/* Supabase Storage Setup SQL Helper Box */}
          <div className="bg-[#121212] border border-zinc-800/80 rounded-3xl p-5 space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-xl bg-blue-500/10 text-blue-400 flex items-center justify-center">
                  <Info className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="text-xs font-bold text-white">أوامر إعداد Supabase للتخزين السحابي (app-apks) وجداول الدول والتحديثات</h4>
                  <p className="text-[11px] text-zinc-400">تضمن هذه الأوامر أن يكون مجلد الـ APK عاماً (Public) وتسمح بالتنزيل المباشر بدون أخطاء 404 أو قيود صلاحيات</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setShowStorageSetupSql(!showStorageSetupSql)}
                className="px-3 py-1.5 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-xs font-bold text-zinc-300 hover:text-white border border-zinc-700 transition-colors"
              >
                {showStorageSetupSql ? 'إخفاء أوامر SQL' : 'عرض أوامر SQL الشاملة'}
              </button>
            </div>

            {showStorageSetupSql && (
              <div className="mt-3 pt-3 border-t border-zinc-800 space-y-2.5 animate-fadeIn">
                <div className="flex items-center justify-between">
                  <span className="text-[11px] text-zinc-400">انسخ الكود وشغله في Supabase SQL Editor:</span>
                  <button
                    type="button"
                    onClick={() => {
                      const sql = `-- 1. جدول إصدارات التطبيق (app_updates)
CREATE TABLE IF NOT EXISTS public.app_updates (
  id TEXT PRIMARY KEY,
  version_name TEXT NOT NULL,
  version_code INTEGER NOT NULL,
  apk_url TEXT NOT NULL,
  update_title TEXT NOT NULL,
  update_description TEXT,
  is_active BOOLEAN DEFAULT true,
  created_at BIGINT NOT NULL
);

ALTER TABLE public.app_updates ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Allow public read app_updates" ON public.app_updates FOR SELECT USING (true);
CREATE POLICY "Allow public insert app_updates" ON public.app_updates FOR INSERT WITH CHECK (true);
CREATE POLICY "Allow public update app_updates" ON public.app_updates FOR UPDATE USING (true);
CREATE POLICY "Allow public delete app_updates" ON public.app_updates FOR DELETE USING (true);

-- 2. جدول الدول المدعومة (countries)
CREATE TABLE IF NOT EXISTS public.countries (
  code TEXT PRIMARY KEY,
  name_ar TEXT NOT NULL,
  full_name_ar TEXT,
  name_en TEXT NOT NULL,
  flag_emoji TEXT NOT NULL,
  currency_code TEXT NOT NULL,
  currency_name_ar TEXT NOT NULL,
  currency_symbol TEXT NOT NULL,
  dial_code TEXT NOT NULL,
  order_fee NUMERIC DEFAULT 10,
  is_active BOOLEAN DEFAULT true,
  display_order INTEGER DEFAULT 1
);

ALTER TABLE public.countries ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Allow public read countries" ON public.countries FOR SELECT USING (true);
CREATE POLICY "Allow public insert countries" ON public.countries FOR INSERT WITH CHECK (true);
CREATE POLICY "Allow public update countries" ON public.countries FOR UPDATE USING (true);
CREATE POLICY "Allow public delete countries" ON public.countries FOR DELETE USING (true);

-- 3. إنشاء حاوية التخزين app-apks وجعلها عامة (Public) وتطبيق سياسات الوصول
INSERT INTO storage.buckets (id, name, public) 
VALUES ('app-apks', 'app-apks', true)
ON CONFLICT (id) DO UPDATE SET public = true;

CREATE POLICY "Public APKs Access" ON storage.objects FOR SELECT USING (bucket_id = 'app-apks');
CREATE POLICY "Public APKs Upload" ON storage.objects FOR INSERT WITH CHECK (bucket_id = 'app-apks');
CREATE POLICY "Public APKs Update" ON storage.objects FOR UPDATE USING (bucket_id = 'app-apks');
CREATE POLICY "Public APKs Delete" ON storage.objects FOR DELETE USING (bucket_id = 'app-apks');

-- 4. جدول وسائل الدفع والمحافظ (payment_methods)
CREATE TABLE IF NOT EXISTS public.payment_methods (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  wallet_number TEXT NOT NULL,
  owner_name TEXT NOT NULL,
  instructions TEXT,
  icon_type TEXT,
  is_enabled BOOLEAN DEFAULT true,
  min_amount NUMERIC,
  max_amount NUMERIC,
  display_order INTEGER DEFAULT 1,
  country_code TEXT DEFAULT 'EG'
);

ALTER TABLE public.payment_methods ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Allow public read payment_methods" ON public.payment_methods FOR SELECT USING (true);
CREATE POLICY "Allow public insert payment_methods" ON public.payment_methods FOR INSERT WITH CHECK (true);
CREATE POLICY "Allow public update payment_methods" ON public.payment_methods FOR UPDATE USING (true);
CREATE POLICY "Allow public delete payment_methods" ON public.payment_methods FOR DELETE USING (true);

-- 5. تفعيل البث المباشر (Realtime) لجميع الجداول لمزامنة الموقع والتطبيق لحظياً
ALTER PUBLICATION supabase_realtime ADD TABLE IF NOT EXISTS payment_methods;
ALTER PUBLICATION supabase_realtime ADD TABLE IF NOT EXISTS app_updates;
ALTER PUBLICATION supabase_realtime ADD TABLE IF NOT EXISTS countries;`;
                      navigator.clipboard.writeText(sql);
                      setCopiedSql(true);
                      setTimeout(() => setCopiedSql(false), 2500);
                    }}
                    className="px-3 py-1 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-[11px] font-bold flex items-center gap-1 transition-colors"
                  >
                    {copiedSql ? (
                      <>
                        <Check className="w-3.5 h-3.5" />
                        <span>تم نسخ كود SQL!</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3.5 h-3.5" />
                        <span>نسخ كود SQL بالكامل</span>
                      </>
                    )}
                  </button>
                </div>

                <pre className="bg-[#0B0B0B] border border-zinc-800 rounded-2xl p-4 text-[11px] font-mono text-emerald-300 overflow-x-auto text-left leading-relaxed max-h-56">
{`-- 1. جدول إصدارات التطبيق (app_updates)
CREATE TABLE IF NOT EXISTS public.app_updates (
  id TEXT PRIMARY KEY,
  version_name TEXT NOT NULL,
  version_code INTEGER NOT NULL,
  apk_url TEXT NOT NULL,
  update_title TEXT NOT NULL,
  update_description TEXT,
  is_active BOOLEAN DEFAULT true,
  created_at BIGINT NOT NULL
);

ALTER TABLE public.app_updates ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Allow public read app_updates" ON public.app_updates FOR SELECT USING (true);
CREATE POLICY "Allow public insert app_updates" ON public.app_updates FOR INSERT WITH CHECK (true);
CREATE POLICY "Allow public update app_updates" ON public.app_updates FOR UPDATE USING (true);
CREATE POLICY "Allow public delete app_updates" ON public.app_updates FOR DELETE USING (true);

-- 2. جدول الدول المدعومة (countries)
CREATE TABLE IF NOT EXISTS public.countries (
  code TEXT PRIMARY KEY,
  name_ar TEXT NOT NULL,
  full_name_ar TEXT,
  name_en TEXT NOT NULL,
  flag_emoji TEXT NOT NULL,
  currency_code TEXT NOT NULL,
  currency_name_ar TEXT NOT NULL,
  currency_symbol TEXT NOT NULL,
  dial_code TEXT NOT NULL,
  order_fee NUMERIC DEFAULT 10,
  is_active BOOLEAN DEFAULT true,
  display_order INTEGER DEFAULT 1
);

ALTER TABLE public.countries ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Allow public read countries" ON public.countries FOR SELECT USING (true);
CREATE POLICY "Allow public insert countries" ON public.countries FOR INSERT WITH CHECK (true);
CREATE POLICY "Allow public update countries" ON public.countries FOR UPDATE USING (true);
CREATE POLICY "Allow public delete countries" ON public.countries FOR DELETE USING (true);

-- 3. إنشاء حاوية التخزين app-apks وجعلها عامة (Public) وتطبيق سياسات الوصول
INSERT INTO storage.buckets (id, name, public) 
VALUES ('app-apks', 'app-apks', true)
ON CONFLICT (id) DO UPDATE SET public = true;

CREATE POLICY "Public APKs Access" ON storage.objects FOR SELECT USING (bucket_id = 'app-apks');
CREATE POLICY "Public APKs Upload" ON storage.objects FOR INSERT WITH CHECK (bucket_id = 'app-apks');
CREATE POLICY "Public APKs Update" ON storage.objects FOR UPDATE USING (bucket_id = 'app-apks');
CREATE POLICY "Public APKs Delete" ON storage.objects FOR DELETE USING (bucket_id = 'app-apks');

-- 4. جدول وسائل الدفع والمحافظ (payment_methods)
CREATE TABLE IF NOT EXISTS public.payment_methods (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  wallet_number TEXT NOT NULL,
  owner_name TEXT NOT NULL,
  instructions TEXT,
  icon_type TEXT,
  is_enabled BOOLEAN DEFAULT true,
  min_amount NUMERIC,
  max_amount NUMERIC,
  display_order INTEGER DEFAULT 1,
  country_code TEXT DEFAULT 'EG'
);

ALTER TABLE public.payment_methods ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Allow public read payment_methods" ON public.payment_methods FOR SELECT USING (true);
CREATE POLICY "Allow public insert payment_methods" ON public.payment_methods FOR INSERT WITH CHECK (true);
CREATE POLICY "Allow public update payment_methods" ON public.payment_methods FOR UPDATE USING (true);
CREATE POLICY "Allow public delete payment_methods" ON public.payment_methods FOR DELETE USING (true);

-- 5. تفعيل البث المباشر (Realtime) لجميع الجداول لمزامنة الموقع والتطبيق لحظياً
ALTER PUBLICATION supabase_realtime ADD TABLE IF NOT EXISTS payment_methods;
ALTER PUBLICATION supabase_realtime ADD TABLE IF NOT EXISTS app_updates;
ALTER PUBLICATION supabase_realtime ADD TABLE IF NOT EXISTS countries;`}
                </pre>
              </div>
            )}
          </div>
        </div>
      )}

      {/* RECEIPT INSPECTION MODAL */}
      {inspectingReceipt && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/90 backdrop-blur-md">
          <div className="relative max-w-lg w-full bg-[#161616] border border-zinc-800 rounded-3xl overflow-hidden p-6 space-y-4">
            <div className="flex justify-between items-center pb-2 border-b border-zinc-800">
              <h3 className="text-sm font-bold text-white">إيصال التحويل — الطلب {inspectingReceipt.order_id}</h3>
              <button
                onClick={() => setInspectingReceipt(null)}
                className="p-1 rounded-full bg-zinc-800 text-zinc-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="max-h-[60vh] overflow-auto rounded-xl bg-black border border-zinc-800 flex items-center justify-center">
              <img
                src={inspectingReceipt.receipt_image_url}
                alt="Receipt Full"
                className="w-full h-auto object-contain"
              />
            </div>

            <div className="flex gap-2">
              <button
                onClick={() => {
                  adminApprovePayment(inspectingReceipt.payment_id, inspectingReceipt.order_id);
                  setInspectingReceipt(null);
                }}
                className="flex-1 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold"
              >
                قبول وتفعيل الرابط
              </button>
              <button
                onClick={() => {
                  const target = inspectingReceipt;
                  setInspectingReceipt(null);
                  setRejectingPayment(target);
                }}
                className="flex-1 py-2.5 bg-red-600 hover:bg-red-500 text-white rounded-xl text-xs font-bold"
              >
                رفض الإيصال
              </button>
            </div>
          </div>
        </div>
      )}

      {/* REJECTION REASON MODAL */}
      {rejectingPayment && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/90 backdrop-blur-md">
          <div className="relative max-w-sm w-full bg-[#161616] border border-red-500/40 rounded-3xl p-6 space-y-4">
            <h3 className="text-base font-black text-white">تأكيد رفض الإيصال</h3>
            <p className="text-xs text-zinc-400">
              اختر أو اكتب سبب الرفض ليظهر للعميل بوضوح في حسابه:
            </p>

            <select
              value={rejectReason}
              onChange={(e) => setRejectReason(e.target.value)}
              className="w-full bg-[#0B0B0B] text-white text-xs rounded-xl p-3 border border-zinc-700"
            >
              <option value="صورة الإيصال غير واضحة أو ناقصة">صورة الإيصال غير واضحة أو ناقصة</option>
              <option value="المبلغ المحول غير مطابق (أقل من الرسوم المطلوبة)">المبلغ المحول غير مطابق (أقل من الرسوم)</option>
              <option value="رقم العملية غير موجود في كشف حساب المحفظة">رقم العملية غير موجود في كشف الحساب</option>
              <option value="تم استخدام نفس الإيصال لطلب سابق">تم استخدام نفس الإيصال لطلب سابق</option>
            </select>

            <div className="flex gap-2">
              <button
                onClick={() => {
                  adminRejectPayment(rejectingPayment.payment_id, rejectingPayment.order_id, rejectReason);
                  setRejectingPayment(null);
                }}
                className="flex-1 py-2.5 bg-red-600 hover:bg-red-500 text-white rounded-xl text-xs font-bold"
              >
                تأكيد الرفض
              </button>
              <button
                onClick={() => setRejectingPayment(null)}
                className="px-4 py-2.5 bg-zinc-800 text-zinc-400 hover:text-white rounded-xl text-xs font-bold"
              >
                إلغاء
              </button>
            </div>
          </div>
        </div>
      )}

      {/* DELETE PAYMENT CONFIRMATION MODAL */}
      {deletingPayment && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/90 backdrop-blur-md animate-fadeIn">
          <div className="relative max-w-sm w-full bg-[#161616] border border-red-500/40 rounded-3xl p-6 space-y-4 shadow-2xl">
            <div className="w-12 h-12 rounded-2xl bg-red-500/15 text-red-400 flex items-center justify-center mx-auto">
              <Trash2 className="w-6 h-6" />
            </div>

            <div className="text-center space-y-2">
              <h3 className="text-base font-black text-white">تأكيد حذف عملية الدفع</h3>
              <p className="text-xs text-zinc-400 leading-relaxed">
                هل أنت متأكد من حذف هذه المعاملة الخاصة بالطلب <span className="text-white font-mono font-bold">({deletingPayment.order_id})</span> ومحفظة <span className="text-emerald-400 font-mono font-bold">({deletingPayment.sender_wallet})</span> نهائياً؟
              </p>
              <p className="text-[11px] text-zinc-500">
                سيتم حذف سجل التحويل وإعادة حالة الطلب لتنتظر سداد العميل.
              </p>
            </div>

            <div className="flex gap-2 pt-2">
              <button
                type="button"
                onClick={() => setDeletingPayment(null)}
                disabled={isDeletingPaymentLoading}
                className="flex-1 py-2.5 bg-zinc-800 hover:bg-zinc-700 text-zinc-300 rounded-xl text-xs font-bold transition-colors"
              >
                إلغاء
              </button>
              <button
                type="button"
                onClick={async () => {
                  setIsDeletingPaymentLoading(true);
                  try {
                    await deletePayment(deletingPayment.payment_id);
                    setDeletingPayment(null);
                  } finally {
                    setIsDeletingPaymentLoading(false);
                  }
                }}
                disabled={isDeletingPaymentLoading}
                className="flex-1 py-2.5 bg-red-600 hover:bg-red-500 text-white rounded-xl text-xs font-bold transition-colors flex items-center justify-center gap-1.5 shadow-lg shadow-red-600/30"
              >
                <Trash2 className="w-4 h-4" />
                <span>{isDeletingPaymentLoading ? 'جاري الحذف...' : 'تأكيد الحذف'}</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ADD / EDIT PRODUCT MODAL */}
      {isProductModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/90 backdrop-blur-md">
          <div className="relative max-w-lg w-full bg-[#161616] border border-zinc-800 rounded-3xl overflow-hidden p-6 max-h-[90vh] flex flex-col">
            <div className="flex justify-between items-center pb-3 border-b border-zinc-800 mb-4">
              <h3 className="text-base font-bold text-white">
                {editingProduct ? 'تعديل بيانات المنتج' : 'إضافة منتج جديد'}
              </h3>
              <button
                onClick={() => setIsProductModalOpen(false)}
                className="p-1 rounded-full bg-zinc-800 text-zinc-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveProduct} className="overflow-y-auto space-y-3.5 flex-1 pr-1">
              <div>
                <label className="text-xs font-bold text-zinc-300 block mb-1">اسم المنتج</label>
                <input
                  type="text"
                  required
                  value={pName}
                  onChange={(e) => setPName(e.target.value)}
                  placeholder="مثال: حذاء رياضي كاجوال"
                  className="w-full bg-[#0B0B0B] text-white text-xs rounded-xl p-2.5 border border-zinc-700 focus:outline-none focus:border-[#E50914]"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-zinc-300 block mb-1">دولة النشر والعملة 🌍</label>
                <select
                  value={pCountryCode}
                  onChange={(e) => setPCountryCode(e.target.value)}
                  className="w-full bg-[#0B0B0B] text-white text-xs rounded-xl p-2.5 border border-zinc-700 font-bold"
                >
                  <option value="EG">🇪🇬 مصر (EGP - ج.م)</option>
                  <option value="SA">🇸🇦 السعودية (SAR - ر.س)</option>
                  <option value="AE">🇦🇪 الإمارات (AED - د.إ)</option>
                </select>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-xs font-bold text-zinc-300 block mb-1">السعر الأصلي</label>
                  <input
                    type="number"
                    required
                    value={pPrice}
                    onChange={(e) => setPPrice(e.target.value)}
                    className="w-full bg-[#0B0B0B] text-white text-xs rounded-xl p-2.5 border border-zinc-700"
                  />
                </div>
                <div>
                  <label className="text-xs font-bold text-zinc-300 block mb-1">فئة الميزانية</label>
                  <select
                    value={pBudget}
                    onChange={(e) => setPBudget(e.target.value)}
                    className="w-full bg-[#0B0B0B] text-white text-xs rounded-xl p-2.5 border border-zinc-700"
                  >
                    <option value="100">100 جنيه</option>
                    <option value="200">200 جنيه</option>
                    <option value="300">300 جنيه</option>
                    <option value="500">500 جنيه</option>
                    <option value="1000">1000 جنيه</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 gap-2">
                <div>
                  <label className="text-xs font-bold text-zinc-300 block mb-1">التصنيف</label>
                  <select
                    value={pCategory}
                    onChange={(e) => setPCategory(e.target.value)}
                    className="w-full bg-[#0B0B0B] text-white text-xs rounded-xl p-2.5 border border-zinc-700"
                  >
                    {categories.filter(c => c.id !== 'all').map(c => (
                      <option key={c.id} value={c.id}>{c.name}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="text-xs font-bold text-zinc-300 block mb-1">الصورة الرئيسية للمنتج (URL)</label>
                <input
                  type="url"
                  value={pImgUrl}
                  onChange={(e) => setPImgUrl(e.target.value)}
                  placeholder="https://images.unsplash.com/..."
                  className="w-full bg-[#0B0B0B] text-white text-xs rounded-xl p-2.5 border border-zinc-700"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-zinc-300 block mb-1">صور إضافية للمنتج (اختياري)</label>
                <div className="space-y-2">
                  {pAdditionalImages.map((img, idx) => (
                    <input
                      key={idx}
                      type="url"
                      value={img}
                      onChange={(e) => {
                        const newArr = [...pAdditionalImages];
                        newArr[idx] = e.target.value;
                        setPAdditionalImages(newArr);
                      }}
                      placeholder={`رابط الصورة الإضافية ${idx + 1}`}
                      className="w-full bg-[#0B0B0B] text-white text-xs rounded-xl p-2.5 border border-zinc-700"
                    />
                  ))}
                </div>
                <button
                  type="button"
                  onClick={() => setPAdditionalImages([...pAdditionalImages, ''])}
                  className="mt-2 text-[11px] text-blue-400 hover:text-blue-300 font-bold"
                >
                  + إضافة رابط صورة آخر
                </button>
              </div>

              <div>
                <label className="text-xs font-bold text-zinc-300 block mb-1">رابط الأفلييت / الشراء المباشر</label>
                <input
                  type="url"
                  value={pAffiliateUrl}
                  onChange={(e) => setPAffiliateUrl(e.target.value)}
                  placeholder="https://trendstore.eg/product?aff=100"
                  className="w-full bg-[#0B0B0B] text-white text-xs rounded-xl p-2.5 border border-zinc-700"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-zinc-300 block mb-1">كود كوبون الخصم (اختياري)</label>
                <input
                  type="text"
                  value={pCouponCode}
                  onChange={(e) => setPCouponCode(e.target.value)}
                  placeholder="مثال: M3AK10 أو SPORT15"
                  className="w-full bg-[#0B0B0B] text-white text-xs rounded-xl p-2.5 border border-zinc-700"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-zinc-300 block mb-1">وصف المنتج</label>
                <textarea
                  value={pDesc}
                  onChange={(e) => setPDesc(e.target.value)}
                  rows={2}
                  className="w-full bg-[#0B0B0B] text-white text-xs rounded-xl p-2.5 border border-zinc-700"
                />
              </div>

              <div className="flex items-center gap-2 pt-1">
                <input
                  type="checkbox"
                  id="featured"
                  checked={pIsFeatured}
                  onChange={(e) => setPIsFeatured(e.target.checked)}
                  className="rounded text-[#E50914] focus:ring-0"
                />
                <label htmlFor="featured" className="text-xs font-bold text-zinc-300">
                  عرض كمنتج مميز (Featured) في الصفحة الرئيسية ⭐
                </label>
              </div>

              <div className="pt-3 border-t border-zinc-800 flex gap-2">
                <button
                  type="submit"
                  className="flex-1 py-3 rounded-xl bg-[#E50914] hover:bg-[#FF3344] text-white text-xs font-bold transition-colors"
                >
                  حفظ المنتج سحابياً
                </button>
                <button
                  type="button"
                  onClick={() => setIsProductModalOpen(false)}
                  className="px-4 py-3 rounded-xl bg-zinc-800 text-zinc-400 hover:text-white text-xs font-bold"
                >
                  إلغاء
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* PAYMENT METHOD MODAL */}
      {isMethodModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/90 backdrop-blur-md">
          <div className="relative max-w-sm w-full bg-[#161616] border border-zinc-800 rounded-3xl p-6 space-y-4">
            <h3 className="text-sm font-bold text-white">
              {editingMethod ? 'تعديل وسيلة الدفع' : 'إضافة وسيلة دفع جديدة'}
            </h3>

            <form onSubmit={handleSaveMethod} className="space-y-3">
              <div>
                <label className="text-xs text-zinc-400 block mb-1">اسم وسيلة الدفع</label>
                <input
                  type="text"
                  required
                  value={mName}
                  onChange={(e) => setMName(e.target.value)}
                  placeholder="فودافون كاش / إنستاباي"
                  className="w-full bg-[#0B0B0B] text-white text-xs rounded-xl p-2.5 border border-zinc-700"
                />
              </div>

              <div>
                <label className="text-xs text-zinc-400 block mb-1">رقم المحفظة / الحساب المعتمد</label>
                <input
                  type="text"
                  required
                  value={mNumber}
                  onChange={(e) => setMNumber(e.target.value)}
                  placeholder="01015042334"
                  className="w-full bg-[#0B0B0B] text-white text-xs rounded-xl p-2.5 border border-zinc-700"
                />
              </div>

              <div>
                <label className="text-xs text-zinc-400 block mb-1">اسم صاحب الحساب</label>
                <input
                  type="text"
                  value={mOwner}
                  onChange={(e) => setMOwner(e.target.value)}
                  className="w-full bg-[#0B0B0B] text-white text-xs rounded-xl p-2.5 border border-zinc-700"
                />
              </div>

              <div>
                <label className="text-xs text-zinc-400 block mb-1">دولة وسيلة الدفع (الربط بالدولة) 🌍</label>
                <select
                  value={mCountryCode}
                  onChange={(e) => setMCountryCode(e.target.value)}
                  className="w-full bg-[#0B0B0B] text-white text-xs rounded-xl p-2.5 border border-zinc-700 font-bold"
                >
                  {countries.map(c => (
                    <option key={c.code} value={c.code}>
                      {c.flag_emoji} {c.name_ar} ({c.currency_symbol})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="text-xs text-zinc-400 block mb-1">تعليمات التحويل للعميل</label>
                <textarea
                  value={mInstructions}
                  onChange={(e) => setMInstructions(e.target.value)}
                  rows={2}
                  className="w-full bg-[#0B0B0B] text-white text-xs rounded-xl p-2.5 border border-zinc-700"
                />
              </div>

              {/* Visibility & Active Status Toggle */}
              <div className="flex items-center justify-between p-3 rounded-2xl bg-[#0B0B0B] border border-zinc-800">
                <div>
                  <span className="text-xs font-bold text-white block">حالة الظهور للعملاء (تفعيل / إخفاء)</span>
                  <span className="text-[11px] text-zinc-400 block mt-0.5">
                    {mIsEnabled ? 'طريقة الدفع ظاهرة ومفعلة للعملاء عند الشراء' : 'طريقة الدفع مخفية ومعطلة مؤقتاً'}
                  </span>
                </div>
                <button
                  type="button"
                  onClick={() => setMIsEnabled(!mIsEnabled)}
                  className={`w-12 h-6 flex items-center rounded-full p-1 transition-colors ${
                    mIsEnabled ? 'bg-emerald-600 justify-end' : 'bg-zinc-700 justify-start'
                  }`}
                >
                  <span className="bg-white w-4 h-4 rounded-full shadow-md"></span>
                </button>
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="submit"
                  className="flex-1 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold transition-all shadow-md shadow-emerald-600/20"
                >
                  حفظ في سوبابيز والواجهة
                </button>
                <button
                  type="button"
                  onClick={() => setIsMethodModalOpen(false)}
                  className="px-4 py-2.5 bg-zinc-800 text-zinc-400 hover:text-white rounded-xl text-xs font-bold transition-colors"
                >
                  إلغاء
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* DELETE PAYMENT METHOD CONFIRMATION MODAL */}
      {deletingMethod && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/90 backdrop-blur-md animate-fadeIn">
          <div className="relative max-w-sm w-full bg-[#161616] border border-red-500/40 rounded-3xl p-6 space-y-4 shadow-2xl">
            <div className="w-12 h-12 rounded-2xl bg-red-500/15 text-red-400 flex items-center justify-center mx-auto border border-red-500/30">
              <Trash2 className="w-6 h-6" />
            </div>

            <div className="text-center space-y-2">
              <h3 className="text-base font-black text-white">تأكيد حذف وسيلة الدفع</h3>
              <p className="text-xs text-zinc-400 leading-relaxed">
                هل أنت متأكد من حذف وسيلة الدفع <strong className="text-white font-bold">{deletingMethod.name}</strong> برقم المحفظة <strong className="text-emerald-400 font-mono font-bold" dir="ltr">{deletingMethod.wallet_number}</strong> نهائياً من قاعدة بيانات Supabase والواجهة؟
              </p>
              <p className="text-[11px] text-red-400 bg-red-500/10 p-2.5 rounded-xl border border-red-500/20">
                ⚠️ سيتم حذفها فوراً عبر البث المباشر ولن تظهر للعملاء في واجهة الموقع ولا في تطبيق الهاتف المحمول.
              </p>
            </div>

            <div className="flex gap-2 pt-2">
              <button
                type="button"
                onClick={() => setDeletingMethod(null)}
                disabled={isDeletingMethodLoading}
                className="flex-1 py-2.5 bg-zinc-800 hover:bg-zinc-700 text-zinc-300 rounded-xl text-xs font-bold transition-colors"
              >
                إلغاء
              </button>
              <button
                type="button"
                onClick={async () => {
                  setIsDeletingMethodLoading(true);
                  try {
                    await adminDeletePaymentMethod(deletingMethod.id);
                    setDeletingMethod(null);
                  } finally {
                    setIsDeletingMethodLoading(false);
                  }
                }}
                disabled={isDeletingMethodLoading}
                className="flex-1 py-2.5 bg-red-600 hover:bg-red-500 text-white rounded-xl text-xs font-bold transition-colors flex items-center justify-center gap-1.5 shadow-lg shadow-red-600/30"
              >
                {isDeletingMethodLoading ? (
                  <>
                    <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                    <span>جاري الحذف...</span>
                  </>
                ) : (
                  <>
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>تأكيد الحذف نهائياً</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* DELETE APP UPDATE CONFIRMATION MODAL */}
      {deletingUpdate && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/90 backdrop-blur-md animate-fadeIn">
          <div className="relative max-w-sm w-full bg-[#161616] border border-red-500/40 rounded-3xl p-6 space-y-4 shadow-2xl">
            <div className="w-12 h-12 rounded-2xl bg-red-500/15 text-red-400 flex items-center justify-center mx-auto">
              <Trash2 className="w-6 h-6" />
            </div>

            <div className="text-center space-y-2">
              <h3 className="text-base font-black text-white">تأكيد حذف إصدار التطبيق</h3>
              <p className="text-xs text-zinc-400 leading-relaxed">
                هل أنت متأكد من حذف الإصدار <span className="text-white font-mono font-bold">({deletingUpdate.version_name} - كود {deletingUpdate.version_code})</span> نهائياً من قاعدة البيانات؟
              </p>
            </div>

            <div className="flex gap-2 pt-2">
              <button
                type="button"
                onClick={() => setDeletingUpdate(null)}
                disabled={isDeletingUpdateLoading}
                className="flex-1 py-2.5 bg-zinc-800 hover:bg-zinc-700 text-zinc-300 rounded-xl text-xs font-bold transition-colors"
              >
                إلغاء
              </button>
              <button
                type="button"
                onClick={async () => {
                  setIsDeletingUpdateLoading(true);
                  try {
                    await adminDeleteAppUpdate(deletingUpdate.id);
                    setDeletingUpdate(null);
                  } finally {
                    setIsDeletingUpdateLoading(false);
                  }
                }}
                disabled={isDeletingUpdateLoading}
                className="flex-1 py-2.5 bg-red-600 hover:bg-red-500 text-white rounded-xl text-xs font-bold transition-colors flex items-center justify-center gap-1.5 shadow-lg shadow-red-600/30"
              >
                <Trash2 className="w-4 h-4" />
                <span>{isDeletingUpdateLoading ? 'جاري الحذف...' : 'تأكيد الحذف'}</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
