import React from 'react';
import { Wallet, Store, ShieldCheck, Zap } from 'lucide-react';

export const AboutSection: React.FC = () => {
  const features = [
    {
      icon: Wallet,
      title: 'اختار على قد جيبك',
      description: 'بتحدد ميزانيتك واحنا بنعرضلك منتجات مناسبة ليها بالظبط بدون حيرة أو إجهاد.'
    },
    {
      icon: Store,
      title: 'متاجر أصلية',
      description: 'كل منتج بيجي من متجره الأصلي المعتمد بسعره الحقيقي بدون أي زيادة أو هوامش ربح خفية.'
    },
    {
      icon: ShieldCheck,
      title: 'شفافية كاملة',
      description: 'موضح لك بالتفصيل سعر المنتج ورسوم الطلب قبل ما تكمل أي خطوة بكل وضوح وأمان.'
    },
    {
      icon: Zap,
      title: 'تجربة سهلة وسريعة',
      description: 'من اختيار الميزانية لحد الانتقال للمتجر وإتمام الشراء في خطوات بسيطة وسلسة.'
    }
  ];

  return (
    <section id="about-section" className="py-12 sm:py-16 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      {/* Header matching Screenshot 4 */}
      <div className="text-center max-w-3xl mx-auto mb-12">
        <h2 className="text-2xl sm:text-4xl font-black text-white mb-4">
          من نحن
        </h2>
        <p className="text-sm sm:text-base text-zinc-400 leading-relaxed">
          منصة مصرية وعربية ذكية بتساعدك تكتشف منتجات مناسبة لميزانيتك من متاجر أصلية موثوقة (أمازون، نون، سوق مصر، وغيرها) من 100 لـ 1000 ج.م. بنوفر وقتك في البحث. إحنا مش متجر، إحنا دليلك اللي بيوصلك لأفضل اختيار على قد جيبك.
        </p>
      </div>

      {/* 4 Feature Cards Grid matching Screenshot 4 */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 sm:gap-6">
        {features.map((item, index) => {
          const Icon = item.icon;
          return (
            <div
              key={index}
              className="bg-[#161616] border border-[#2A2A2A] hover:border-[#E50914]/40 rounded-2xl p-6 transition-all transform hover:-translate-y-1 group"
            >
              <div className="w-12 h-12 rounded-2xl bg-[#E50914]/10 text-[#FF3344] flex items-center justify-center mb-4 group-hover:bg-[#E50914] group-hover:text-white transition-colors">
                <Icon className="w-6 h-6" />
              </div>
              <h3 className="text-base sm:text-lg font-bold text-white mb-2 group-hover:text-[#FF3344] transition-colors">
                {item.title}
              </h3>
              <p className="text-xs sm:text-sm text-zinc-400 leading-relaxed">
                {item.description}
              </p>
            </div>
          );
        })}
      </div>
    </section>
  );
};
