import React from 'react';
import { useApp } from '../context/AppContext';
import { Sparkles, ArrowDown, ShoppingCart, Tag, Smartphone, Download } from 'lucide-react';

export const Hero: React.FC = () => {
  const {
    setCurrentView,
    setSelectedBudget,
    activeCurrencySymbol,
    setIsDownloadModalOpen,
    latestActiveAppUpdate
  } = useApp();

  const scrollToBudgets = () => {
    const el = document.getElementById('budget-section');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    } else {
      setCurrentView('products');
    }
  };

  const scrollToProducts = () => {
    const el = document.getElementById('featured-products');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    } else {
      setCurrentView('products');
    }
  };

  return (
    <section className="relative overflow-hidden pt-6 pb-12 lg:pt-10 lg:pb-16 text-center">
      {/* Radial red glow background matching Screenshot 1 & 2 */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[700px] h-[450px] bg-gradient-to-b from-[#E50914]/25 via-[#E50914]/5 to-transparent rounded-full blur-3xl -z-10 pointer-events-none" />

      <div className="max-w-4xl mx-auto px-4 sm:px-6">
        
        {/* Promotional Banner */}
        <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#161616] border border-[#2A2A2A] shadow-lg mb-6">
          <span className="text-sm">🎁</span>
          <span className="text-xs font-semibold text-zinc-200">
            اطلب واحصل على كوبون خصم إضافي مع كل طلب
          </span>
          <span className="bg-[#E50914] text-white text-[10px] font-black px-2 py-0.5 rounded-md">
            إعلان 📣
          </span>
        </div>

        {/* Small Tagline Pill & Android App Download Pill */}
        <div className="flex flex-wrap items-center justify-center gap-2.5 mb-6">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-[#E50914]/10 border border-[#E50914]/30 text-[#FF3344] text-xs font-bold">
            <Sparkles className="w-3.5 h-3.5" />
            <span>منتجات مختارة على قد جيبك</span>
          </div>

          <button
            onClick={() => setIsDownloadModalOpen(true)}
            className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-gradient-to-r from-emerald-950/70 via-zinc-900 to-[#161616] border border-emerald-500/40 hover:border-emerald-400 text-xs text-white font-bold transition-all shadow-md shadow-emerald-500/10 hover:shadow-emerald-500/25 group"
            title="تحميل تطبيق الأندرويد"
          >
            <div className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            <Smartphone className="w-3.5 h-3.5 text-emerald-400 group-hover:scale-110 transition-transform" />
            <span>تحميل تطبيق الأندرويد</span>
            {latestActiveAppUpdate && (
              <span className="text-[10px] text-emerald-300 font-mono bg-emerald-500/20 px-1.5 py-0.5 rounded-md">
                v{latestActiveAppUpdate.version_name}
              </span>
            )}
          </button>
        </div>

        {/* Main Display Headline */}
        <h1 className="text-3xl sm:text-5xl lg:text-6xl font-black text-white tracking-tight leading-[1.2] mb-6">
          <span className="block text-base sm:text-xl font-bold text-[#E50914] mb-2 tracking-normal">
            معاك 100 | M3AK 100
          </span>
          معاك كام؟{' '}
          <span className="text-[#E50914] drop-shadow-[0_0_25px_rgba(229,9,20,0.4)]">
            وإحنا نوريك
          </span>{' '}
          تشتري إيه
        </h1>

        {/* Subtitle */}
        <p className="text-base sm:text-lg text-zinc-400 max-w-2xl mx-auto leading-relaxed mb-8">
          اختار ميزانيتك، وهنعرضلك أفضل المنتجات من متاجر أصلية بنفس السعر بالظبط، من غير أي زيادة.
        </p>

        {/* CTA Buttons matching Screenshots */}
        <div className="flex flex-col sm:flex-row items-center justify-center gap-3.5 max-w-xl mx-auto mb-8">
          <button
            onClick={scrollToProducts}
            className="w-full sm:w-auto px-8 py-3.5 rounded-full bg-[#E50914] hover:bg-[#FF3344] text-white text-base font-bold transition-all transform hover:-translate-y-0.5 shadow-lg shadow-[#E50914]/30 flex items-center justify-center gap-2"
          >
            <ShoppingCart className="w-4 h-4" />
            <span>اكتشف المنتجات</span>
          </button>

          <button
            onClick={() => setIsDownloadModalOpen(true)}
            className="w-full sm:w-auto px-8 py-3.5 rounded-full bg-gradient-to-r from-emerald-600 via-emerald-500 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white text-base font-bold transition-all transform hover:-translate-y-0.5 shadow-xl shadow-emerald-600/30 flex items-center justify-center gap-2.5 group"
          >
            <Smartphone className="w-5 h-5 group-hover:scale-110 transition-transform" />
            <span>تحميل تطبيق الأندرويد (APK)</span>
            {latestActiveAppUpdate && (
              <span className="text-xs bg-black/30 px-2 py-0.5 rounded-md font-mono text-emerald-200">
                v{latestActiveAppUpdate.version_name}
              </span>
            )}
          </button>
        </div>

      </div>
    </section>
  );
};
