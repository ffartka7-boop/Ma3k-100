import React, { useState, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import { X, Heart, Store, Shield, Check, Copy, ShoppingBag, ExternalLink, Tag, Globe, ChevronRight, ChevronLeft, Maximize2 } from 'lucide-react';
import { getCountryDetails } from '../utils/country';

export const ProductDetailsModal: React.FC = () => {
  const {
    activeProductModal,
    setActiveProductModal,
    setActiveOrderModal,
    favorites,
    toggleFavorite,
    activeCurrency,
    getOrderFeeForCountry
  } = useApp();

  const [copiedCoupon, setCopiedCoupon] = useState(false);
  const [currentImgIndex, setCurrentImgIndex] = useState(0);
  const [isFullscreenImage, setIsFullscreenImage] = useState(false);

  // Reset index when product changes
  useEffect(() => {
    setCurrentImgIndex(0);
    setIsFullscreenImage(false);
  }, [activeProductModal?.id]);

  if (!activeProductModal) return null;

  const product = activeProductModal;
  const isFav = favorites.includes(product.id);
  const country = getCountryDetails(product.country_code);
  const productOrderFee = getOrderFeeForCountry(product.country_code);

  const allImages = [product.image_url];
  if (product.additional_images_json) {
    try {
      const extra = JSON.parse(product.additional_images_json);
      if (Array.isArray(extra)) {
        allImages.push(...extra.filter(Boolean));
      }
    } catch {}
  }

  const handleNextImg = (e: React.MouseEvent) => {
    e.stopPropagation();
    setCurrentImgIndex((prev) => (prev + 1) % allImages.length);
  };

  const handlePrevImg = (e: React.MouseEvent) => {
    e.stopPropagation();
    setCurrentImgIndex((prev) => (prev - 1 + allImages.length) % allImages.length);
  };

  const handleCopyCoupon = () => {
    if (product.coupon_code) {
      navigator.clipboard.writeText(product.coupon_code);
      setCopiedCoupon(true);
      setTimeout(() => setCopiedCoupon(false), 2500);
    }
  };

  const handleStartOrder = () => {
    setActiveProductModal(null);
    setActiveOrderModal({ product, step: 'confirm' });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div
        className="relative w-full max-w-2xl bg-[#161616] border border-[#2A2A2A] rounded-3xl overflow-hidden shadow-2xl max-h-[90vh] flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Modal Header */}
        <div className="flex items-center justify-between p-4 sm:p-5 border-b border-[#2A2A2A]">
          <div className="flex items-center gap-2 flex-wrap">
            {/* Country Flag Badge */}
            <span
              className="px-3 py-1 rounded-xl bg-black/80 border border-white/20 text-white text-xs font-black flex items-center gap-1.5 shadow-sm"
              title={`دولة النشر: ${country.fullName}`}
            >
              <span className="text-base leading-none">{country.flag}</span>
              <span>{country.name}</span>
            </span>

            <span className="px-2.5 py-1 rounded-xl bg-[#E50914]/20 text-[#FF3344] text-xs font-bold">
              ميزانية {product.budget} {country.currencySymbol}
            </span>

            {product.is_featured && (
              <span className="px-2.5 py-1 rounded-xl bg-[#FFD700] text-black text-xs font-black">
                ⭐ منتج مميز
              </span>
            )}
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => toggleFavorite(product.id)}
              className={`p-2 rounded-full border transition-colors ${
                isFav
                  ? 'bg-[#E50914] text-white border-[#E50914]'
                  : 'bg-[#222222] text-zinc-400 border-[#333333] hover:text-white'
              }`}
              title="المفضلة"
            >
              <Heart className={`w-4 h-4 ${isFav ? 'fill-current' : ''}`} />
            </button>
            <button
              onClick={() => setActiveProductModal(null)}
              className="p-2 rounded-full bg-[#222222] text-zinc-400 hover:text-white border border-[#333333] transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Modal Body */}
        <div className="p-4 sm:p-6 overflow-y-auto space-y-6">
          {/* Main Image Container with Full Product Visibility */}
          <div className="relative w-full h-64 sm:h-80 md:h-96 rounded-2xl overflow-hidden bg-[#0A0A0A] border border-zinc-800 flex items-center justify-center p-3 group shadow-inner">
            {/* Ambient Blurred Backdrop */}
            <div
              className="absolute inset-0 bg-cover bg-center blur-2xl opacity-25 scale-110 pointer-events-none transition-all duration-500"
              style={{ backgroundImage: `url(${allImages[currentImgIndex]})` }}
            />

            <img
              src={allImages[currentImgIndex]}
              alt={product.name}
              onClick={() => setIsFullscreenImage(true)}
              className="relative z-10 max-w-full max-h-full object-contain cursor-zoom-in transition-transform duration-300 group-hover:scale-[1.02] drop-shadow-2xl select-none"
              referrerPolicy="no-referrer"
            />
            
            {allImages.length > 1 && (
              <>
                <button
                  onClick={handlePrevImg}
                  className="absolute right-2.5 top-1/2 -translate-y-1/2 p-2 bg-black/70 text-white rounded-full hover:bg-black/90 transition-colors backdrop-blur-md opacity-0 group-hover:opacity-100 z-20 shadow-lg"
                  title="الصورة السابقة"
                >
                  <ChevronRight className="w-5 h-5" />
                </button>
                <button
                  onClick={handleNextImg}
                  className="absolute left-2.5 top-1/2 -translate-y-1/2 p-2 bg-black/70 text-white rounded-full hover:bg-black/90 transition-colors backdrop-blur-md opacity-0 group-hover:opacity-100 z-20 shadow-lg"
                  title="الصورة التالية"
                >
                  <ChevronLeft className="w-5 h-5" />
                </button>
                <div className="absolute bottom-3 left-1/2 -translate-x-1/2 bg-black/70 backdrop-blur-md px-3 py-1.5 rounded-full flex items-center gap-1.5 opacity-0 group-hover:opacity-100 transition-opacity z-20 shadow-md">
                  {allImages.map((_, i) => (
                    <span key={i} className={`h-1.5 rounded-full transition-all ${i === currentImgIndex ? 'bg-[#E50914] w-3.5' : 'bg-white/50 w-1.5'}`} />
                  ))}
                </div>
              </>
            )}
            
            <button
              onClick={() => setIsFullscreenImage(true)}
              className="absolute bottom-3 right-3 z-20 bg-black/70 hover:bg-black/90 backdrop-blur-md px-2.5 py-1.5 rounded-xl text-white text-xs font-bold transition-all shadow-lg flex items-center gap-1.5 opacity-0 group-hover:opacity-100"
              title="تكبير الصورة بالحجم الكامل"
            >
              <Maximize2 className="w-3.5 h-3.5" />
              <span>تكبير الصورة</span>
            </button>

            {/* Country Floating Badge on Image */}
            <div className="absolute top-3 right-3 z-20 bg-black/85 backdrop-blur-md px-3 py-1 rounded-xl border border-white/20 text-white text-xs font-black flex items-center gap-1.5 shadow-lg">
              <span className="text-base">{country.flag}</span>
              <span>متاح في {country.fullName}</span>
            </div>
          </div>
          
          {/* Thumbnails Row */}
          {allImages.length > 1 && (
            <div className="flex items-center gap-2 overflow-x-auto pb-2 -mt-2 scrollbar-hide">
              {allImages.map((img, i) => (
                <button
                  key={i}
                  onClick={() => setCurrentImgIndex(i)}
                  className={`relative shrink-0 w-16 h-16 rounded-xl overflow-hidden border-2 bg-[#0B0B0B] p-1 flex items-center justify-center transition-all ${
                    i === currentImgIndex ? 'border-[#E50914] ring-2 ring-[#E50914]/30' : 'border-zinc-800 hover:border-zinc-600'
                  }`}
                >
                  <img src={img} alt="" className="w-full h-full object-contain" referrerPolicy="no-referrer" />
                </button>
              ))}
            </div>
          )}

          {/* Product Name & Country Info */}
          <div>
            <div className="flex items-center gap-2 text-xs text-zinc-400 mb-2 flex-wrap">
              <span className="px-2 py-0.5 rounded-md bg-zinc-800 text-white font-bold flex items-center gap-1 border border-zinc-700">
                <span>{country.flag}</span>
                <span>{country.name}</span>
              </span>
              <span>•</span>
              <span>رابط أصلي معتمد</span>
            </div>
            <h2 className="text-xl sm:text-2xl font-black text-white leading-tight">
              {product.name}
            </h2>
          </div>

          {/* Pricing & Fee Breakdown Card */}
          <div className="p-4 rounded-2xl bg-[#0B0B0B] border border-[#2A2A2A] space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-sm text-zinc-400">سعر المنتج ({country.name}):</span>
              <span className="text-xl font-black text-white flex items-center gap-1">
                <span>{product.price.toLocaleString('ar-EG')}</span>
                <span className="text-sm text-[#FF3344] font-bold">{country.currencySymbol}</span>
              </span>
            </div>

            <div className="flex items-center justify-between pt-2 border-t border-zinc-800">
              <span className="text-xs text-zinc-400 flex items-center gap-1">
                <span>رسوم خدمة تأمين وتفعيل الرابط:</span>
              </span>
              <span className="text-sm font-bold text-[#FF3344]">
                {productOrderFee} {country.currencySymbol} (مرة واحدة)
              </span>
            </div>

            <p className="text-[11px] text-zinc-500 pt-1">
              * سعر المنتج نفسه يتم سداده في {country.name} عند الشراء هناك. رسوم المنصة الرمزية ({productOrderFee} {country.currencySymbol}) تُسدد لتأمين كود الخصم ورابط الأفلييت المباشر.
            </p>
          </div>

          {/* Coupon Section if available */}
          {product.coupon_code && (
            <div className="p-4 rounded-2xl bg-emerald-950/30 border border-emerald-500/40 flex items-center justify-between gap-4">
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-xl bg-emerald-500/20 text-emerald-400">
                  <Tag className="w-5 h-5" />
                </div>
                <div>
                  <p className="text-xs text-emerald-300 font-bold">كوبون خصم إضافي متاح!</p>
                  <p className="text-lg font-black text-white tracking-widest">{product.coupon_code}</p>
                </div>
              </div>

              <button
                onClick={handleCopyCoupon}
                className="px-4 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-black text-xs font-black flex items-center gap-1.5 transition-colors"
              >
                {copiedCoupon ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                <span>{copiedCoupon ? 'تم النسخ!' : 'نسخ الكوبون'}</span>
              </button>
            </div>
          )}

          {/* Description */}
          <div className="space-y-2">
            <h4 className="text-sm font-bold text-white">وصف ومواصفات المنتج:</h4>
            <p className="text-sm text-zinc-300 leading-relaxed bg-[#0B0B0B]/50 p-4 rounded-2xl border border-zinc-800/80">
              {product.description}
            </p>
          </div>

          {/* Guarantee / Transparency Notice */}
          <div className="flex items-start gap-3 p-3.5 rounded-xl bg-zinc-900/60 border border-zinc-800 text-xs text-zinc-400">
            <Shield className="w-5 h-5 text-[#FF3344] shrink-0 mt-0.5" />
            <p className="leading-snug">
              تضمن منصة <strong>معاك 100</strong> توجيهك بأمان وموثوقية في <strong>{country.fullName}</strong> بدون أي تلاعب بالأسعار أو تكاليف خفية.
            </p>
          </div>
        </div>

        {/* Modal Footer CTA */}
        <div className="p-4 sm:p-5 border-t border-[#2A2A2A] bg-[#0E0E0E] flex items-center gap-3">
          <button
            onClick={handleStartOrder}
            className="flex-1 py-3.5 rounded-2xl bg-[#E50914] hover:bg-[#FF3344] text-white font-bold text-sm transition-all transform active:scale-98 shadow-lg shadow-[#E50914]/25 flex items-center justify-center gap-2"
          >
            <ShoppingBag className="w-4 h-4" />
            <span>طلب المنتج وتفعيل الرابط ({productOrderFee} {country.currencySymbol})</span>
          </button>
        </div>
      </div>

      {/* Fullscreen Image Gallery Overlay */}
      {isFullscreenImage && (
        <div 
          className="fixed inset-0 z-[60] bg-black/95 flex items-center justify-center animate-in fade-in duration-200"
          onClick={() => setIsFullscreenImage(false)}
        >
          <button
            onClick={() => setIsFullscreenImage(false)}
            className="absolute top-5 right-5 p-3 rounded-full bg-white/10 hover:bg-white/20 text-white transition-colors z-50"
          >
            <X className="w-6 h-6" />
          </button>
          
          <img
            src={allImages[currentImgIndex]}
            alt={product.name}
            className="w-full h-full object-contain select-none"
            onClick={(e) => e.stopPropagation()}
            referrerPolicy="no-referrer"
          />
          
          {allImages.length > 1 && (
            <>
              <button
                onClick={handlePrevImg}
                className="absolute right-5 top-1/2 -translate-y-1/2 p-3 bg-white/10 hover:bg-white/20 text-white rounded-full transition-colors z-50"
              >
                <ChevronRight className="w-8 h-8" />
              </button>
              <button
                onClick={handleNextImg}
                className="absolute left-5 top-1/2 -translate-y-1/2 p-3 bg-white/10 hover:bg-white/20 text-white rounded-full transition-colors z-50"
              >
                <ChevronLeft className="w-8 h-8" />
              </button>
              
              <div className="absolute bottom-5 left-1/2 -translate-x-1/2 bg-black/60 backdrop-blur-md px-4 py-2 rounded-full flex items-center gap-2 z-50">
                {allImages.map((_, i) => (
                  <button
                    key={i}
                    onClick={(e) => { e.stopPropagation(); setCurrentImgIndex(i); }}
                    className={`transition-colors rounded-full ${i === currentImgIndex ? 'bg-[#E50914] w-3 h-3' : 'bg-white/40 hover:bg-white/60 w-2 h-2'}`}
                  />
                ))}
              </div>
            </>
          )}
        </div>
      )}
    </div>
  );
};
