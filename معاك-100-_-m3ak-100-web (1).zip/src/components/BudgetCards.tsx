import React from 'react';
import { useApp } from '../context/AppContext';
import { Wallet, ArrowLeft, CheckCircle2 } from 'lucide-react';

export const BudgetCards: React.FC = () => {
  const { budgets, products, selectedBudget, setSelectedBudget, selectedCountry, activeCurrency, setCurrentView } = useApp();

  const handleSelectBudget = (amount: number) => {
    if (selectedBudget === amount) {
      setSelectedBudget(null);
    } else {
      setSelectedBudget(amount);
      const el = document.getElementById('featured-products');
      if (el) {
        el.scrollIntoView({ behavior: 'smooth' });
      }
    }
  };

  return (
    <section id="budget-section" className="py-6 sm:py-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-2.5">
          <div className="p-2 rounded-xl bg-[#E50914]/10 text-[#E50914]">
            <Wallet className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-xl sm:text-2xl font-black text-white">
              اختار ميزانيتك
            </h2>
            <p className="text-xs text-zinc-400">
              تصفح المنتجات المتوافقة تماماً مع ما ترغب في إنفاقه
            </p>
          </div>
        </div>

        {selectedBudget && (
          <button
            onClick={() => setSelectedBudget(null)}
            className="text-xs text-[#FF3344] hover:underline font-bold"
          >
            إلغاء التحديد (عرض الكل)
          </button>
        )}
      </div>

      {/* Grid of Budget Cards matching Screenshot 1 & 2 */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3.5 sm:gap-4">
        {budgets.map((budget) => {
          const isSelected = selectedBudget === budget.amount;
          const count = products.filter(
            (p) =>
              p.budget === budget.amount &&
              p.is_available &&
              (selectedCountry === 'ALL' || (p.country_code || 'EG') === selectedCountry)
          ).length;

          return (
            <div
              key={budget.amount}
              onClick={() => handleSelectBudget(budget.amount)}
              className={`relative overflow-hidden cursor-pointer rounded-2xl p-4 sm:p-5 transition-all transform hover:-translate-y-1 group ${
                isSelected
                  ? 'bg-gradient-to-br from-[#1E1112] via-[#2D1214] to-[#161616] border-2 border-[#E50914] shadow-xl shadow-[#E50914]/20'
                  : 'bg-[#161616] hover:bg-[#1E1E1E] border border-[#2A2A2A] hover:border-[#E50914]/40'
              }`}
            >
              {/* Subtle background watermark */}
              <span className="absolute -bottom-2 -left-2 text-5xl font-black text-white/[0.03] select-none pointer-events-none group-hover:text-white/[0.06] transition-colors">
                {budget.amount}
              </span>

              <div className="flex items-start justify-between mb-4">
                <div
                  className={`w-9 h-9 rounded-xl flex items-center justify-center transition-colors ${
                    isSelected
                      ? 'bg-[#E50914] text-white'
                      : 'bg-[#E50914]/15 text-[#FF3344] group-hover:bg-[#E50914] group-hover:text-white'
                  }`}
                >
                  <Wallet className="w-4 h-4" />
                </div>

                <div
                  className={`w-6 h-6 rounded-full flex items-center justify-center transition-transform group-hover:-translate-x-1 ${
                    isSelected ? 'text-[#E50914]' : 'text-zinc-600 group-hover:text-white'
                  }`}
                >
                  {isSelected ? <CheckCircle2 className="w-4 h-4" /> : <ArrowLeft className="w-4 h-4" />}
                </div>
              </div>

              <div>
                <div className="flex items-baseline gap-1">
                  <span className="text-2xl sm:text-3xl font-black text-white tracking-tight">
                    {budget.amount.toLocaleString('ar-EG')}
                  </span>
                  <span className="text-xs font-semibold text-zinc-400">
                    {activeCurrency}
                  </span>
                </div>

                <p className="text-[11px] text-zinc-500 mt-1 font-medium">
                  {count > 0 ? `${count} منتج متوفر` : 'منتجات حصرية'}
                </p>
              </div>
            </div>
          );
        })}
      </div>
    </section>
  );
};
