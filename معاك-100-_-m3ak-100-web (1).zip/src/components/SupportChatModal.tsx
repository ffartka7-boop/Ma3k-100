import React, { useState, useRef, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import { X, Send, MessageCircle, Bot, User, Phone } from 'lucide-react';

export const SupportChatModal: React.FC = () => {
  const { isChatModalOpen, setIsChatModalOpen, chatMessages, sendChatMessage, currentUser } = useApp();
  const [inputText, setInputText] = useState('');
  const [isSending, setIsSending] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (isChatModalOpen) {
      messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
  }, [chatMessages, isChatModalOpen]);

  if (!isChatModalOpen) return null;

  const handleSend = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim()) return;
    try {
      setIsSending(true);
      await sendChatMessage(inputText);
      setInputText('');
    } finally {
      setIsSending(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div
        className="relative w-full max-w-md bg-[#161616] border border-[#2A2A2A] rounded-3xl overflow-hidden shadow-2xl h-[580px] max-h-[90vh] flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Chat Header */}
        <div className="flex items-center justify-between p-4 border-b border-[#2A2A2A] bg-[#0E0E0E]">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-[#E50914]/20 text-[#FF3344] flex items-center justify-center border border-[#E50914]/30">
              <MessageCircle className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-white flex items-center gap-1.5">
                <span>الدعم الفني المباشر</span>
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
              </h3>
              <p className="text-[11px] text-zinc-400">متاح 24/7 لمساعدتك في أي استفسار</p>
            </div>
          </div>

          <div className="flex items-center gap-1">
            <a
              href="https://wa.me/201015042334"
              target="_blank"
              rel="noopener noreferrer"
              className="p-2 rounded-full bg-emerald-500/10 text-emerald-400 hover:bg-emerald-500/20 transition-colors"
              title="محادثة واتساب مباشرة"
            >
              <Phone className="w-4 h-4" />
            </a>
            <button
              onClick={() => setIsChatModalOpen(false)}
              className="p-2 rounded-full bg-zinc-800 text-zinc-400 hover:text-white transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* WhatsApp Banner */}
        <div className="px-4 py-2 bg-emerald-950/30 border-b border-emerald-500/20 flex items-center justify-between text-xs text-emerald-300">
          <span>للمساعدة الفورية يمكنك مراسلتنا واتساب:</span>
          <a
            href="https://wa.me/201015042334"
            target="_blank"
            rel="noopener noreferrer"
            className="font-bold underline text-white font-mono"
          >
            01015042334
          </a>
        </div>

        {/* Chat Messages List */}
        <div className="flex-1 p-4 overflow-y-auto space-y-3 bg-[#0B0B0B]">
          {chatMessages.map((msg) => {
            const isMe = msg.sender_role === 'USER';
            return (
              <div
                key={msg.message_id}
                className={`flex items-start gap-2 max-w-[85%] ${
                  isMe ? 'mr-auto flex-row-reverse' : 'ml-auto flex-row'
                }`}
              >
                <div
                  className={`w-7 h-7 rounded-xl flex items-center justify-center shrink-0 text-xs font-bold ${
                    isMe
                      ? 'bg-[#E50914] text-white'
                      : 'bg-zinc-800 text-zinc-300 border border-zinc-700'
                  }`}
                >
                  {isMe ? <User className="w-3.5 h-3.5" /> : <Bot className="w-3.5 h-3.5" />}
                </div>

                <div
                  className={`p-3 rounded-2xl text-xs sm:text-sm leading-relaxed ${
                    isMe
                      ? 'bg-[#E50914] text-white rounded-tr-none shadow-md'
                      : 'bg-[#1C1C1C] text-zinc-200 rounded-tl-none border border-zinc-800'
                  }`}
                >
                  <p>{msg.message_text}</p>
                  <span className="text-[9px] opacity-60 block text-left mt-1">
                    {new Date(msg.timestamp).toLocaleTimeString('ar-EG', {
                      hour: '2-digit',
                      minute: '2-digit'
                    })}
                  </span>
                </div>
              </div>
            );
          })}
          <div ref={messagesEndRef} />
        </div>

        {/* Chat Input */}
        <form onSubmit={handleSend} className="p-3 border-t border-[#2A2A2A] bg-[#121212] flex items-center gap-2">
          <input
            type="text"
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            placeholder="اكتب رسالتك أو استفسارك هنا..."
            className="flex-1 bg-[#1A1A1A] text-white text-xs sm:text-sm rounded-2xl px-4 py-3 border border-[#2A2A2A] focus:outline-none focus:border-[#E50914] placeholder:text-zinc-500"
          />
          <button
            type="submit"
            disabled={isSending || !inputText.trim()}
            className="p-3 rounded-2xl bg-[#E50914] hover:bg-[#FF3344] text-white transition-all transform active:scale-95 disabled:opacity-40 disabled:hover:bg-[#E50914]"
          >
            <Send className="w-4 h-4 rotate-180" />
          </button>
        </form>
      </div>
    </div>
  );
};
