import React, { useState, useEffect, useRef } from 'react';
import { useApp } from '../context/AppContext';
import {
  Smartphone,
  Download,
  CheckCircle2,
  AlertCircle,
  Copy,
  Check,
  X,
  RefreshCw,
  Sparkles,
  ShieldCheck,
  PackageCheck,
  FolderOpen,
  RotateCcw,
  ChevronDown,
  BellRing
} from 'lucide-react';
import type { AppUpdate } from '../types';
import { playDownloadChime, playInstallClickSound } from '../lib/soundEffects';

type DownloadState = 'idle' | 'downloading' | 'download_started';

export const DownloadAppModal: React.FC = () => {
  const {
    isDownloadModalOpen,
    setIsDownloadModalOpen,
    getLatestActiveAppUpdate,
    latestActiveAppUpdate,
    downloadLatestApk
  } = useApp();

  const [activeUpdate, setActiveUpdate] = useState<AppUpdate | null>(latestActiveAppUpdate);
  const [downloadState, setDownloadState] = useState<DownloadState>('idle');
  const [downloadProgress, setDownloadProgress] = useState(0);
  const [copiedLink, setCopiedLink] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');
  const [activeStepTab, setActiveStepTab] = useState<'notification' | 'files'>('notification');

  const progressIntervalRef = useRef<NodeJS.Timeout | null>(null);

  // Close on Escape key
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isDownloadModalOpen) {
        setIsDownloadModalOpen(false);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isDownloadModalOpen, setIsDownloadModalOpen]);

  // Load active update smoothly when modal opens without layout shaking
  useEffect(() => {
    if (isDownloadModalOpen) {
      setErrorMsg('');
      setActiveStepTab('notification');

      if (latestActiveAppUpdate) {
        setActiveUpdate(latestActiveAppUpdate);
      }

      getLatestActiveAppUpdate()
        .then((res) => {
          if (res) {
            setActiveUpdate(res);
          } else if (latestActiveAppUpdate) {
            setActiveUpdate(latestActiveAppUpdate);
          }
        })
        .catch((err) => {
          console.warn('Background check for app update notice:', err);
        });
    } else {
      // Reset state when closed
      if (progressIntervalRef.current) {
        clearInterval(progressIntervalRef.current);
      }
      setDownloadState('idle');
      setDownloadProgress(0);
    }
  }, [isDownloadModalOpen]);

  // Cleanup interval on unmount
  useEffect(() => {
    return () => {
      if (progressIntervalRef.current) {
        clearInterval(progressIntervalRef.current);
      }
    };
  }, []);

  if (!isDownloadModalOpen) return null;

  // Single-run download handler (only downloads ONCE here, or when explicit Re-download is clicked)
  const handleStartDownload = async () => {
    try {
      setErrorMsg('');
      setDownloadState('downloading');
      setDownloadProgress(10);

      // Trigger the real browser download only once
      const res = await downloadLatestApk();
      if (!res.success) {
        setErrorMsg(res.error || 'تعذر بدء التحميل. يمكنك نسخ الرابط والتحميل يدوياً.');
        setDownloadState('idle');
        return;
      }

      if (res.update) {
        setActiveUpdate(res.update);
      }

      // Smooth visual progress indicator to 100%
      let currentProg = 10;
      if (progressIntervalRef.current) {
        clearInterval(progressIntervalRef.current);
      }

      progressIntervalRef.current = setInterval(() => {
        currentProg += Math.floor(Math.random() * 9) + 7;
        if (currentProg >= 100) {
          currentProg = 100;
          if (progressIntervalRef.current) {
            clearInterval(progressIntervalRef.current);
          }
          setDownloadProgress(100);
          setDownloadState('download_started');

          // Play pleasant download chime
          playDownloadChime();
        } else {
          setDownloadProgress(currentProg);
        }
      }, 80);

    } catch (e: any) {
      console.error('Download error:', e);
      setErrorMsg('تعذر إكمال التحميل تلقائياً. يمكنك نسخ الرابط واستخدامه مباشرة.');
      setDownloadState('idle');
      if (progressIntervalRef.current) {
        clearInterval(progressIntervalRef.current);
      }
    }
  };

  const handleCancelDownload = () => {
    if (progressIntervalRef.current) {
      clearInterval(progressIntervalRef.current);
    }
    setDownloadState('idle');
    setDownloadProgress(0);
  };

  // Action 1: "Install Now" switch to step 1 (Does NOT re-download)
  const handleInstallNowAction = () => {
    playInstallClickSound();
    setActiveStepTab('notification');
  };

  // Action 2: "Open File in Downloads" switch to step 2 (Does NOT re-download)
  const handleOpenFileAction = () => {
    playInstallClickSound();
    setActiveStepTab('files');
  };

  const handleCopyLink = () => {
    if (activeUpdate?.apk_url) {
      navigator.clipboard.writeText(activeUpdate.apk_url);
      setCopiedLink(true);
      setTimeout(() => setCopiedLink(false), 2500);
    }
  };

  const cleanVer = (activeUpdate?.version_name || 'latest').replace(/[^a-zA-Z0-9._-]/g, '_');
  const apkFileName = `m3ak100_v${cleanVer}.apk`;

  return (
    <div
      onClick={(e) => {
        if (e.target === e.currentTarget) {
          setIsDownloadModalOpen(false);
        }
      }}
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md transition-opacity duration-200"
    >
      <div className="relative max-w-md w-full bg-[#141414] border border-[#2A2A2A] rounded-3xl overflow-hidden shadow-2xl shadow-emerald-500/10 p-5 sm:p-6 space-y-4 transition-all duration-300">
        
        {/* Top Glow & Decorative Elements */}
        <div className="absolute top-0 right-1/2 translate-x-1/2 w-48 h-24 bg-emerald-500/15 blur-3xl rounded-full pointer-events-none -z-0" />

        {/* Close Button */}
        <button
          onClick={() => setIsDownloadModalOpen(false)}
          className="absolute top-4 left-4 p-2 rounded-full bg-zinc-900/90 border border-zinc-700/80 text-white hover:bg-zinc-800 hover:border-zinc-500 transition-colors z-20 shadow-md flex items-center justify-center cursor-pointer active:scale-95"
          title="إغلاق النافذة"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header with App Icon & Security Shield */}
        <div className="flex items-center gap-3.5 relative z-10 pr-10">
          <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-emerald-500/20 via-emerald-500/10 to-transparent border border-emerald-500/30 flex items-center justify-center text-emerald-400 shadow-lg shadow-emerald-500/20 shrink-0">
            <Smartphone className="w-7 h-7" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-lg font-black text-white">تطبيق معاك 100</h2>
              <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 border border-emerald-500/30 text-emerald-400 text-[10px] font-bold">
                APK رسمي
              </span>
            </div>
            <div className="flex items-center gap-1.5 text-xs text-emerald-400/90 mt-0.5">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
              <span>فحص أمان وحماية متوافق مع Android</span>
            </div>
          </div>
        </div>

        {/* Error message */}
        {errorMsg && (
          <div className="p-3 bg-red-950/40 border border-red-500/40 rounded-2xl text-xs text-red-300 flex items-start gap-2 relative z-10">
            <AlertCircle className="w-4 h-4 text-red-400 shrink-0 mt-0.5" />
            <span>{errorMsg}</span>
          </div>
        )}

        {/* Update Card */}
        {activeUpdate ? (
          <div className="bg-[#0B0B0B] border border-zinc-800 rounded-2xl p-4 space-y-3 relative z-10">
            {/* Version Meta Bar */}
            <div className="flex flex-wrap items-center justify-between gap-2 pb-2.5 border-b border-zinc-800/80">
              <div className="flex items-center gap-2">
                <span className="px-2.5 py-0.5 rounded-lg bg-emerald-500/20 text-emerald-300 font-mono font-black text-xs border border-emerald-500/40">
                  v{activeUpdate.version_name}
                </span>
                <span className="px-2 py-0.5 rounded-lg bg-zinc-900 text-zinc-400 font-mono text-[10px] border border-zinc-800">
                  كود: {activeUpdate.version_code}
                </span>
                {activeUpdate.file_size_mb && (
                  <span className="px-2 py-0.5 rounded-lg bg-blue-950/40 text-blue-300 font-mono text-[10px] border border-blue-500/30">
                    {activeUpdate.file_size_mb} MB
                  </span>
                )}
              </div>

              <div className="flex items-center gap-1.5 text-[11px] text-emerald-400 font-bold">
                <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
                <span>متوافق مع أندرويد</span>
              </div>
            </div>

            {/* Title & Description / Changelog */}
            <div className="space-y-1">
              <h3 className="text-xs font-bold text-white flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-emerald-400" />
                <span>{activeUpdate.update_title || 'أحدث إصدار نشط'}</span>
              </h3>
              <p className="text-xs text-zinc-400 leading-relaxed whitespace-pre-line bg-[#141414] p-2.5 rounded-xl border border-zinc-800/80 max-h-20 overflow-y-auto">
                {activeUpdate.update_description || 'تحسينات عامة على سرعة واستقرار التطبيق وتلقي إشعارات الطلبات الفورية.'}
              </p>
            </div>
          </div>
        ) : (
          <div className="text-center py-6 space-y-2 bg-[#0B0B0B] border border-zinc-800 rounded-2xl p-4 relative z-10">
            <Smartphone className="w-8 h-8 text-zinc-600 mx-auto" />
            <p className="text-xs font-bold text-white">لا يوجد إصدار منشور حالياً</p>
            <p className="text-[11px] text-zinc-400">
              يرجى رفع ونشر إصدار APK من لوحة التحكم.
            </p>
          </div>
        )}

        {/* Dynamic State UI (idle -> downloading -> download_started) */}
        <div className="space-y-3 relative z-10">
          {downloadState === 'idle' && (
            <>
              <button
                onClick={handleStartDownload}
                disabled={!activeUpdate}
                className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-emerald-600 via-emerald-500 to-teal-600 hover:from-emerald-500 hover:to-teal-500 disabled:opacity-50 text-white text-xs font-black transition-all flex items-center justify-center gap-2 shadow-lg shadow-emerald-600/30 group cursor-pointer active:scale-95"
              >
                <Download className="w-4 h-4 group-hover:scale-110 transition-transform" />
                <span>تنزيل الآن</span>
              </button>

              {activeUpdate?.apk_url && (
                <button
                  onClick={handleCopyLink}
                  className="w-full py-2.5 rounded-xl bg-zinc-900 hover:bg-zinc-800 text-zinc-300 hover:text-white border border-zinc-800 text-xs font-bold transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  {copiedLink ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-emerald-400" />
                      <span className="text-emerald-400">تم نسخ رابط التحميل!</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5 text-zinc-400" />
                      <span>نسخ رابط التحميل المباشر</span>
                    </>
                  )}
                </button>
              )}
            </>
          )}

          {downloadState === 'downloading' && (
            <div className="p-4 bg-gradient-to-br from-emerald-950/40 via-[#0E1713] to-[#0B0B0B] border border-emerald-500/40 rounded-2xl space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <RefreshCw className="w-4 h-4 text-emerald-400 animate-spin" />
                  <span className="text-xs font-black text-white">جاري بدء تنزيل ملف APK...</span>
                </div>
                <span className="text-xs font-black font-mono text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded-lg border border-emerald-500/30">
                  {downloadProgress}%
                </span>
              </div>

              {/* Progress Bar */}
              <div className="w-full h-2.5 bg-zinc-900 rounded-full overflow-hidden border border-zinc-800 p-0.5">
                <div
                  className="h-full bg-gradient-to-r from-emerald-500 to-teal-400 rounded-full transition-all duration-150 shadow-sm shadow-emerald-500"
                  style={{ width: `${downloadProgress}%` }}
                />
              </div>

              <div className="flex items-center justify-between text-[11px] text-zinc-400 pt-1">
                <span>يتم حفظ الملف في مجلد التنزيلات على هاتفك</span>
                <button
                  onClick={handleCancelDownload}
                  className="text-zinc-500 hover:text-red-400 transition-colors text-[10px]"
                >
                  إلغاء
                </button>
              </div>
            </div>
          )}

          {downloadState === 'download_started' && (
            <div className="space-y-3">
              {/* Accurate Status Banner (Honest & clear: Download started / available on device) */}
              <div className="p-3.5 bg-gradient-to-r from-emerald-950/60 via-emerald-900/30 to-[#0B0B0B] border border-emerald-500/50 rounded-2xl flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-emerald-500 text-black flex items-center justify-center shrink-0 shadow-lg shadow-emerald-500/40">
                  <CheckCircle2 className="w-6 h-6" />
                </div>
                <div>
                  <h4 className="text-xs font-black text-emerald-300">تم بدء تنزيل ملف التطبيق!</h4>
                  <p className="text-[11px] text-zinc-300 mt-0.5">
                    الملف متاح الآن في التنزيلات. اتبع الخطوات أدناه لتثبيته.
                  </p>
                </div>
              </div>

              {/* ACTION 1: Guide to Notification Bar (Does NOT re-download) */}
              <button
                onClick={handleInstallNowAction}
                className={`w-full py-3.5 rounded-2xl transition-all flex items-center justify-center gap-2.5 shadow-xl cursor-pointer active:scale-95 border ${
                  activeStepTab === 'notification'
                    ? 'bg-gradient-to-r from-emerald-500 via-emerald-400 to-teal-500 text-black font-black border-emerald-300 shadow-emerald-500/30'
                    : 'bg-zinc-900 hover:bg-zinc-800 text-zinc-200 font-bold border-zinc-700'
                } text-sm`}
              >
                <PackageCheck className="w-5 h-5 text-current" />
                <span>تثبيت الآن (من إشعار التنزيل)</span>
              </button>

              {/* ACTION 2: Guide to Downloads / Files Folder (Does NOT re-download) */}
              <button
                onClick={handleOpenFileAction}
                className={`w-full py-3 rounded-2xl transition-all flex items-center justify-center gap-2 cursor-pointer active:scale-95 border ${
                  activeStepTab === 'files'
                    ? 'bg-gradient-to-r from-emerald-500 via-emerald-400 to-teal-500 text-black font-black border-emerald-300 shadow-emerald-500/30'
                    : 'bg-zinc-900 hover:bg-zinc-800 text-emerald-300 hover:text-white border-emerald-500/30 font-bold'
                } text-xs`}
              >
                <FolderOpen className="w-4 h-4 text-current" />
                <span>فتح الملف في مجلد التنزيلات</span>
              </button>

              {/* Clear, Step-by-Step Guidance Box */}
              <div className="p-3.5 bg-[#0A130F] border border-emerald-500/30 rounded-2xl text-[11px] text-zinc-300 space-y-2.5">
                <div className="flex items-center gap-2 text-emerald-400 font-bold">
                  <ChevronDown className="w-4 h-4 animate-bounce" />
                  <span>خطوات تثبيت ملف APK على جهازك:</span>
                </div>
                <div className="space-y-2 pr-1 text-zinc-300 leading-relaxed">
                  {activeStepTab === 'notification' ? (
                    <div className="p-2.5 rounded-xl bg-emerald-500/20 border border-emerald-500/40 text-white space-y-1.5">
                      <div className="flex items-center gap-2 text-emerald-300 font-black">
                        <BellRing className="w-4 h-4 text-emerald-400" />
                        <span>التثبيت عبر شريط الإشعارات:</span>
                      </div>
                      <ol className="list-decimal list-inside space-y-1 text-zinc-200 pr-1">
                        <li>اسحب شريط الإشعارات من أعلى شاشة هاتفك.</li>
                        <li>اضغط على إشعار اكتمال تنزيل ملف <strong className="font-mono text-white">{apkFileName}</strong>.</li>
                        <li>اضغط على زر <strong>«تثبيت» (Install)</strong> عندما يطلبه منك نظام أندرويد.</li>
                      </ol>
                    </div>
                  ) : (
                    <div className="p-2.5 rounded-xl bg-emerald-500/20 border border-emerald-500/40 text-white space-y-1.5">
                      <div className="flex items-center gap-2 text-emerald-300 font-black">
                        <FolderOpen className="w-4 h-4 text-emerald-400" />
                        <span>التثبيت عبر مدير الملفات / التنزيلات:</span>
                      </div>
                      <ol className="list-decimal list-inside space-y-1 text-zinc-200 pr-1">
                        <li>افتح تطبيق <strong>«ملفاتي»</strong> أو <strong>«التنزيلات (Files / Downloads)»</strong> على هاتفك.</li>
                        <li>ادخل إلى مجلد <strong>التنزيلات (Downloads)</strong>.</li>
                        <li>اضغط على ملف <strong className="font-mono text-white">{apkFileName}</strong> واختر <strong>«تثبيت»</strong>.</li>
                      </ol>
                    </div>
                  )}
                </div>
              </div>

              {/* Explicit Re-download or Copy Link (ONLY HERE is a new download triggered) */}
              <div className="flex items-center gap-2 pt-1">
                <button
                  onClick={handleStartDownload}
                  className="flex-1 py-2 px-3 rounded-xl bg-zinc-900 hover:bg-zinc-800 text-zinc-400 hover:text-white border border-zinc-800 text-[11px] font-bold transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
                  title="إعادة تنزيل الملف مرة أخرى"
                >
                  <RotateCcw className="w-3.5 h-3.5 text-amber-400" />
                  <span>إعادة تنزيل الملف</span>
                </button>

                <button
                  onClick={handleCopyLink}
                  className="py-2 px-3 rounded-xl bg-zinc-900 hover:bg-zinc-800 text-zinc-400 hover:text-white border border-zinc-800 text-[11px] font-bold transition-colors flex items-center justify-center gap-1 cursor-pointer"
                  title="نسخ الرابط المباشر"
                >
                  {copiedLink ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>نسخ الرابط</span>
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Installation Tip Footer */}
        <div className="pt-2 border-t border-zinc-800/80 text-[10px] text-zinc-400 text-center relative z-10">
          💡 يتم حفظ الملف بأمان في مجلد التنزيلات بجهازك، وتثبيته عبر نظام أندرويد لحماية خصوصيتك وأمان جهازك.
        </div>
      </div>
    </div>
  );
};
