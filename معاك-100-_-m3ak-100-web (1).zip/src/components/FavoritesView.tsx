import React from 'react';
import { useApp } from '../context/AppContext';
import { ProductCard } from './ProductCard';
import { Heart, ArrowLeft, Sparkles } from 'lucide-react';

export const FavoritesView: React.FC = () => {
  const { products, favorites, setCurrentView } = useApp();

  const favoriteProducts = products.filter(p => favorites.includes(p.id));

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Header */}
      <div className="flex items-center justify-between mb-8">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-2xl bg-[#E50914]/15 text-[#FF3344]">
            <Heart className="w-6 h-6 fill-current" />
          </div>
          <div>
            <h1 className="text-2xl sm:text-3xl font-black text-white">المفضلة</h1>
            <p className="text-xs sm:text-sm text-zinc-400">
              المنتجات التي قمت بحفظها للرجوع إليها وطلبها لاحقاً
            </p>
          </div>
        </div>

        <button
          onClick={() => setCurrentView('products')}
          className="text-xs sm:text-sm font-bold text-[#FF3344] hover:underline flex items-center gap-1"
        >
          <span>تصفح كل المنتجات</span>
          <ArrowLeft className="w-4 h-4" />
        </button>
      </div>

      {favoriteProducts.length === 0 ? (
        <div className="text-center py-20 px-4 bg-[#161616] border border-[#2A2A2A] rounded-3xl space-y-4">
          <div className="w-16 h-16 rounded-2xl bg-zinc-800/80 text-zinc-500 flex items-center justify-center mx-auto">
            <Heart className="w-8 h-8" />
          </div>
          <h3 className="text-lg font-bold text-white">قائمة المفضلة فارغة حالياً</h3>
          <p className="text-xs sm:text-sm text-zinc-400 max-w-sm mx-auto leading-relaxed">
            اضغط على علامة القلب ❤️ بجانب أي منتج لحفظه هنا والوصول إليه بسرعة في أي وقت.
          </p>
          <button
            onClick={() => setCurrentView('products')}
            className="px-6 py-2.5 rounded-full bg-[#E50914] text-white text-xs font-bold hover:bg-[#FF3344] transition-colors inline-block"
          >
            اكتشف المنتجات
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-2.5 sm:gap-4">
          {favoriteProducts.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      )}
    </div>
  );
};
