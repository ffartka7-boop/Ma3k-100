import React, { useState, useMemo } from 'react';
import { useApp } from '../context/AppContext';
import {
  ShoppingBag,
  Clock,
  CheckCircle2,
  XCircle,
  AlertCircle,
  Copy,
  Check,
  ExternalLink,
  Store,
  Tag,
  ArrowLeft,
  Trash2,
  Search,
  RotateCcw,
  Calendar,
  Layers,
  AlertTriangle,
  Eye,
  X
} from 'lucide-react';
import type { Order } from '../types';
import { getCountryDetails } from '../utils/country';

export const OrdersView: React.FC = () => {
  const { orders, deleteOrder, setActiveOrderModal, products, activeCurrency, setCurrentView } = useApp();

  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<'ALL' | 'PENDING' | 'REVIEW' | 'APPROVED' | 'REJECTED'>('ALL');
  const [deletingOrderId, setDeletingOrderId] = useState<string | null>(null);
  const [isDeletingLoading, setIsDeletingLoading] = useState(false);
  const [showClearAllModal, setShowClearAllModal] = useState(false);
  const [previewImage, setPreviewImage] = useState<{ url: string; title: string } | null>(null);

  const copyToClipboard = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2500);
  };

  const handlePayOrder = (order: Order) => {
    const prod = products.find(p => p.id === order.product_id) || {
      id: order.product_id,
      name: order.product_name,
      image_url: order.product_image,
      price: order.product_price,
      budget: 100,
      description: '',
      category_id: 'all',
      store_name: order.store_name,
      original_product_url: order.original_product_url,
      affiliate_url: order.affiliate_url,
      is_featured: false,
      is_available: true
    };
    setActiveOrderModal({ product: prod, order, step: 'pay' });
  };

  const handleReorder = (order: Order) => {
    const prod = products.find(p => p.id === order.product_id) || {
      id: order.product_id,
      name: order.product_name,
      image_url: order.product_image,
      price: order.product_price,
      budget: 100,
      description: '',
      category_id: 'all',
      store_name: order.store_name,
      original_product_url: order.original_product_url,
      affiliate_url: order.affiliate_url,
      is_featured: false,
      is_available: true
    };
    setActiveOrderModal({ product: prod, step: 'confirm' });
  };

  const confirmDeleteOrder = async () => {
    if (!deletingOrderId) return;
    setIsDeletingLoading(true);
    try {
      await deleteOrder(deletingOrderId);
      setDeletingOrderId(null);
    } finally {
      setIsDeletingLoading(false);
    }
  };

  const confirmClearAll = async () => {
    setIsDeletingLoading(true);
    try {
      for (const order of orders) {
        await deleteOrder(order.order_id);
      }
      setShowClearAllModal(false);
    } finally {
      setIsDeletingLoading(false);
    }
  };

  // Filtered orders
  const filteredOrders = useMemo(() => {
    return orders.filter(order => {
      const isApproved = order.payment_status === 'APPROVED' || order.payment_status === 'Paid';
      const isReview = order.payment_status === 'PAYMENT_REVIEW';
      const isRejected = order.payment_status === 'REJECTED';
      const isPending = order.payment_status === 'PENDING_PAYMENT';

      let matchesStatus = true;
      if (statusFilter === 'APPROVED') matchesStatus = isApproved;
      else if (statusFilter === 'REVIEW') matchesStatus = isReview;
      else if (statusFilter === 'REJECTED') matchesStatus = isRejected;
      else if (statusFilter === 'PENDING') matchesStatus = isPending;

      if (!matchesStatus) return false;

      if (!searchQuery.trim()) return true;
      const q = searchQuery.toLowerCase().trim();
      return (
        order.order_id.toLowerCase().includes(q) ||
        order.product_name.toLowerCase().includes(q) ||
        (order.store_name && order.store_name.toLowerCase().includes(q)) ||
        (order.coupon_code && order.coupon_code.toLowerCase().includes(q))
      );
    });
  }, [orders, statusFilter, searchQuery]);

  const counts = useMemo(() => {
    return {
      all: orders.length,
      pending: orders.filter(o => o.payment_status === 'PENDING_PAYMENT').length,
      review: orders.filter(o => o.payment_status === 'PAYMENT_REVIEW').length,
      approved: orders.filter(o => o.payment_status === 'APPROVED' || o.payment_status === 'Paid').length,
      rejected: orders.filter(o => o.payment_status === 'REJECTED').length,
    };
  }, [orders]);

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-2xl bg-[#E50914]/15 text-[#FF3344] shrink-0">
            <ShoppingBag className="w-6 h-6" />
          </div>
          <div>
            <h1 className="text-2xl sm:text-3xl font-black text-white flex items-center gap-2">
              <span>سجل الطلبات</span>
              <span className="text-xs px-2.5 py-0.5 rounded-full bg-zinc-800 text-zinc-300 font-normal">
                {orders.length} طلب
              </span>
            </h1>
            <p className="text-xs sm:text-sm text-zinc-400">
              تابع حالة سداد رسوم الخدمة وروابط المتاجر، مع إمكانية حذف أو إعادة طلب أي منتج
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {orders.length > 0 && (
            <button
              onClick={() => setShowClearAllModal(true)}
              className="text-xs font-bold text-zinc-400 hover:text-red-400 bg-[#161616] hover:bg-red-500/10 px-3 py-2 rounded-xl border border-[#2A2A2A] hover:border-red-500/30 transition-all flex items-center gap-1.5"
              title="تفريغ سجل الطلبات"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>حذف الكل</span>
            </button>
          )}

          <button
            onClick={() => setCurrentView('products')}
            className="text-xs sm:text-sm font-bold text-white bg-[#E50914] hover:bg-[#FF3344] px-4 py-2 rounded-xl transition-all flex items-center gap-1.5 shadow-md shadow-[#E50914]/20"
          >
            <span>تصفح المنتجات</span>
            <ArrowLeft className="w-4 h-4" />
          </button>
        </div>
      </div>

      {orders.length === 0 ? (
        <div className="text-center py-16 px-4 bg-[#161616] border border-[#2A2A2A] rounded-3xl space-y-4">
          <div className="w-16 h-16 rounded-2xl bg-zinc-800/80 text-zinc-500 flex items-center justify-center mx-auto">
            <ShoppingBag className="w-8 h-8" />
          </div>
          <h3 className="text-lg font-bold text-white">ليس لديك أي طلبات حتى الآن</h3>
          <p className="text-xs sm:text-sm text-zinc-400 max-w-sm mx-auto leading-relaxed">
            اختر المنتجات المناسبة لميزانيتك من مختلف المتاجر، وسنقوم بتوفير الروابط المباشرة بأفضل الأسعار.
          </p>
          <button
            onClick={() => setCurrentView('products')}
            className="px-6 py-2.5 rounded-full bg-[#E50914] text-white text-xs font-bold hover:bg-[#FF3344] transition-colors inline-block"
          >
            اكتشف المنتجات الآن
          </button>
        </div>
      ) : (
        <div className="space-y-4">
          {/* Filter Bar & Search */}
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 bg-[#161616] p-3.5 sm:p-4 rounded-2xl border border-[#2A2A2A]">
            <div className="flex items-center gap-1.5 overflow-x-auto pb-1 sm:pb-0 scrollbar-none">
              {[
                { id: 'ALL', label: `الكل (${counts.all})` },
                { id: 'PENDING', label: `بانتظار السداد (${counts.pending})` },
                { id: 'REVIEW', label: `قيد المراجعة (${counts.review})` },
                { id: 'APPROVED', label: `المفعلة (${counts.approved})` },
                { id: 'REJECTED', label: `المرفوضة (${counts.rejected})` }
              ].map(tab => (
                <button
                  key={tab.id}
                  onClick={() => setStatusFilter(tab.id as any)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition-colors ${
                    statusFilter === tab.id
                      ? 'bg-[#E50914] text-white shadow-sm'
                      : 'bg-[#0B0B0B] text-zinc-400 hover:text-white border border-zinc-800'
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </div>

            <div className="relative flex-1 sm:max-w-xs">
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="بحث برقم الطلب أو اسم المنتج..."
                className="w-full bg-[#0B0B0B] text-white text-xs rounded-xl pl-8 pr-3 py-2 border border-zinc-800 focus:outline-none focus:border-[#E50914]"
              />
              <Search className="w-3.5 h-3.5 text-zinc-500 absolute left-2.5 top-1/2 -translate-y-1/2 pointer-events-none" />
            </div>
          </div>

          {filteredOrders.length === 0 ? (
            <div className="text-center py-12 px-4 bg-[#161616] border border-[#2A2A2A] rounded-3xl space-y-2">
              <p className="text-sm text-zinc-300 font-bold">لا توجد طلبات مطابقة للبحث أو الفلتر المحدد</p>
              <p className="text-xs text-zinc-500">جرب تغيير حالة الفلتر أو كتابة كلمة بحث أخرى</p>
            </div>
          ) : (
            filteredOrders.map((order) => {
              const isApproved = order.payment_status === 'APPROVED' || order.payment_status === 'Paid';
              const isReview = order.payment_status === 'PAYMENT_REVIEW';
              const isRejected = order.payment_status === 'REJECTED';
              const isPending = order.payment_status === 'PENDING_PAYMENT';
              const country = getCountryDetails(order.country_code);

              const targetUrl = order.affiliate_url || order.original_product_url;

              return (
                <div
                  key={order.order_id}
                  className={`bg-[#161616] border rounded-3xl p-5 sm:p-6 transition-all relative overflow-hidden ${
                    isApproved
                      ? 'border-emerald-500/40 bg-gradient-to-b from-[#161616] to-emerald-950/10'
                      : isRejected
                      ? 'border-red-500/40 bg-gradient-to-b from-[#161616] to-red-950/10'
                      : isReview
                      ? 'border-amber-500/40 bg-gradient-to-b from-[#161616] to-amber-950/10'
                      : 'border-[#2A2A2A]'
                  }`}
                >
                  {/* Top Row: Order ID, Country Flag, Status Badge, and DELETE BUTTON */}
                  <div className="flex flex-wrap items-center justify-between gap-2 pb-4 border-b border-zinc-800">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="text-xs text-zinc-400">رقم الطلب:</span>
                      <span className="text-xs font-mono font-bold text-white bg-zinc-800 px-2 py-0.5 rounded">
                        {order.order_id}
                      </span>
                      <button
                        onClick={() => copyToClipboard(order.order_id, `orderid_${order.order_id}`)}
                        className="text-zinc-500 hover:text-white transition-colors"
                        title="نسخ رقم الطلب"
                      >
                        {copiedId === `orderid_${order.order_id}` ? (
                          <Check className="w-3 h-3 text-emerald-400" />
                        ) : (
                          <Copy className="w-3 h-3" />
                        )}
                      </button>

                      <span
                        className="px-2 py-0.5 rounded-full bg-zinc-900 border border-zinc-700 text-white text-[10px] font-bold flex items-center gap-1"
                        title={`دولة الطلب: ${country.fullName}`}
                      >
                        <span>{country.flag}</span>
                        <span>{country.name}</span>
                      </span>
                    </div>

                    <div className="flex items-center gap-2">
                      {/* Status Badge */}
                      <div>
                        {isApproved && (
                          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/15 text-emerald-400 text-xs font-bold border border-emerald-500/30">
                            <CheckCircle2 className="w-3.5 h-3.5" />
                            <span>تم قبول الدفع وتفعيل الرابط ✅</span>
                          </span>
                        )}
                        {isReview && (
                          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-500/15 text-amber-300 text-xs font-bold border border-amber-500/30 animate-pulse">
                            <Clock className="w-3.5 h-3.5" />
                            <span>قيد مراجعة الدفع ⏳</span>
                          </span>
                        )}
                        {isRejected && (
                          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-red-500/15 text-red-400 text-xs font-bold border border-red-500/30">
                            <XCircle className="w-3.5 h-3.5" />
                            <span>عفواً لم يتم الدفع ❌</span>
                          </span>
                        )}
                        {isPending && (
                          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#E50914]/15 text-[#FF3344] text-xs font-bold border border-[#E50914]/30">
                            <AlertCircle className="w-3.5 h-3.5" />
                            <span>بانتظار السداد ({order.order_fee} {activeCurrency}) 💳</span>
                          </span>
                        )}
                      </div>

                      {/* Explicit Delete Button */}
                      <button
                        onClick={() => setDeletingOrderId(order.order_id)}
                        className="p-1.5 sm:px-2.5 sm:py-1 rounded-xl bg-zinc-900/90 hover:bg-red-500/20 text-zinc-400 hover:text-red-400 border border-zinc-800 hover:border-red-500/30 transition-all flex items-center gap-1 text-xs font-bold"
                        title="حذف هذا الطلب من السجل"
                      >
                        <Trash2 className="w-3.5 h-3.5 text-red-400" />
                        <span className="hidden sm:inline">حذف</span>
                      </button>
                    </div>
                  </div>

                  {/* Main Content: Product Details */}
                  <div className="py-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                    <div className="flex items-center gap-3.5 sm:gap-4">
                      {/* Contained Product Thumbnail */}
                      <div
                        onClick={() => setPreviewImage({
                          url: order.product_image || 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=300',
                          title: order.product_name
                        })}
                        className="w-20 h-20 sm:w-24 sm:h-24 rounded-2xl bg-[#080808] border border-zinc-800 hover:border-zinc-600 p-1.5 flex items-center justify-center shrink-0 relative overflow-hidden group cursor-pointer shadow-inner transition-colors"
                        title="انقر لتكبير صورة المنتج"
                      >
                        <div
                          className="absolute inset-0 bg-cover bg-center blur-md opacity-20 scale-125 pointer-events-none"
                          style={{ backgroundImage: `url(${order.product_image || 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=300'})` }}
                        />
                        <img
                          src={order.product_image || 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=300'}
                          alt={order.product_name}
                          className="relative z-10 w-full h-full object-contain rounded-xl select-none group-hover:scale-105 transition-transform"
                          referrerPolicy="no-referrer"
                        />
                        <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center z-20">
                          <Eye className="w-4 h-4 text-white drop-shadow" />
                        </div>
                      </div>

                      <div>
                        <h3 className="text-base font-black text-white mb-1 leading-snug">{order.product_name}</h3>
                        <p className="text-xs text-zinc-400 flex items-center gap-1.5 flex-wrap">
                          <Store className="w-3.5 h-3.5 text-[#FF3344]" />
                          <span className="text-zinc-500 font-bold">متاح في: {country.flag} {country.name}</span>
                        </p>
                        <p className="text-xs text-zinc-500 mt-1">
                          سعر المنتج: <strong className="text-white">{order.product_price} {country.currencySymbol}</strong> | رسوم الطلب: <strong className="text-[#FF3344]">{order.order_fee} {activeCurrency}</strong>
                        </p>
                      </div>
                    </div>

                    {/* Actions depending on status */}
                    <div className="w-full sm:w-auto flex flex-wrap sm:flex-nowrap items-center gap-2">
                      {isPending && (
                        <button
                          onClick={() => handlePayOrder(order)}
                          className="flex-1 sm:flex-none px-5 py-2.5 rounded-full bg-[#E50914] hover:bg-[#FF3344] text-white text-xs font-bold transition-all shadow-md shadow-[#E50914]/20 text-center"
                        >
                          سداد الرسوم الآن ({order.order_fee} {activeCurrency})
                        </button>
                      )}

                      {isRejected && (
                        <button
                          onClick={() => handlePayOrder(order)}
                          className="flex-1 sm:flex-none px-5 py-2.5 rounded-full bg-[#E50914] hover:bg-[#FF3344] text-white text-xs font-bold transition-all shadow-md text-center"
                        >
                          إعادة محاولة السداد 💳
                        </button>
                      )}

                      <button
                        onClick={() => handleReorder(order)}
                        className="flex-1 sm:flex-none px-3.5 py-2.5 rounded-full bg-zinc-800 hover:bg-zinc-700 text-zinc-300 hover:text-white text-xs font-bold transition-all flex items-center justify-center gap-1.5 border border-zinc-700"
                        title="طلب نسخة جديدة من هذا المنتج"
                      >
                        <RotateCcw className="w-3.5 h-3.5" />
                        <span>طلب جديد</span>
                      </button>
                    </div>
                  </div>

                  {/* REJECTION NOTICE */}
                  {isRejected && (
                    <div className="p-3.5 rounded-2xl bg-red-950/30 border border-red-500/40 text-xs text-red-300 space-y-1">
                      <p className="font-bold flex items-center gap-1.5">
                        <XCircle className="w-4 h-4 text-red-400" />
                        <span>تنبيه: تم رفض الدفع</span>
                      </p>
                      <p className="text-zinc-300">
                        {order.rejection_reason || 'تم رفض العملية من قبل الإدارة لعدم وضوح الإيصال أو عدم مطابقة المبلغ. يرجى إعادة سداد الرسوم بشكل صحيح.'}
                      </p>
                    </div>
                  )}

                  {/* UNDER REVIEW NOTICE */}
                  {isReview && (
                    <div className="p-3.5 rounded-2xl bg-amber-500/10 border border-amber-500/30 text-xs text-amber-200">
                      <p className="leading-relaxed">
                        ⏳ إيصالك قيد المراجعة الفورية من فريق الإدارة. بمجرد التحقق، سيظهر لك رابط الشراء المباشر وكوبون الخصم هنا فوراً.
                      </p>
                    </div>
                  )}

                  {/* APPROVED: REVEAL LINK & COUPON */}
                  {isApproved && (
                    <div className="mt-2 pt-4 border-t border-zinc-800/80 space-y-3">
                      {/* Coupon Box if available */}
                      {order.coupon_code && (
                        <div className="p-3 rounded-xl bg-emerald-950/40 border border-emerald-500/30 flex items-center justify-between gap-2">
                          <div className="flex items-center gap-2">
                            <Tag className="w-4 h-4 text-emerald-400" />
                            <span className="text-xs text-zinc-300 font-bold">كود كوبون الخصم:</span>
                            <span className="text-sm font-black text-white font-mono bg-black/40 px-2 py-0.5 rounded">
                              {order.coupon_code}
                            </span>
                          </div>
                          <button
                            onClick={() => copyToClipboard(order.coupon_code!, `coupon_${order.order_id}`)}
                            className="px-3 py-1 rounded-lg bg-emerald-500 hover:bg-emerald-400 text-black text-xs font-black flex items-center gap-1"
                          >
                            {copiedId === `coupon_${order.order_id}` ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                            <span>{copiedId === `coupon_${order.order_id}` ? 'تم النسخ' : 'نسخ الكود'}</span>
                          </button>
                        </div>
                      )}

                      {/* Direct Product Link Section */}
                      <div className="p-3.5 rounded-2xl bg-[#0B0B0B] border border-emerald-500/30 flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
                        <div className="flex-1 min-w-0">
                          <span className="text-[11px] text-emerald-400 font-bold block mb-1">
                            رابط الشراء المباشر مفعل وجاهز:
                          </span>
                          <p className="text-xs text-zinc-400 font-mono truncate">{targetUrl}</p>
                        </div>

                        <div className="flex items-center gap-2">
                          <button
                            onClick={() => copyToClipboard(targetUrl, `url_${order.order_id}`)}
                            className="flex-1 sm:flex-none px-3.5 py-2 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-white text-xs font-bold flex items-center justify-center gap-1.5 border border-zinc-700"
                          >
                            {copiedId === `url_${order.order_id}` ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                            <span>{copiedId === `url_${order.order_id}` ? 'تم النسخ' : 'نسخ الرابط'}</span>
                          </button>

                          <a
                            href={targetUrl}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="flex-1 sm:flex-none px-5 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-black text-xs font-black flex items-center justify-center gap-1.5 transition-colors shadow-md"
                          >
                            <ExternalLink className="w-3.5 h-3.5" />
                            <span>الانتقال والشراء 🛒</span>
                          </a>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              );
            })
          )}
        </div>
      )}

      {/* SINGLE ORDER DELETE CONFIRMATION MODAL */}
      {deletingOrderId && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4 animate-fadeIn">
          <div className="bg-[#161616] border border-red-500/30 w-full max-w-md rounded-3xl p-6 shadow-2xl space-y-4">
            <div className="w-12 h-12 rounded-2xl bg-red-500/15 text-red-400 flex items-center justify-center mx-auto">
              <AlertTriangle className="w-6 h-6" />
            </div>

            <div className="text-center space-y-2">
              <h3 className="text-lg font-black text-white">تأكيد حذف الطلب</h3>
              <p className="text-xs sm:text-sm text-zinc-400 leading-relaxed">
                هل أنت متأكد من حذف الطلب رقم <span className="text-white font-mono font-bold">({deletingOrderId})</span> من سجلك؟
              </p>
              <p className="text-[11px] text-zinc-500">
                سيتم حذف سجل هذا الطلب نهائياً من حسابك وقاعدة البيانات.
              </p>
            </div>

            <div className="flex gap-3 pt-2">
              <button
                type="button"
                onClick={() => setDeletingOrderId(null)}
                disabled={isDeletingLoading}
                className="flex-1 py-2.5 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-zinc-300 text-xs font-bold transition-colors"
              >
                إلغاء
              </button>
              <button
                type="button"
                onClick={confirmDeleteOrder}
                disabled={isDeletingLoading}
                className="flex-1 py-2.5 rounded-xl bg-red-600 hover:bg-red-500 text-white text-xs font-bold transition-colors flex items-center justify-center gap-1.5 shadow-lg shadow-red-600/30"
              >
                <Trash2 className="w-4 h-4" />
                <span>{isDeletingLoading ? 'جاري الحذف...' : 'نعم، حذف الطلب'}</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* CLEAR ALL ORDERS CONFIRMATION MODAL */}
      {showClearAllModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4 animate-fadeIn">
          <div className="bg-[#161616] border border-red-500/30 w-full max-w-md rounded-3xl p-6 shadow-2xl space-y-4">
            <div className="w-12 h-12 rounded-2xl bg-red-500/15 text-red-400 flex items-center justify-center mx-auto">
              <Trash2 className="w-6 h-6" />
            </div>

            <div className="text-center space-y-2">
              <h3 className="text-lg font-black text-white">تفريغ سجل الطلبات بالكامل</h3>
              <p className="text-xs sm:text-sm text-zinc-400 leading-relaxed">
                هل تريد حقاً حذف جميع الطلبات ({orders.length} طلب) من سجلك؟
              </p>
            </div>

            <div className="flex gap-3 pt-2">
              <button
                type="button"
                onClick={() => setShowClearAllModal(false)}
                disabled={isDeletingLoading}
                className="flex-1 py-2.5 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-zinc-300 text-xs font-bold transition-colors"
              >
                إلغاء
              </button>
              <button
                type="button"
                onClick={confirmClearAll}
                disabled={isDeletingLoading}
                className="flex-1 py-2.5 rounded-xl bg-red-600 hover:bg-red-500 text-white text-xs font-bold transition-colors flex items-center justify-center gap-1.5 shadow-lg shadow-red-600/30"
              >
                <Trash2 className="w-4 h-4" />
                <span>{isDeletingLoading ? 'جاري الحذف...' : 'تأكيد تفريغ السجل'}</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Image Preview Lightbox Modal */}
      {previewImage && (
        <div
          className="fixed inset-0 z-50 bg-black/95 backdrop-blur-md flex items-center justify-center p-4 animate-in fade-in duration-200"
          onClick={() => setPreviewImage(null)}
        >
          <div
            className="relative max-w-3xl w-full bg-[#111] border border-zinc-800 rounded-3xl p-4 flex flex-col items-center gap-3 shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="w-full flex items-center justify-between pb-2 border-b border-zinc-800">
              <h4 className="text-sm font-bold text-white truncate max-w-[80%]">{previewImage.title}</h4>
              <button
                onClick={() => setPreviewImage(null)}
                className="p-1.5 rounded-full bg-zinc-800 hover:bg-zinc-700 text-zinc-300 hover:text-white transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="relative w-full h-[60vh] flex items-center justify-center bg-[#070707] rounded-2xl overflow-hidden p-2">
              <img
                src={previewImage.url}
                alt={previewImage.title}
                className="max-w-full max-h-full object-contain rounded-xl drop-shadow-2xl"
                referrerPolicy="no-referrer"
              />
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
