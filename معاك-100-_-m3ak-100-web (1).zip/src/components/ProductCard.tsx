import React, { useState } from 'react';
import type { Product } from '../types';
import { useApp } from '../context/AppContext';
import { Heart, ShoppingCart, Eye, Tag, ChevronRight, ChevronLeft } from 'lucide-react';
import { getCountryDetails } from '../utils/country';

interface ProductCardProps {
  product: Product;
}

export const ProductCard: React.FC<ProductCardProps> = ({ product }) => {
  const {
    favorites,
    toggleFavorite,
    setActiveProductModal,
    setActiveOrderModal
  } = useApp();
  
  const [currentImgIndex, setCurrentImgIndex] = useState(0);

  const isFav = favorites.includes(product.id);
  const country = getCountryDetails(product.country_code);

  const allImages = [product.image_url];
  if (product.additional_images_json) {
    try {
      const extra = JSON.parse(product.additional_images_json);
      if (Array.isArray(extra)) {
        allImages.push(...extra.filter(Boolean));
      }
    } catch {}
  }

  const handleCardClick = () => {
    setActiveProductModal(product);
  };

  const handleOrderClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    setActiveOrderModal({ product, step: 'confirm' });
  };
  
  const handleNextImg = (e: React.MouseEvent) => {
    e.stopPropagation();
    setCurrentImgIndex((prev) => (prev + 1) % allImages.length);
  };

  const handlePrevImg = (e: React.MouseEvent) => {
    e.stopPropagation();
    setCurrentImgIndex((prev) => (prev - 1 + allImages.length) % allImages.length);
  };

  return (
    <div
      onClick={handleCardClick}
      className="group relative bg-[#151515] hover:bg-[#1A1A1A] border border-[#242424] hover:border-[#E50914]/60 rounded-xl sm:rounded-2xl overflow-hidden transition-all duration-200 transform hover:-translate-y-0.5 cursor-pointer flex flex-col shadow-sm hover:shadow-lg hover:shadow-black/50"
    >
      {/* Product Image Box */}
      <div className="relative aspect-square sm:aspect-[4/5] w-full overflow-hidden bg-[#0D0D0D] flex items-center justify-center p-2">
        {/* Subtle blurred ambient backdrop */}
        <div
          className="absolute inset-0 bg-center bg-cover blur-xl opacity-20 scale-125 pointer-events-none transition-opacity duration-300 group-hover:opacity-30"
          style={{ backgroundImage: `url(${allImages[currentImgIndex]})` }}
        />

        <img
          src={allImages[currentImgIndex]}
          alt={product.name}
          className="relative z-[1] w-full h-full object-contain object-center group-hover:scale-105 transition-transform duration-300 drop-shadow-md select-none"
          loading="lazy"
          referrerPolicy="no-referrer"
        />

        {allImages.length > 1 && (
          <>
            <button
              onClick={handlePrevImg}
              className="absolute right-1.5 top-1/2 -translate-y-1/2 p-1.5 bg-black/50 text-white rounded-full hover:bg-black/80 transition-colors backdrop-blur-md opacity-0 group-hover:opacity-100 z-20"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
            <button
              onClick={handleNextImg}
              className="absolute left-1.5 top-1/2 -translate-y-1/2 p-1.5 bg-black/50 text-white rounded-full hover:bg-black/80 transition-colors backdrop-blur-md opacity-0 group-hover:opacity-100 z-20"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <div className="absolute bottom-2 left-1/2 -translate-x-1/2 bg-black/50 backdrop-blur-md px-2 py-1 rounded-full flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity z-20">
              {allImages.map((_, i) => (
                <span key={i} className={`w-1 h-1 rounded-full transition-colors ${i === currentImgIndex ? 'bg-[#E50914] w-2' : 'bg-white/50'}`} />
              ))}
            </div>
          </>
        )}

        {/* Gradient Shadow Overlay */}
        <div className="absolute inset-0 bg-gradient-to-t from-[#151515] via-transparent to-black/30 pointer-events-none" />

        {/* Top Badges: Country Flag & Badge + Favorites */}
        <div className="absolute top-1.5 inset-x-1.5 flex items-center justify-between z-10">
          <div className="flex items-center gap-1 flex-wrap">
            {/* Prominent Country Flag Badge */}
            <span
              className="px-2 py-0.5 rounded-full bg-black/85 backdrop-blur-md text-white text-[10px] sm:text-[11px] font-black border border-white/20 shadow-md flex items-center gap-1 hover:scale-105 transition-transform"
              title={`دولة النشر: ${country.fullName}`}
            >
              <span className="text-sm leading-none">{country.flag}</span>
              <span className="font-bold">{country.name}</span>
            </span>

            {/* Budget Pill */}
            <span className="px-1.5 py-0.5 rounded-full bg-[#E50914]/90 text-white text-[8px] sm:text-[9px] font-black border border-white/10 shadow-sm">
              {product.budget} {country.currencySymbol}
            </span>

            {product.is_featured && (
              <span className="px-1 py-0.5 rounded bg-[#FFD700] text-black text-[8px] font-black shadow-sm">
                ⭐
              </span>
            )}
          </div>

          {/* Favorite Heart Button */}
          <button
            onClick={(e) => {
              e.stopPropagation();
              toggleFavorite(product.id);
            }}
            className={`w-6 h-6 rounded-full flex items-center justify-center backdrop-blur-md transition-all active:scale-90 shadow-sm shrink-0 ${
              isFav
                ? 'bg-[#E50914] text-white'
                : 'bg-black/60 text-white/80 hover:text-white hover:bg-black/80'
            }`}
            title={isFav ? 'إزالة من المفضلة' : 'حفظ في المفضلة'}
          >
            <Heart className={`w-3 h-3 ${isFav ? 'fill-current text-white' : ''}`} />
          </button>
        </div>

        {/* Coupon pill if available */}
        {product.coupon_code && (
          <div className="absolute bottom-1.5 right-1.5 bg-[#E50914]/90 text-white text-[8px] font-bold px-1.5 py-0.5 rounded backdrop-blur-sm flex items-center gap-0.5 shadow-sm">
            <Tag className="w-2 h-2" />
            <span>{product.coupon_code}</span>
          </div>
        )}
      </div>

      {/* Product Content Details */}
      <div className="p-2 sm:p-2.5 flex-1 flex flex-col justify-between gap-1.5">
        <div>
          {/* Country Tag */}
          <div className="flex items-center justify-between text-[10px] text-zinc-400 mb-0.5">
            <span className="flex items-center gap-1 text-zinc-300 font-medium truncate max-w-[80%]">
              <span className="text-zinc-400 font-bold shrink-0">{country.flag} {country.name}</span>
            </span>
            {product.order_count ? (
              <span className="text-[9px] text-zinc-500 shrink-0">
                {product.order_count} طلب
              </span>
            ) : null}
          </div>

          {/* Title */}
          <h3 className="text-[11px] sm:text-xs font-bold text-white line-clamp-2 leading-snug group-hover:text-[#FF3344] transition-colors">
            {product.name}
          </h3>
        </div>

        {/* Price and Action Button */}
        <div className="pt-1.5 border-t border-zinc-800/80 flex items-center justify-between gap-1">
          <div className="min-w-0">
            <div className="flex items-baseline gap-0.5">
              <span className="text-xs sm:text-sm font-black text-white truncate">
                {product.price.toLocaleString('ar-EG')}
              </span>
              <span className="text-[9px] sm:text-[10px] text-[#FF3344] font-bold shrink-0">
                {country.currencySymbol}
              </span>
            </div>
          </div>

          <button
            onClick={handleOrderClick}
            className="px-2.5 py-1 rounded-full bg-white hover:bg-zinc-200 text-black text-[10px] sm:text-[11px] font-black transition-all transform active:scale-95 shadow flex items-center gap-1 shrink-0"
          >
            <span>اطلب</span>
          </button>
        </div>
      </div>
    </div>
  );
};
