import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { X, User, Check, AlertCircle } from 'lucide-react';

export const AuthModal: React.FC = () => {
  const {
    isAuthModalOpen,
    setIsAuthModalOpen,
    signInWithGoogleReal,
    setGuestUser
  } = useApp();

  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');
  const [successMsg, setSuccessMsg] = useState('');

  if (!isAuthModalOpen) return null;

  const handleGoogleClick = async () => {
    setError('');
    setIsLoading(true);
    try {
      await signInWithGoogleReal();
    } catch (err: any) {
      console.warn('Google sign-in error:', err);
      setError('تعذر تسجيل الدخول بـ Google، يرجى المحاولة مرة أخرى.');
      setIsLoading(false);
    }
  };

  const handleGuestClick = async () => {
    setError('');
    setIsLoading(true);
    try {
      await setGuestUser();
      setSuccessMsg('تم تسجيل الدخول كزائر بنجاح وتعيين رقمك التعريفي!');
      setTimeout(() => {
        setIsAuthModalOpen(false);
      }, 400);
    } catch (err: any) {
      console.warn('Guest sign-in error:', err);
      setError('حدث خطأ أثناء الدخول كزائر.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm animate-in fade-in duration-200">
      <div
        className="relative w-full max-w-md bg-[#121212] border border-[#2A2A2A] text-white rounded-3xl overflow-hidden shadow-2xl p-6 sm:p-7"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Close Button */}
        <button
          onClick={() => setIsAuthModalOpen(false)}
          className="absolute top-4 left-4 p-2 rounded-full bg-zinc-800 hover:bg-zinc-700 text-zinc-400 hover:text-white transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Brand Header */}
        <div className="text-center mb-6 pt-1">
          <div className="inline-flex items-center gap-2 mb-2">
            <div className="w-9 h-9 rounded-2xl bg-gradient-to-br from-[#E50914] to-[#990000] text-white font-black text-sm flex items-center justify-center shadow-lg shadow-[#E50914]/20">
              100
            </div>
            <span className="text-2xl font-black tracking-tight text-white">معاك 100</span>
          </div>
          <p className="text-xs text-zinc-400">
            تسجيل الدخول الموحد بحساب Google
          </p>
        </div>

        {/* Direct Action Buttons */}
        <div className="space-y-3.5">
          {/* Official Google Device Account Button */}
          <button
            type="button"
            onClick={handleGoogleClick}
            disabled={isLoading}
            className="w-full py-4 px-4 rounded-2xl bg-white hover:bg-zinc-100 active:scale-[0.99] text-black font-bold text-sm flex items-center justify-center gap-3 transition-all shadow-md shadow-white/10 disabled:opacity-50"
          >
            <svg className="w-5 h-5" viewBox="0 0 24 24">
              <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
              <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
              <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z" />
              <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z" />
            </svg>
            <span>تسجيل الدخول بحساب Google</span>
          </button>

          {/* Quick Guest Sign-In Button */}
          <button
            type="button"
            onClick={handleGuestClick}
            disabled={isLoading}
            className="w-full py-3 px-4 rounded-2xl bg-[#1A1A1A] hover:bg-[#242424] active:scale-[0.99] border border-zinc-800 hover:border-zinc-700 text-zinc-400 hover:text-white font-medium text-xs flex items-center justify-center gap-2.5 transition-all disabled:opacity-50"
          >
            <div className="w-5 h-5 rounded-full bg-zinc-800 text-zinc-400 flex items-center justify-center text-[10px]">
              <User className="w-3 h-3" />
            </div>
            <span>الدخول كزائر سريع (تصفح وطلب فوري)</span>
          </button>
        </div>

        {/* Feedback Messages */}
        {error && (
          <div className="mt-4 p-3 rounded-xl bg-red-950/60 border border-red-800/80 text-red-200 text-xs flex items-start gap-2">
            <AlertCircle className="w-4 h-4 shrink-0 mt-0.5 text-red-400" />
            <span className="leading-relaxed">{error}</span>
          </div>
        )}

        {successMsg && (
          <div className="mt-4 p-3 rounded-xl bg-emerald-950/60 border border-emerald-800/80 text-emerald-200 text-xs flex items-center gap-2">
            <Check className="w-4 h-4 shrink-0 text-emerald-400" />
            <span>{successMsg}</span>
          </div>
        )}
      </div>
    </div>
  );
};
