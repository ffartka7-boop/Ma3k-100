import React, { useState, useEffect, useCallback } from 'react';
import { useApp } from '../context/AppContext';
import {
  signInWithGoogleWorkspace,
  getCachedAccessToken,
  initGoogleAuth,
  logoutGoogle
} from '../lib/googleAuth';
import {
  fetchGmailProfile,
  listGmailMessages,
  getGmailMessageDetail,
  sendGmailEmail,
  createGmailDraft,
  trashGmailMessage,
  modifyGmailMessageLabels,
  GmailUserProfile,
  GmailMessageSummary,
  GmailMessageDetail
} from '../lib/gmailService';
import {
  Mail,
  Inbox,
  Send,
  FileText,
  Trash2,
  Star,
  RefreshCw,
  Search,
  Plus,
  ArrowRight,
  CheckCircle,
  AlertTriangle,
  Clock,
  User,
  ShieldCheck,
  X,
  Reply,
  ExternalLink,
  ChevronLeft,
  ChevronRight
} from 'lucide-react';

export const GmailView: React.FC = () => {
  const { currentUser, setIsAuthModalOpen } = useApp();

  // Auth & Connection State
  const [token, setToken] = useState<string | null>(getCachedAccessToken());
  const [isAuthenticating, setIsAuthenticating] = useState(false);
  const [gmailProfile, setGmailProfile] = useState<GmailUserProfile | null>(null);

  // Messages & Navigation State
  const [currentFolder, setCurrentFolder] = useState<'INBOX' | 'STARRED' | 'SENT' | 'DRAFT' | 'TRASH' | 'SPAM'>('INBOX');
  const [messages, setMessages] = useState<GmailMessageSummary[]>([]);
  const [isLoadingMessages, setIsLoadingMessages] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [activeMessage, setActiveMessage] = useState<GmailMessageDetail | null>(null);
  const [isLoadingDetail, setIsLoadingDetail] = useState(false);

  // Composer Modal State
  const [isComposeOpen, setIsComposeOpen] = useState(false);
  const [composeTo, setComposeTo] = useState('');
  const [composeSubject, setComposeSubject] = useState('');
  const [composeBody, setComposeBody] = useState('');
  const [isSending, setIsSending] = useState(false);
  const [isSavingDraft, setIsSavingDraft] = useState(false);

  // Destructive Action Confirmation Modal State
  const [trashConfirmId, setTrashConfirmId] = useState<string | null>(null);
  const [isTrashing, setIsTrashing] = useState(false);

  // Feedback Notification
  const [toastMessage, setToastMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  const showToast = (type: 'success' | 'error', text: string) => {
    setToastMessage({ type, text });
    setTimeout(() => setToastMessage(null), 4000);
  };

  // Auth State Listener
  useEffect(() => {
    const unsubscribe = initGoogleAuth(
      (user, accessToken) => {
        setToken(accessToken);
      },
      () => {
        // If memory token is cleared
        setToken(getCachedAccessToken());
      }
    );
    return () => unsubscribe();
  }, []);

  // Connect / Authorize with Google Workspace
  const handleConnectGmail = async () => {
    setIsAuthenticating(true);
    try {
      const result = await signInWithGoogleWorkspace();
      setToken(result.accessToken);
      showToast('success', 'تم الاتصال بحساب Gmail بنجاح!');
    } catch (err: any) {
      console.error('Google Workspace Connect error:', err);
      showToast('error', err.message || 'تعذر الاتصال بـ Gmail، يرجى المحاولة مجدداً.');
    } finally {
      setIsAuthenticating(false);
    }
  };

  // Load Gmail Profile
  const loadProfile = useCallback(async () => {
    if (!token) return;
    try {
      const prof = await fetchGmailProfile(token);
      setGmailProfile(prof);
    } catch (err) {
      console.warn('Load profile notice:', err);
    }
  }, [token]);

  // Load Messages for active folder / query
  const loadMessages = useCallback(async () => {
    if (!token) return;
    setIsLoadingMessages(true);
    try {
      let q = searchQuery.trim();
      let labelIds: string[] = [];

      if (!q) {
        if (currentFolder === 'INBOX') labelIds = ['INBOX'];
        else if (currentFolder === 'STARRED') labelIds = ['STARRED'];
        else if (currentFolder === 'SENT') labelIds = ['SENT'];
        else if (currentFolder === 'DRAFT') labelIds = ['DRAFT'];
        else if (currentFolder === 'TRASH') labelIds = ['TRASH'];
        else if (currentFolder === 'SPAM') labelIds = ['SPAM'];
      }

      const res = await listGmailMessages({ q: q || undefined, labelIds: labelIds.length ? labelIds : undefined, maxResults: 25 }, token);
      setMessages(res.messages);
    } catch (err: any) {
      console.error('Fetch messages error:', err);
      showToast('error', 'تعذر تحميل الرسائل: ' + (err.message || 'تحقق من الصلاحيات'));
    } finally {
      setIsLoadingMessages(false);
    }
  }, [token, currentFolder, searchQuery]);

  useEffect(() => {
    if (token) {
      loadProfile();
      loadMessages();
    }
  }, [token, currentFolder, loadProfile, loadMessages]);

  // View message detail
  const handleOpenMessage = async (msgSummary: GmailMessageSummary) => {
    if (!token) return;
    setIsLoadingDetail(true);
    try {
      const detail = await getGmailMessageDetail(msgSummary.id, token);
      setActiveMessage(detail);

      // If unread, mark as read
      if (detail.unread) {
        modifyGmailMessageLabels(detail.id, [], ['UNREAD'], token).catch(() => {});
        setMessages((prev) =>
          prev.map((m) => (m.id === detail.id ? { ...m, unread: false } : m))
        );
      }
    } catch (err: any) {
      console.error('Load detail error:', err);
      showToast('error', 'تعذر قراءة محتوى الرسالة.');
    } finally {
      setIsLoadingDetail(false);
    }
  };

  // Toggle Star
  const handleToggleStar = async (msgId: string, currentStarred: boolean, e: React.MouseEvent) => {
    e.stopPropagation();
    if (!token) return;
    try {
      if (currentStarred) {
        await modifyGmailMessageLabels(msgId, [], ['STARRED'], token);
      } else {
        await modifyGmailMessageLabels(msgId, ['STARRED'], [], token);
      }
      setMessages((prev) =>
        prev.map((m) => (m.id === msgId ? { ...m, starred: !currentStarred } : m))
      );
      if (activeMessage && activeMessage.id === msgId) {
        setActiveMessage({ ...activeMessage, starred: !currentStarred });
      }
    } catch (err) {
      console.warn('Star toggle error:', err);
    }
  };

  // Send Email
  const handleSendEmail = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!token) return;
    if (!composeTo.trim() || !composeSubject.trim()) {
      showToast('error', 'يرجى إدخال البريد الإلكتروني للمستلم والموضوع.');
      return;
    }

    setIsSending(true);
    try {
      await sendGmailEmail(
        {
          to: composeTo.trim(),
          subject: composeSubject.trim(),
          body: composeBody.trim()
        },
        token
      );
      showToast('success', 'تم إرسال البريد الإلكتروني بنجاح!');
      setIsComposeOpen(false);
      setComposeTo('');
      setComposeSubject('');
      setComposeBody('');
      loadMessages();
      loadProfile();
    } catch (err: any) {
      console.error('Send email error:', err);
      showToast('error', 'فشل إرسال البريد: ' + (err.message || ''));
    } finally {
      setIsSending(false);
    }
  };

  // Save as Draft
  const handleSaveDraft = async () => {
    if (!token) return;
    if (!composeSubject.trim() && !composeBody.trim()) {
      showToast('error', 'يرجى كتابة عنوان أو محتوى لحفظ المسودة.');
      return;
    }

    setIsSavingDraft(true);
    try {
      await createGmailDraft(
        {
          to: composeTo.trim(),
          subject: composeSubject.trim() || '(مسودة بدون عنوان)',
          body: composeBody.trim()
        },
        token
      );
      showToast('success', 'تم حفظ المسودة في حساب Gmail بنجاح!');
      setIsComposeOpen(false);
      setComposeTo('');
      setComposeSubject('');
      setComposeBody('');
      if (currentFolder === 'DRAFT') {
        loadMessages();
      }
    } catch (err: any) {
      console.error('Draft save error:', err);
      showToast('error', 'فشل حفظ المسودة: ' + (err.message || ''));
    } finally {
      setIsSavingDraft(false);
    }
  };

  // Trash Message with Explicit User Confirmation Dialog (MANDATORY for mutating/destructive API calls)
  const handleConfirmTrash = async () => {
    if (!token || !trashConfirmId) return;
    setIsTrashing(true);
    try {
      await trashGmailMessage(trashConfirmId, token);
      showToast('success', 'تم نقل الرسالة إلى سلة المهملات في Gmail بنجاح.');
      setMessages((prev) => prev.filter((m) => m.id !== trashConfirmId));
      if (activeMessage && activeMessage.id === trashConfirmId) {
        setActiveMessage(null);
      }
      setTrashConfirmId(null);
      loadProfile();
    } catch (err: any) {
      console.error('Trash error:', err);
      showToast('error', 'فشل حذف الرسالة: ' + (err.message || ''));
    } finally {
      setIsTrashing(false);
    }
  };

  // Reply
  const handleReply = (msg: GmailMessageDetail) => {
    // Extract sender email
    const fromHeader = msg.from;
    const match = fromHeader.match(/<([^>]+)>/) || [null, fromHeader];
    const replyTo = match[1] || fromHeader;

    const replySubject = msg.subject.startsWith('Re:') ? msg.subject : `Re: ${msg.subject}`;
    const quotedBody = `\n\n--- في ${msg.date}، كتب ${msg.from} ---\n> ` + msg.body.replace(/\n/g, '\n> ');

    setComposeTo(replyTo.trim());
    setComposeSubject(replySubject);
    setComposeBody(quotedBody);
    setIsComposeOpen(true);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* View Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6 pb-6 border-b border-zinc-800">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-[#EA4335] to-[#B31412] text-white flex items-center justify-center shadow-lg shadow-[#EA4335]/20">
            <Mail className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-2xl font-black text-white">بريد Gmail</h1>
              <span className="text-[11px] font-bold px-2 py-0.5 rounded-full bg-red-500/10 text-red-400 border border-red-500/20">
                Google Workspace
              </span>
            </div>
            <p className="text-xs text-zinc-400 mt-0.5">
              إدارة وقراءة وإرسال رسائل البريد الإلكتروني عبر حساب Google المعتمد
            </p>
          </div>
        </div>

        {/* User Account / Connection Controls */}
        <div className="flex items-center gap-3">
          {token && gmailProfile ? (
            <div className="flex items-center gap-2.5 bg-[#161616] border border-zinc-800 rounded-2xl px-3.5 py-2">
              <div className="w-7 h-7 rounded-xl bg-red-500/20 text-red-400 flex items-center justify-center text-xs font-bold">
                {gmailProfile.emailAddress.charAt(0).toUpperCase()}
              </div>
              <div className="text-right">
                <div className="text-xs font-bold text-zinc-200 truncate max-w-[160px] dir-ltr">
                  {gmailProfile.emailAddress}
                </div>
                <div className="text-[10px] text-zinc-500">
                  {gmailProfile.messagesTotal} رسالة
                </div>
              </div>
            </div>
          ) : (
            <button
              onClick={handleConnectGmail}
              disabled={isAuthenticating}
              className="px-4 py-2.5 rounded-2xl bg-white hover:bg-zinc-100 text-black text-xs font-bold flex items-center gap-2 transition-all shadow-md active:scale-95 disabled:opacity-50"
            >
              <svg className="w-4 h-4" viewBox="0 0 24 24">
                <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
                <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
                <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z" />
                <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z" />
              </svg>
              <span>{isAuthenticating ? 'جاري الاتصال...' : 'ربط حساب Gmail'}</span>
            </button>
          )}

          {token && (
            <button
              onClick={() => {
                setComposeTo('');
                setComposeSubject('');
                setComposeBody('');
                setIsComposeOpen(true);
              }}
              className="px-4 py-2.5 rounded-2xl bg-[#EA4335] hover:bg-[#D93025] text-white text-xs font-bold flex items-center gap-2 transition-all shadow-md shadow-[#EA4335]/20 active:scale-95"
            >
              <Plus className="w-4 h-4" />
              <span>رسالة جديدة</span>
            </button>
          )}
        </div>
      </div>

      {/* Main Content Area */}
      {!token ? (
        /* Unconnected Welcome Card */
        <div className="bg-[#141414] border border-[#242424] rounded-3xl p-8 sm:p-12 text-center max-w-2xl mx-auto shadow-2xl my-8">
          <div className="w-16 h-16 rounded-3xl bg-red-500/10 border border-red-500/20 text-[#EA4335] flex items-center justify-center mx-auto mb-5 shadow-inner">
            <Mail className="w-8 h-8" />
          </div>
          <h2 className="text-xl sm:text-2xl font-black text-white mb-2">
            الاتصال بخدمة Gmail
          </h2>
          <p className="text-sm text-zinc-400 max-w-md mx-auto mb-6 leading-relaxed">
            يمكنك الوصول إلى صندوق البريد الإلكتروني الخاص بك في Gmail، واستعراض وقراءة الرسائل، وإرسال الرسائل والرد عليها بأمان تام بموافقتك.
          </p>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-3">
            <button
              onClick={handleConnectGmail}
              disabled={isAuthenticating}
              className="w-full sm:w-auto px-6 py-3.5 rounded-2xl bg-white hover:bg-zinc-100 text-black text-sm font-bold flex items-center justify-center gap-3 transition-all shadow-lg active:scale-95 disabled:opacity-50"
            >
              <svg className="w-5 h-5" viewBox="0 0 24 24">
                <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
                <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
                <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z" />
                <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z" />
              </svg>
              <span>{isAuthenticating ? 'جاري فتح نافذة Google...' : 'تسجيل الدخول وربط Gmail'}</span>
            </button>
          </div>

          <div className="mt-8 pt-6 border-t border-zinc-800/80 flex items-center justify-center gap-2 text-zinc-500 text-xs">
            <ShieldCheck className="w-4 h-4 text-emerald-500" />
            <span>اتصال رسمي مشفر ومحمي عبر Google OAuth API</span>
          </div>
        </div>
      ) : (
        /* Connected Mailbox UI */
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          {/* Sidebar Navigation */}
          <div className="lg:col-span-3 space-y-2 bg-[#141414] border border-[#242424] rounded-3xl p-3 shadow-xl">
            <div className="px-3 py-2 text-xs font-bold text-zinc-400">
              المجلدات والتصنيفات
            </div>

            <button
              onClick={() => {
                setCurrentFolder('INBOX');
                setActiveMessage(null);
              }}
              className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-2xl text-xs font-bold transition-all ${
                currentFolder === 'INBOX'
                  ? 'bg-[#EA4335] text-white shadow-md shadow-[#EA4335]/20'
                  : 'text-zinc-300 hover:bg-[#1E1E1E]'
              }`}
            >
              <div className="flex items-center gap-2.5">
                <Inbox className="w-4 h-4" />
                <span>البريد الوارد</span>
              </div>
            </button>

            <button
              onClick={() => {
                setCurrentFolder('STARRED');
                setActiveMessage(null);
              }}
              className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-2xl text-xs font-bold transition-all ${
                currentFolder === 'STARRED'
                  ? 'bg-[#EA4335] text-white shadow-md shadow-[#EA4335]/20'
                  : 'text-zinc-300 hover:bg-[#1E1E1E]'
              }`}
            >
              <div className="flex items-center gap-2.5">
                <Star className="w-4 h-4 text-amber-400" />
                <span>المميزة بنجمة</span>
              </div>
            </button>

            <button
              onClick={() => {
                setCurrentFolder('SENT');
                setActiveMessage(null);
              }}
              className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-2xl text-xs font-bold transition-all ${
                currentFolder === 'SENT'
                  ? 'bg-[#EA4335] text-white shadow-md shadow-[#EA4335]/20'
                  : 'text-zinc-300 hover:bg-[#1E1E1E]'
              }`}
            >
              <div className="flex items-center gap-2.5">
                <Send className="w-4 h-4" />
                <span>الرسائل المرسلة</span>
              </div>
            </button>

            <button
              onClick={() => {
                setCurrentFolder('DRAFT');
                setActiveMessage(null);
              }}
              className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-2xl text-xs font-bold transition-all ${
                currentFolder === 'DRAFT'
                  ? 'bg-[#EA4335] text-white shadow-md shadow-[#EA4335]/20'
                  : 'text-zinc-300 hover:bg-[#1E1E1E]'
              }`}
            >
              <div className="flex items-center gap-2.5">
                <FileText className="w-4 h-4" />
                <span>المسودات</span>
              </div>
            </button>

            <button
              onClick={() => {
                setCurrentFolder('TRASH');
                setActiveMessage(null);
              }}
              className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-2xl text-xs font-bold transition-all ${
                currentFolder === 'TRASH'
                  ? 'bg-[#EA4335] text-white shadow-md shadow-[#EA4335]/20'
                  : 'text-zinc-300 hover:bg-[#1E1E1E]'
              }`}
            >
              <div className="flex items-center gap-2.5">
                <Trash2 className="w-4 h-4" />
                <span>سلة المهملات</span>
              </div>
            </button>
          </div>

          {/* Messages List & Message Reader Container */}
          <div className="lg:col-span-9 bg-[#141414] border border-[#242424] rounded-3xl overflow-hidden shadow-xl min-h-[550px] flex flex-col">
            {/* Top Toolbar */}
            <div className="p-4 border-b border-zinc-800/80 flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 bg-[#111]">
              <div className="relative flex-1">
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') {
                      loadMessages();
                    }
                  }}
                  placeholder="ابحث في رسائل Gmail..."
                  className="w-full bg-[#1A1A1A] border border-zinc-700/70 rounded-2xl pl-10 pr-4 py-2 text-xs text-white placeholder:text-zinc-500 focus:outline-none focus:border-[#EA4335]"
                />
                <Search
                  onClick={() => loadMessages()}
                  className="w-4 h-4 text-zinc-400 absolute left-3.5 top-2.5 cursor-pointer hover:text-white"
                />
              </div>

              <div className="flex items-center gap-2 shrink-0">
                <button
                  onClick={() => {
                    loadMessages();
                    loadProfile();
                  }}
                  disabled={isLoadingMessages}
                  className="p-2.5 rounded-2xl bg-[#1E1E1E] hover:bg-zinc-800 text-zinc-300 hover:text-white transition-colors disabled:opacity-50"
                  title="تحديث الرسائل"
                >
                  <RefreshCw className={`w-4 h-4 ${isLoadingMessages ? 'animate-spin text-red-400' : ''}`} />
                </button>

                {activeMessage && (
                  <button
                    onClick={() => setActiveMessage(null)}
                    className="px-3 py-2 rounded-2xl bg-zinc-800 hover:bg-zinc-700 text-xs font-bold text-zinc-300 flex items-center gap-1.5"
                  >
                    <ChevronRight className="w-4 h-4" />
                    <span>العودة للقائمة</span>
                  </button>
                )}
              </div>
            </div>

            {/* Content Body: Either Reader or List */}
            {isLoadingDetail ? (
              <div className="flex-1 flex flex-col items-center justify-center p-12 text-zinc-400">
                <RefreshCw className="w-8 h-8 animate-spin text-red-500 mb-3" />
                <p className="text-xs">جاري قراءة محتوى الرسالة...</p>
              </div>
            ) : activeMessage ? (
              /* Message Reader View */
              <div className="flex-1 p-6 flex flex-col justify-between">
                <div>
                  {/* Subject and Action buttons */}
                  <div className="flex items-start justify-between gap-4 pb-4 border-b border-zinc-800">
                    <div>
                      <h2 className="text-lg font-bold text-white mb-1 leading-snug">
                        {activeMessage.subject}
                      </h2>
                      <div className="flex items-center gap-2 text-xs text-zinc-400">
                        <span className="font-semibold text-zinc-300">من:</span>
                        <span className="dir-ltr text-right">{activeMessage.from}</span>
                      </div>
                      {activeMessage.to && (
                        <div className="flex items-center gap-2 text-xs text-zinc-500 mt-0.5">
                          <span>إلى:</span>
                          <span className="dir-ltr text-right">{activeMessage.to}</span>
                        </div>
                      )}
                    </div>

                    <div className="flex items-center gap-2 shrink-0">
                      <button
                        onClick={(e) => handleToggleStar(activeMessage.id, activeMessage.starred, e)}
                        className="p-2 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-zinc-300"
                        title={activeMessage.starred ? 'إزالة النجمة' : 'تمييز بنجمة'}
                      >
                        <Star className={`w-4 h-4 ${activeMessage.starred ? 'text-amber-400 fill-amber-400' : ''}`} />
                      </button>

                      <button
                        onClick={() => handleReply(activeMessage)}
                        className="px-3 py-2 rounded-xl bg-[#1E1E1E] hover:bg-zinc-800 text-zinc-200 text-xs font-bold flex items-center gap-1.5"
                      >
                        <Reply className="w-4 h-4" />
                        <span>رد</span>
                      </button>

                      <button
                        onClick={() => setTrashConfirmId(activeMessage.id)}
                        className="p-2 rounded-xl bg-red-950/40 hover:bg-red-900/60 text-red-400 transition-colors"
                        title="حذف الرسالة"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>

                  {/* Date and Details header */}
                  <div className="py-2.5 flex items-center justify-between text-[11px] text-zinc-500 border-b border-zinc-800/60 mb-5">
                    <span className="flex items-center gap-1.5">
                      <Clock className="w-3.5 h-3.5" />
                      {activeMessage.date}
                    </span>
                    <span className="font-mono text-[10px] text-zinc-600">ID: {activeMessage.id}</span>
                  </div>

                  {/* Message Body */}
                  <div className="text-sm text-zinc-200 leading-relaxed font-sans whitespace-pre-wrap select-text bg-[#0E0E0E] p-5 rounded-2xl border border-zinc-800/80 min-h-[220px]">
                    {activeMessage.body}
                  </div>
                </div>

                {/* Bottom Quick Reply Prompt */}
                <div className="mt-6 pt-4 border-t border-zinc-800 flex items-center justify-between">
                  <button
                    onClick={() => handleReply(activeMessage)}
                    className="px-4 py-2 rounded-xl bg-[#EA4335] hover:bg-[#D93025] text-white text-xs font-bold flex items-center gap-2 shadow-sm"
                  >
                    <Reply className="w-4 h-4" />
                    <span>الرد على هذه الرسالة</span>
                  </button>

                  <button
                    onClick={() => setActiveMessage(null)}
                    className="text-xs text-zinc-400 hover:text-white"
                  >
                    إغلاق العرض
                  </button>
                </div>
              </div>
            ) : (
              /* Message List View */
              <div className="flex-1 divide-y divide-zinc-800/60">
                {isLoadingMessages ? (
                  <div className="py-20 flex flex-col items-center justify-center text-zinc-400">
                    <RefreshCw className="w-8 h-8 animate-spin text-red-500 mb-3" />
                    <p className="text-xs">جاري جلب الرسائل من Gmail...</p>
                  </div>
                ) : messages.length === 0 ? (
                  <div className="py-20 text-center text-zinc-500">
                    <Inbox className="w-12 h-12 mx-auto mb-3 opacity-30" />
                    <p className="text-sm font-bold text-zinc-400">لا توجد رسائل في هذا المجلد</p>
                    <p className="text-xs text-zinc-600 mt-1">صندوق البريد نظيف ومحدث</p>
                  </div>
                ) : (
                  messages.map((msg) => (
                    <div
                      key={msg.id}
                      onClick={() => handleOpenMessage(msg)}
                      className={`p-4 flex items-center justify-between gap-4 cursor-pointer transition-colors ${
                        msg.unread
                          ? 'bg-[#181818] hover:bg-[#202020] text-white font-bold'
                          : 'hover:bg-[#171717] text-zinc-300'
                      }`}
                    >
                      <div className="flex items-center gap-3 overflow-hidden">
                        <button
                          onClick={(e) => handleToggleStar(msg.id, msg.starred, e)}
                          className="p-1 text-zinc-500 hover:text-amber-400 shrink-0"
                        >
                          <Star className={`w-4 h-4 ${msg.starred ? 'text-amber-400 fill-amber-400' : ''}`} />
                        </button>

                        <div className="min-w-0">
                          <div className="flex items-center gap-2 mb-0.5">
                            <span className="text-xs font-bold text-zinc-200 truncate max-w-[140px] sm:max-w-[200px]">
                              {msg.from.replace(/<.*>/, '').trim() || msg.from}
                            </span>
                            {msg.unread && (
                              <span className="w-2 h-2 rounded-full bg-red-500 shrink-0" />
                            )}
                          </div>
                          <div className="text-xs text-zinc-300 font-medium truncate">
                            {msg.subject}
                          </div>
                          <div className="text-[11px] text-zinc-500 truncate max-w-md sm:max-w-xl">
                            {msg.snippet}
                          </div>
                        </div>
                      </div>

                      <div className="flex items-center gap-3 shrink-0">
                        <span className="text-[11px] text-zinc-500 hidden sm:inline whitespace-nowrap">
                          {msg.date.split(' ').slice(0, 4).join(' ')}
                        </span>
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            setTrashConfirmId(msg.id);
                          }}
                          className="p-1.5 rounded-lg opacity-40 hover:opacity-100 hover:bg-red-950/50 text-red-400 transition-all"
                          title="حذف"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  ))
                )}
              </div>
            )}
          </div>
        </div>
      )}

      {/* COMPOSE EMAIL MODAL */}
      {isComposeOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
          <div
            className="w-full max-w-xl bg-[#141414] border border-[#282828] text-white rounded-3xl shadow-2xl p-6 relative overflow-hidden"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between pb-4 border-b border-zinc-800 mb-5">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-xl bg-red-500/20 text-red-400 flex items-center justify-center">
                  <Send className="w-4 h-4" />
                </div>
                <h3 className="text-base font-bold text-white">إنشاء رسالة بريد إلكتروني</h3>
              </div>

              <button
                onClick={() => setIsComposeOpen(false)}
                className="p-1.5 rounded-full bg-zinc-800 hover:bg-zinc-700 text-zinc-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSendEmail} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-zinc-400 mb-1">
                  إلى (البريد الإلكتروني):
                </label>
                <input
                  type="email"
                  required
                  value={composeTo}
                  onChange={(e) => setComposeTo(e.target.value)}
                  placeholder="recipient@example.com"
                  className="w-full bg-[#1A1A1A] border border-zinc-700/80 rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-none focus:border-[#EA4335] dir-ltr text-right"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-zinc-400 mb-1">
                  الموضوع:
                </label>
                <input
                  type="text"
                  required
                  value={composeSubject}
                  onChange={(e) => setComposeSubject(e.target.value)}
                  placeholder="موضوع الرسالة..."
                  className="w-full bg-[#1A1A1A] border border-zinc-700/80 rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-none focus:border-[#EA4335]"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-zinc-400 mb-1">
                  نص الرسالة:
                </label>
                <textarea
                  rows={6}
                  value={composeBody}
                  onChange={(e) => setComposeBody(e.target.value)}
                  placeholder="اكتب تفاصيل الرسالة هنا..."
                  className="w-full bg-[#1A1A1A] border border-zinc-700/80 rounded-xl p-3.5 text-xs text-white focus:outline-none focus:border-[#EA4335] resize-none"
                />
              </div>

              <div className="flex items-center justify-between pt-3 border-t border-zinc-800">
                <button
                  type="button"
                  onClick={handleSaveDraft}
                  disabled={isSavingDraft || isSending}
                  className="px-4 py-2 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-zinc-300 text-xs font-bold transition-all disabled:opacity-50 flex items-center gap-1.5"
                >
                  <FileText className="w-3.5 h-3.5" />
                  <span>{isSavingDraft ? 'جاري الحفظ...' : 'حفظ كمسودة'}</span>
                </button>

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => setIsComposeOpen(false)}
                    className="px-4 py-2 rounded-xl text-xs font-bold text-zinc-400 hover:text-white"
                  >
                    إلغاء
                  </button>

                  <button
                    type="submit"
                    disabled={isSending || isSavingDraft}
                    className="px-5 py-2.5 rounded-xl bg-[#EA4335] hover:bg-[#D93025] text-white text-xs font-bold transition-all shadow-md shadow-[#EA4335]/20 disabled:opacity-50 flex items-center gap-2"
                  >
                    <Send className="w-4 h-4" />
                    <span>{isSending ? 'جاري الإرسال...' : 'إرسال البريد'}</span>
                  </button>
                </div>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* DESTRUCTIVE TRASH ACTION CONFIRMATION MODAL (Required by Workspace Integration Policy) */}
      {trashConfirmId && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-150">
          <div
            className="w-full max-w-md bg-[#161616] border border-red-900/40 rounded-3xl p-6 shadow-2xl text-center"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="w-12 h-12 rounded-2xl bg-red-500/10 border border-red-500/20 text-red-400 flex items-center justify-center mx-auto mb-4">
              <AlertTriangle className="w-6 h-6" />
            </div>

            <h3 className="text-base font-bold text-white mb-2">
              تأكيد حذف الرسالة من Gmail
            </h3>

            <p className="text-xs text-zinc-400 mb-6 leading-relaxed">
              هل أنت متأكد من نقل هذه الرسالة إلى سلة المهملات في حساب Gmail الخاص بك؟ يمكنك استعادتها لاحقاً من مجلد المهملات.
            </p>

            <div className="flex items-center justify-center gap-3">
              <button
                type="button"
                onClick={() => setTrashConfirmId(null)}
                className="px-4 py-2.5 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-zinc-300 text-xs font-bold flex-1"
              >
                إلغاء
              </button>

              <button
                type="button"
                onClick={handleConfirmTrash}
                disabled={isTrashing}
                className="px-4 py-2.5 rounded-xl bg-red-600 hover:bg-red-700 text-white text-xs font-bold flex-1 transition-all shadow-md shadow-red-600/20 disabled:opacity-50"
              >
                {isTrashing ? 'جاري الحذف...' : 'تأكيد الحذف'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-6 left-6 z-50 animate-in slide-in-from-bottom-5 fade-in duration-200">
          <div
            className={`px-4 py-3 rounded-2xl border text-xs font-bold flex items-center gap-2.5 shadow-2xl ${
              toastMessage.type === 'success'
                ? 'bg-emerald-950 border-emerald-700 text-emerald-200'
                : 'bg-red-950 border-red-700 text-red-200'
            }`}
          >
            {toastMessage.type === 'success' ? (
              <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0" />
            ) : (
              <AlertTriangle className="w-4 h-4 text-red-400 shrink-0" />
            )}
            <span>{toastMessage.text}</span>
          </div>
        </div>
      )}
    </div>
  );
};
