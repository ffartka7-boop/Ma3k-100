import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import {
  X,
  CheckCircle2,
  Copy,
  Check,
  Upload,
  ArrowRight,
  ShieldCheck,
  AlertCircle,
  ExternalLink,
  PhoneCall,
  Lock
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { getCountryDetails } from '../utils/country';

export const OrderModal: React.FC = () => {
  const {
    activeOrderModal,
    setActiveOrderModal,
    createOrder,
    submitPayment,
    paymentMethods,
    countries,
    getOrderFeeForCountry,
    getOrderExpiryForCountry,
    selectedCountry,
    activeCurrency,
    setCurrentView,
    isPaymentGatewayEnabled
  } = useApp();

  const [step, setStep] = useState<'confirm' | 'pay' | 'success'>('confirm');
  const [createdOrder, setCreatedOrder] = useState<any>(null);
  const [selectedMethodId, setSelectedMethodId] = useState<string>('vodafone_cash');
  const [senderWallet, setSenderWallet] = useState('');
  const [receiptImage, setReceiptImage] = useState<string>('');
  const [copiedNumber, setCopiedNumber] = useState(false);
  const [copiedCoupon, setCopiedCoupon] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  const product = activeOrderModal?.product;
  const productCountryCode = (product?.country_code && product.country_code !== 'ALL')
    ? product.country_code
    : (selectedCountry !== 'ALL' ? selectedCountry : 'EG');

  const countryObj = countries.find(c => c.code === productCountryCode) || {
    code: productCountryCode,
    name_ar: getCountryDetails(productCountryCode).name,
    currency_symbol: getCountryDetails(productCountryCode).currencySymbol,
    currency_name_ar: getCountryDetails(productCountryCode).currencyName,
    order_fee: getOrderFeeForCountry(productCountryCode)
  };

  const currentOrderFee = createdOrder ? createdOrder.order_fee : (isPaymentGatewayEnabled ? getOrderFeeForCountry(productCountryCode) : 0);
  const currentExpiryMinutes = getOrderExpiryForCountry(productCountryCode);
  const currencyName = countryObj.currency_name_ar || countryObj.currency_code || activeCurrency;
  const currencySymbol = countryObj.currency_symbol || 'ج.م';
  const country = {
    code: productCountryCode,
    name: countryObj.name_ar,
    currencySymbol: currencySymbol,
    currencyName: currencyName,
    flag: getCountryDetails(productCountryCode).flag
  };

  const availableMethods = React.useMemo(() => {
    return paymentMethods.filter(
      m => m.is_enabled && (m.country_code === productCountryCode || m.country_code === 'ALL' || !m.country_code)
    );
  }, [paymentMethods, productCountryCode]);

  // Track modal opening / product change to initialize state once
  const modalProductIdRef = React.useRef<string | null>(null);

  React.useEffect(() => {
    if (activeOrderModal && activeOrderModal.product) {
      if (modalProductIdRef.current !== activeOrderModal.product.id) {
        modalProductIdRef.current = activeOrderModal.product.id;
        setStep(activeOrderModal.step || 'confirm');
        setCreatedOrder(activeOrderModal.order || null);
        setSenderWallet('');
        setReceiptImage('');
        setErrorMsg('');
        setIsSubmitting(false);
      }
    } else {
      modalProductIdRef.current = null;
    }
  }, [activeOrderModal]);

  // Set default payment method when available methods load
  React.useEffect(() => {
    if (availableMethods.length > 0 && !availableMethods.some(m => m.id === selectedMethodId)) {
      setSelectedMethodId(availableMethods[0].id);
    }
  }, [availableMethods, selectedMethodId]);

  const selectedMethod = availableMethods.find(m => m.id === selectedMethodId) || availableMethods[0] || null;

  if (!activeOrderModal || !product) return null;

  const handleCopyWalletNumber = () => {
    if (selectedMethod) {
      navigator.clipboard.writeText(selectedMethod.wallet_number);
      setCopiedNumber(true);
      setTimeout(() => setCopiedNumber(false), 2500);
    }
  };

  const handleCopyCoupon = (code: string) => {
    navigator.clipboard.writeText(code);
    setCopiedCoupon(true);
    setTimeout(() => setCopiedCoupon(false), 2500);
  };

  const handleConfirmOrder = async () => {
    try {
      setIsSubmitting(true);
      const newOrder = await createOrder(product);
      setCreatedOrder(newOrder);

      // If payment gateway is disabled by admin, activate directly and go straight to success
      if (!isPaymentGatewayEnabled) {
        setStep('success');
        try {
          confetti({
            particleCount: 90,
            spread: 80,
            origin: { y: 0.6 }
          });
        } catch {}
      } else {
        setStep('pay');
      }
    } catch {
      setErrorMsg('حدث خطأ أثناء إنشاء الطلب، يرجى المحاولة مرة أخرى.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (uploadEvent) => {
        setReceiptImage(uploadEvent.target?.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmitPayment = async () => {
    if (!createdOrder) return;
    if (!senderWallet.trim()) {
      setErrorMsg('يرجى إدخال رقم الهاتف المحول منه.');
      return;
    }
    if (!selectedMethod) {
      setErrorMsg('يرجى اختيار وسيلة دفع مفعلة ومتاحة.');
      return;
    }
    if (!receiptImage) {
      setErrorMsg('يرجى إرفاق صورة إيصال التحويل للمطابقة السريعة.');
      return;
    }

    try {
      setIsSubmitting(true);
      setErrorMsg('');
      const ok = await submitPayment(
        createdOrder.order_id,
        selectedMethod.name,
        senderWallet,
        receiptImage
      );
      if (ok) {
        setStep('success');
        try {
          confetti({
            particleCount: 80,
            spread: 70,
            origin: { y: 0.6 }
          });
        } catch {
          // ignore if canvas not ready
        }
      } else {
        setErrorMsg('تعذر تسجيل بيانات الدفع، يرجى إعادة المحاولة.');
      }
    } catch {
      setErrorMsg('حدث خطأ غير متوقع.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const isFreeDirectMode = !isPaymentGatewayEnabled || createdOrder?.payment_status === 'APPROVED';
  const targetProductUrl = product.affiliate_url || product.original_product_url;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm animate-in fade-in duration-200">
      <div
        className="relative w-full max-w-xl bg-[#161616] border border-[#2A2A2A] rounded-3xl overflow-hidden shadow-2xl max-h-[92vh] flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between p-4 sm:p-5 border-b border-[#2A2A2A]">
          <div className="flex items-center gap-2">
            <span className={`w-2.5 h-2.5 rounded-full ${isFreeDirectMode ? 'bg-emerald-500' : 'bg-[#E50914]'} animate-pulse`} />
            <h3 className="text-base sm:text-lg font-black text-white">
              {step === 'confirm' && (isPaymentGatewayEnabled ? 'تأكيد تفاصيل الطلب' : 'تفعيل رابط الطلب المباشر')}
              {step === 'pay' && 'سداد رسوم الخدمة وتفعيل الرابط'}
              {step === 'success' && (isFreeDirectMode ? 'تم تفعيل الرابط بنجاح! 🎉' : 'تم استلام طلبك بنجاح!')}
            </h3>
          </div>
          <button
            onClick={() => setActiveOrderModal(null)}
            className="p-1.5 rounded-full bg-[#222222] text-zinc-400 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-4 sm:p-6 overflow-y-auto space-y-5">
          {/* STEP 1: CONFIRM */}
          {step === 'confirm' && (
            <>
              {/* Product Preview Card */}
              <div className="flex items-center gap-3.5 sm:gap-4 p-3.5 bg-[#0B0B0B] rounded-2xl border border-zinc-800 shadow-md">
                <div className="w-20 h-20 sm:w-24 sm:h-24 rounded-2xl bg-[#060606] border border-zinc-700/80 p-1.5 flex items-center justify-center shrink-0 overflow-hidden relative shadow-inner">
                  {/* Subtle blurred background */}
                  <div
                    className="absolute inset-0 bg-cover bg-center blur-lg opacity-25 scale-125 pointer-events-none"
                    style={{ backgroundImage: `url(${product.image_url})` }}
                  />
                  <img
                    src={product.image_url}
                    alt={product.name}
                    className="relative z-10 w-full h-full object-contain rounded-xl select-none"
                    referrerPolicy="no-referrer"
                  />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-1.5 mb-1.5 flex-wrap">
                    <span className="px-2 py-0.5 rounded-full bg-zinc-800 text-white text-[10px] font-bold border border-zinc-700 flex items-center gap-1">
                      <span>{country.flag}</span>
                      <span>{country.name}</span>
                    </span>
                    <span className="text-[10px] bg-zinc-800/80 text-zinc-400 px-2 py-0.5 rounded-full font-bold">
                      ميزانية {product.budget} {country.currencySymbol}
                    </span>
                  </div>
                  <h4 className="text-sm font-black text-white line-clamp-2 leading-snug">{product.name}</h4>
                  <p className="text-xs text-emerald-400 font-bold mt-1.5 flex items-center gap-1">
                    <span className="text-zinc-400 font-normal">سعر السلعة:</span>
                    <span>{product.price.toLocaleString('ar-EG')} {country.currencySymbol}</span>
                  </p>
                </div>
              </div>

              {/* Order Cost Breakdown */}
              <div className="p-4 rounded-2xl bg-[#0B0B0B] border border-[#2A2A2A] space-y-2.5 text-xs sm:text-sm">
                <div className="flex justify-between text-zinc-400">
                  <span>سعر المنتج في المتجر الأصلي ({country.name}):</span>
                  <span className="text-white font-bold">{product.price} {country.currencySymbol}</span>
                </div>
                <div className="flex justify-between text-zinc-400">
                  <span>رسوم خدمة المنصة (تفعيل الرابط والكود):</span>
                  {isPaymentGatewayEnabled ? (
                    <span className="text-[#FF3344] font-black">{currentOrderFee} {currencySymbol}</span>
                  ) : (
                    <span className="text-emerald-400 font-black px-2 py-0.5 rounded-full bg-emerald-500/10 border border-emerald-500/30">
                      0 {currencySymbol} (مجاناً 🎁)
                    </span>
                  )}
                </div>
                <div className="pt-2 border-t border-zinc-800 flex justify-between text-sm sm:text-base font-black text-white">
                  <span>المبلغ المطلوب سداده الآن:</span>
                  {isPaymentGatewayEnabled ? (
                    <span className="text-[#E50914]">{currentOrderFee} {currencySymbol}</span>
                  ) : (
                    <span className="text-emerald-400 font-black">0 {currencySymbol} (متاح فوراً)</span>
                  )}
                </div>
              </div>

              {/* Security / Free Note */}
              {isPaymentGatewayEnabled ? (
                <div className="p-3.5 rounded-xl bg-amber-500/10 border border-amber-500/30 text-xs text-amber-300 flex items-start gap-2.5">
                  <AlertCircle className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
                  <p className="leading-relaxed">
                    بمجرد سداد رسوم الخدمة الرمزية ({currentOrderFee} {currencySymbol})، سيتم تفعيل رابط الشراء المباشر فوراً وكوبون الخصم الخاص بك لشراء المنتج بسعره الأصلي من المتجر.
                  </p>
                </div>
              ) : (
                <div className="p-3.5 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-xs text-emerald-300 flex items-start gap-2.5">
                  <ShieldCheck className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
                  <p className="leading-relaxed">
                    تم إلغاء رسوم الخدمة مؤقتاً بأمر الإدارة! يمكنك الآن الضغط على زر التفعيل للحصول على رابط المنتج والكوبون مباشرة بدون أي رسوم.
                  </p>
                </div>
              )}

              {errorMsg && (
                <div className="p-3 rounded-xl bg-red-950/40 border border-red-500/50 text-xs text-red-300">
                  {errorMsg}
                </div>
              )}

              <button
                onClick={handleConfirmOrder}
                disabled={isSubmitting}
                className={`w-full py-3.5 rounded-2xl ${
                  isPaymentGatewayEnabled
                    ? 'bg-[#E50914] hover:bg-[#FF3344] shadow-[#E50914]/25'
                    : 'bg-emerald-600 hover:bg-emerald-500 shadow-emerald-600/30'
                } text-white font-bold text-sm transition-all transform active:scale-98 shadow-lg flex items-center justify-center gap-2 disabled:opacity-50`}
              >
                {isSubmitting ? (
                  <span>جاري معالجة وتفعيل الطلب...</span>
                ) : (
                  <>
                    {isPaymentGatewayEnabled ? (
                      <>
                        <span>متابعة للدفع وسداد {currentOrderFee} {currencySymbol}</span>
                        <ArrowRight className="w-4 h-4 rotate-180" />
                      </>
                    ) : (
                      <>
                        <ExternalLink className="w-4 h-4" />
                        <span>تأكيد الطلب وتفعيل رابط الشراء والكوبون فوراً ⚡</span>
                      </>
                    )}
                  </>
                )}
              </button>
            </>
          )}

          {/* STEP 2: PAYMENT WITH WALLETS */}
          {step === 'pay' && isPaymentGatewayEnabled && (
            <>
              {/* Product Preview Card */}
              <div className="flex items-center gap-3.5 sm:gap-4 p-3 bg-[#0B0B0B] rounded-2xl border border-zinc-800 shadow-md">
                <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-2xl bg-[#060606] border border-zinc-700/80 p-1 flex items-center justify-center shrink-0 overflow-hidden relative shadow-inner">
                  <div
                    className="absolute inset-0 bg-cover bg-center blur-lg opacity-25 scale-125 pointer-events-none"
                    style={{ backgroundImage: `url(${product.image_url})` }}
                  />
                  <img
                    src={product.image_url}
                    alt={product.name}
                    className="relative z-10 w-full h-full object-contain rounded-xl select-none"
                    referrerPolicy="no-referrer"
                  />
                </div>
                <div className="flex-1 min-w-0">
                  <h4 className="text-xs sm:text-sm font-black text-white line-clamp-1 leading-snug">{product.name}</h4>
                  <div className="flex items-center gap-2 mt-1 text-[11px]">
                    <span className="text-zinc-400">سعر السلعة: {product.price} {country.currencySymbol}</span>
                    <span className="text-zinc-600">•</span>
                    <span className="text-[#FF3344] font-bold">الرسوم: {currentOrderFee} {currencySymbol}</span>
                  </div>
                </div>
              </div>

              {/* Payment Methods Selector */}
              <div>
                <label className="text-xs font-bold text-zinc-300 block mb-2">
                  اختر وسيلة الدفع المناسبة:
                </label>
                {availableMethods.length > 0 ? (
                  <div className="grid grid-cols-2 gap-2">
                    {availableMethods.map(method => (
                      <button
                        key={method.id}
                        type="button"
                        onClick={() => setSelectedMethodId(method.id)}
                        className={`p-3 rounded-2xl border text-right transition-all flex flex-col gap-1 ${
                          (selectedMethod?.id === method.id)
                            ? 'bg-[#E50914]/15 border-[#E50914] text-white shadow-lg shadow-[#E50914]/10'
                            : 'bg-[#0B0B0B] border-[#2A2A2A] text-zinc-400 hover:text-white hover:border-zinc-700'
                        }`}
                      >
                        <span className="text-xs font-bold">{method.name}</span>
                        <span className="text-[10px] text-zinc-500 font-mono">{method.wallet_number}</span>
                      </button>
                    ))}
                  </div>
                ) : (
                  <div className="p-4 rounded-2xl bg-amber-500/10 border border-amber-500/20 text-center space-y-1.5 my-2">
                    <p className="text-xs font-bold text-amber-300">لا توجد وسائل دفع مفعلة ومتاحة حالياً لهذه الدولة.</p>
                    <p className="text-[11px] text-zinc-400">يرجى التواصل معنا عبر زر المحادثة لتوفير وسيلة تحويل مباشرة.</p>
                  </div>
                )}
              </div>

              {/* Wallet Info & Copy Card */}
              {selectedMethod && (
                <div className="p-4 rounded-2xl bg-[#0B0B0B] border border-[#2A2A2A] space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-xs text-zinc-400">حول المبلغ المطلوب:</span>
                    <span className="text-base font-black text-[#FF3344]">
                      {currentOrderFee} {currencySymbol}
                    </span>
                  </div>

                  <div className="flex items-center justify-between p-2.5 rounded-xl bg-zinc-900 border border-zinc-800">
                    <div>
                      <span className="text-[10px] text-zinc-500 block">رقم المحفظة المعتمد</span>
                      <span className="text-base font-black text-white font-mono tracking-wider">
                        {selectedMethod.wallet_number}
                      </span>
                    </div>

                    <button
                      onClick={handleCopyWalletNumber}
                      className="px-3 py-1.5 rounded-lg bg-[#E50914] hover:bg-[#FF3344] text-white text-xs font-bold flex items-center gap-1 transition-colors"
                    >
                      {copiedNumber ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                      <span>{copiedNumber ? 'تم النسخ' : 'نسخ الرقم'}</span>
                    </button>
                  </div>

                  <p className="text-[11px] text-zinc-400 leading-relaxed">
                    {selectedMethod.instructions}
                  </p>
                </div>
              )}

              {/* Form inputs for verification */}
              <div className="space-y-3 pt-1">
                <div>
                  <label className="text-xs font-bold text-zinc-300 block mb-1">
                    رقم الهاتف المحول منه:
                  </label>
                  <input
                    type="text"
                    value={senderWallet}
                    onChange={(e) => setSenderWallet(e.target.value)}
                    placeholder="مثال: 01012345678 أو رقم الهاتف"
                    className="w-full bg-[#0B0B0B] text-white text-sm rounded-xl px-3.5 py-2.5 border border-[#2A2A2A] focus:outline-none focus:border-[#E50914]"
                  />
                  <p className="text-[10px] text-zinc-500 mt-1">
                    🕒 يتم تسجيل التاريخ والساعة تلقائياً حسب توقيت الدولة والساعة العالمية (UTC).
                  </p>
                </div>

                {/* Receipt Upload */}
                <div>
                  <label className="text-xs font-bold text-zinc-300 block mb-1">
                    صورة إيصال التحويل (سكرين شوت):
                  </label>
                  <label className="flex flex-col items-center justify-center w-full p-4 border-2 border-dashed border-[#2A2A2A] hover:border-[#E50914] rounded-2xl bg-[#0B0B0B] cursor-pointer transition-colors">
                    {receiptImage ? (
                      <div className="flex items-center gap-3">
                        <img
                          src={receiptImage}
                          alt="Receipt"
                          className="w-14 h-14 object-cover rounded-lg border border-zinc-700"
                        />
                        <div className="text-right">
                          <span className="text-xs font-bold text-emerald-400 block">تم إرفاق الإيصال بنجاح</span>
                          <span className="text-[10px] text-zinc-400">اضغط لتغيير الصورة</span>
                        </div>
                      </div>
                    ) : (
                      <div className="flex flex-col items-center justify-center gap-1.5 text-zinc-400">
                        <Upload className="w-5 h-5 text-[#FF3344]" />
                        <span className="text-xs font-bold text-white">اضغط لاختيار صورة الإيصال</span>
                        <span className="text-[10px] text-zinc-500">PNG, JPG بحد أقصى 5 ميجابايت</span>
                      </div>
                    )}
                    <input
                      type="file"
                      accept="image/*"
                      onChange={handleFileChange}
                      className="hidden"
                    />
                  </label>
                </div>
              </div>

              {errorMsg && (
                <div className="p-3 rounded-xl bg-red-950/40 border border-red-500/50 text-xs text-red-300">
                  {errorMsg}
                </div>
              )}

              <button
                onClick={handleSubmitPayment}
                disabled={isSubmitting}
                className="w-full py-3.5 rounded-2xl bg-[#E50914] hover:bg-[#FF3344] text-white font-bold text-sm transition-all transform active:scale-98 shadow-lg shadow-[#E50914]/25 flex items-center justify-center gap-2 disabled:opacity-50"
              >
                {isSubmitting ? (
                  <span>جاري إرسال الإيصال للمراجعة...</span>
                ) : (
                  <>
                    <CheckCircle2 className="w-4 h-4" />
                    <span>تأكيد التحويل وإرسال الإيصال</span>
                  </>
                )}
              </button>
            </>
          )}

          {/* STEP 3: SUCCESS */}
          {step === 'success' && (
            <div className="text-center py-4 space-y-4">
              <div className="w-16 h-16 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 flex items-center justify-center mx-auto">
                <CheckCircle2 className="w-8 h-8" />
              </div>

              <div>
                <h4 className="text-lg font-black text-white">
                  {isFreeDirectMode ? 'تم تفعيل رابط الشراء بنجاح! 🚀' : 'تم إرسال إيصال الدفع بنجاح!'}
                </h4>
                <p className="text-xs text-zinc-400 mt-1 max-w-sm mx-auto leading-relaxed">
                  {isFreeDirectMode ? (
                    <>
                      طلبك رقم <span className="text-white font-mono font-bold">{createdOrder?.order_id}</span> مفعّل ومباشر، يمكنك فتح رابط المنتج والشراء فوراً.
                    </>
                  ) : (
                    <>
                      طلبك رقم <span className="text-white font-mono font-bold">{createdOrder?.order_id}</span> قيد المراجعة الفورية من قبل الإدارة، وسيتم تفعيل رابط الشراء فور التأكيد.
                    </>
                  )}
                </p>
              </div>

              {/* Direct Store Link Button in Free / Approved Mode */}
              {isFreeDirectMode && targetProductUrl && (
                <div className="p-4 rounded-2xl bg-gradient-to-b from-emerald-950/40 to-[#0B0B0B] border border-emerald-500/40 space-y-3">
                  <a
                    href={targetProductUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-full py-3.5 px-4 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-black text-sm flex items-center justify-center gap-2 shadow-lg shadow-emerald-600/30 transition-all transform active:scale-98"
                  >
                    <span>فتح رابط المنتج في المتجر ({product.store_name || 'المتجر الأصلي'})</span>
                    <ExternalLink className="w-4 h-4" />
                  </a>

                  {product.coupon_code && (
                    <div className="flex items-center justify-between p-2.5 rounded-xl bg-black/60 border border-emerald-500/30">
                      <div className="text-right">
                        <span className="text-[10px] text-zinc-400 block">كوبون الخصم الإضافي:</span>
                        <span className="text-sm font-black text-amber-400 font-mono">{product.coupon_code}</span>
                      </div>
                      <button
                        onClick={() => handleCopyCoupon(product.coupon_code || '')}
                        className="px-3 py-1.5 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-white text-xs font-bold flex items-center gap-1 transition-colors"
                      >
                        {copiedCoupon ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                        <span>{copiedCoupon ? 'تم النسخ' : 'نسخ الكوبون'}</span>
                      </button>
                    </div>
                  )}
                </div>
              )}

              <div className="p-4 rounded-2xl bg-[#0B0B0B] border border-zinc-800 text-xs text-zinc-300 space-y-1.5 text-right">
                <div className="flex justify-between">
                  <span className="text-zinc-500">المنتج:</span>
                  <span className="font-bold text-white">{product.name}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-zinc-500">المبلغ:</span>
                  <span className="font-bold text-emerald-400">
                    {isFreeDirectMode ? '0 ' + currencySymbol + ' (مجاناً)' : currentOrderFee + ' ' + currencySymbol}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-zinc-500">الحالة:</span>
                  <span className={`font-bold ${isFreeDirectMode ? 'text-emerald-400' : 'text-[#FF9800]'}`}>
                    {isFreeDirectMode ? 'مفعّل ومباشر ✅' : 'قيد مراجعة الدفع ⏳'}
                  </span>
                </div>
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  onClick={() => {
                    setActiveOrderModal(null);
                    setCurrentView('orders');
                  }}
                  className="flex-1 py-3 rounded-xl bg-[#E50914] text-white font-bold text-xs hover:bg-[#FF3344] transition-colors"
                >
                  الانتقال لصفحة طلباتي
                </button>
                <button
                  onClick={() => {
                    setActiveOrderModal(null);
                  }}
                  className="px-5 py-3 rounded-xl bg-zinc-800 text-zinc-300 font-bold text-xs hover:text-white transition-colors"
                >
                  إغلاق
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
