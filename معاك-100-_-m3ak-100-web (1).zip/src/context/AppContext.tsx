import React, { createContext, useContext, useState, useEffect, useMemo, ReactNode } from 'react';
import type { Product, Category, Budget, Store, Country, Order, Payment, PaymentMethod, ChatMessage, UserProfile, ModeratorUser, AppView, AppUpdate } from '../types';
import {
  supabase,
  SUPABASE_URL,
  DEFAULT_CATEGORIES,
  DEFAULT_BUDGETS,
  DEFAULT_STORES,
  DEFAULT_COUNTRIES,
  DEFAULT_PAYMENT_METHODS,
  INITIAL_PRODUCTS
} from '../lib/supabase';
import { signInWithGoogleWorkspace, logoutGoogle } from '../lib/googleAuth';
import { validateAndAnalyzeApkFile, sanitizeApkFileName, checkApkUrlHealth } from '../lib/apkValidator';

export const resolvePublicApkUrl = (rawUrl?: string): string => {
  if (!rawUrl || typeof rawUrl !== 'string') return '';
  const trimmed = rawUrl.trim();
  if (!trimmed) return '';

  // If already full http / https URL
  if (trimmed.startsWith('http://') || trimmed.startsWith('https://')) {
    return trimmed;
  }

  // Handle relative paths inside 'app-apks' bucket
  let cleanPath = trimmed.replace(/^\/+/, '');
  if (cleanPath.startsWith('storage/v1/object/public/app-apks/')) {
    cleanPath = cleanPath.replace('storage/v1/object/public/app-apks/', '');
  } else if (cleanPath.startsWith('app-apks/')) {
    cleanPath = cleanPath.replace('app-apks/', '');
  }

  // Properly encode path segments while preserving slashes
  const encodedSegments = cleanPath
    .split('/')
    .map(seg => encodeURIComponent(decodeURIComponent(seg)))
    .join('/');

  return `${SUPABASE_URL}/storage/v1/object/public/app-apks/${encodedSegments}`;
};

/**
 * Triggers Android Package Installer / browser download cleanly.
 * Android browsers handle APK downloads natively by showing a system notification
 * with "Download complete - Tap to install".
 */
export const triggerDirectApkInstall = (rawUrl?: string, fileName?: string) => {
  if (!rawUrl) return;
  const finalUrl = resolvePublicApkUrl(rawUrl);
  if (!finalUrl) return;

  const cleanName = fileName || 'm3ak100.apk';
  const link = document.createElement('a');
  link.href = finalUrl;
  link.setAttribute('download', cleanName);
  link.setAttribute('target', '_blank');
  link.rel = 'noopener noreferrer';
  document.body.appendChild(link);
  link.click();
  setTimeout(() => {
    if (document.body.contains(link)) document.body.removeChild(link);
  }, 1200);
};

export const openDownloadedApkFile = (fileName?: string) => {
  // Graceful no-op: Web browsers in Android sandbox cannot directly access local filesystem.
  // The guidance notice directs the user directly to tap their notification or open Downloads.
};

const areValuesEqual = (a: any, b: any): boolean => {
  if (a === b) return true;
  if (!a || !b) return false;
  return JSON.stringify(a) === JSON.stringify(b);
};

interface AppContextType {
  // Navigation & Views
  currentView: AppView;
  setCurrentView: (view: AppView) => void;

  // Data
  products: Product[];
  categories: Category[];
  budgets: Budget[];
  stores: Store[];
  countries: Country[];
  activeCountries: Country[];
  paymentMethods: PaymentMethod[];
  orders: Order[];
  payments: Payment[];
  chatMessages: ChatMessage[];
  favorites: string[];
  appUpdates: AppUpdate[];

  // User & Auth
  currentUser: UserProfile | null;
  isAdmin: boolean;
  signInWithGoogleReal: () => Promise<void>;
  loginWithGoogle: (email?: string, name?: string) => Promise<void>;
  logout: () => void;
  setGuestUser: () => void;

  // Filters & State
  selectedBudget: number | null;
  setSelectedBudget: (budget: number | null) => void;
  selectedCategory: string | null;
  setSelectedCategory: (catId: string | null) => void;
  selectedStore: string | null;
  setSelectedStore: (store: string | null) => void;
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  selectedCountry: string;
  setSelectedCountry: (code: string) => void;
  activeCurrency: string;
  activeCurrencySymbol: string;
  orderFee: number;
  orderExpiryMinutes: number;
  getOrderFeeForCountry: (countryCode?: string) => number;
  getOrderExpiryForCountry: (countryCode?: string) => number;
  // Settings Key-Value Map & Payment Gateway
  settingsMap: Record<string, string>;
  isPaymentGatewayEnabled: boolean;
  adminTogglePaymentGateway: (enabled: boolean) => Promise<void>;

  // Owner & Moderators
  isOwner: boolean;
  moderators: ModeratorUser[];
  adminAddModerator: (email: string, name?: string) => Promise<{ success: boolean; error?: string }>;
  adminRemoveModerator: (email: string) => Promise<{ success: boolean; error?: string }>;
  OWNER_EMAIL: string;

  // Actions
  toggleFavorite: (productId: string) => void;
  createOrder: (product: Product) => Promise<Order>;
  deleteOrder: (orderId: string) => Promise<void>;
  submitPayment: (orderId: string, method: string, senderWallet: string, txnId: string, receiptImage: string) => Promise<boolean>;
  deletePayment: (paymentId: string) => Promise<void>;
  sendChatMessage: (text: string, orderId?: string) => Promise<void>;

  // Admin Actions
  adminApprovePayment: (paymentId: string, orderId: string) => Promise<void>;
  adminRejectPayment: (paymentId: string, orderId: string, reason: string) => Promise<void>;
  adminUpsertProduct: (product: Product) => Promise<void>;
  adminDeleteProduct: (productId: string) => Promise<void>;
  adminToggleFeatured: (productId: string) => Promise<void>;
  adminUpsertPaymentMethod: (method: PaymentMethod) => Promise<void>;
  adminDeletePaymentMethod: (methodId: string) => Promise<void>;
  adminTogglePaymentMethodActive: (methodId: string) => Promise<void>;
  adminSeedPaymentMethodsToSupabase: () => Promise<{ success: boolean; count?: number; error?: string }>;
  adminSyncPaymentMethodsToSupabase: () => Promise<{ success: boolean; count?: number; error?: string }>;
  adminResetDefaultPaymentMethods: () => Promise<{ success: boolean; count?: number; error?: string }>;
  isLiveSyncConnected: boolean;
  lastLiveEvent: { table: string; type: string; timestamp: number } | null;
  adminToggleCountryActive: (countryCode: string) => Promise<void>;
  adminUpsertCountry: (country: Country) => Promise<void>;
  adminDeleteCountry: (countryCode: string) => Promise<void>;
  adminUpdateSettings: (newFee: number, newExpiry: number, currency: string) => Promise<void>;
  adminUpdateCountrySettings: (countryCode: string, newFee: number, newExpiry: number, currency?: string, currencySymbol?: string) => Promise<void>;
  adminUploadApk: (file: File, versionName: string, versionCode: number, title: string, description: string, isActive?: boolean) => Promise<{ success: boolean; error?: string; update?: AppUpdate }>;
  adminPublishCustomApkUrl: (apkUrl: string, versionName: string, versionCode: number, title: string, description: string, isActive?: boolean, fileSizeMb?: number) => Promise<{ success: boolean; error?: string; update?: AppUpdate }>;
  adminToggleAppUpdateActive: (updateId: string) => Promise<void>;
  adminDeleteAppUpdate: (updateId: string) => Promise<void>;
  adminSeedCountriesToSupabase: () => Promise<{ success: boolean; count?: number; error?: string }>;
  syncWithSupabase: () => Promise<void>;
  getLatestActiveAppUpdate: () => Promise<AppUpdate | null>;
  downloadLatestApk: () => Promise<{ success: boolean; update?: AppUpdate; error?: string }>;
  latestActiveAppUpdate: AppUpdate | null;

  // Modals
  isAuthModalOpen: boolean;
  setIsAuthModalOpen: (open: boolean) => void;
  isDownloadModalOpen: boolean;
  setIsDownloadModalOpen: (open: boolean) => void;
  activeProductModal: Product | null;
  setActiveProductModal: (prod: Product | null) => void;
  activeOrderModal: { product: Product; order?: Order; step?: 'confirm' | 'pay' | 'success' } | null;
  setActiveOrderModal: (val: { product: Product; order?: Order; step?: 'confirm' | 'pay' | 'success' } | null) => void;
  isChatModalOpen: boolean;
  setIsChatModalOpen: (open: boolean) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

const STORAGE_KEYS = {
  USER: 'm3ak_user',
  FAVORITES: 'm3ak_favorites',
  PRODUCTS: 'm3ak_local_products',
  ORDERS: 'm3ak_local_orders',
  PAYMENTS: 'm3ak_local_payments',
  COUNTRY: 'm3ak_selected_country',
  COUNTRIES: 'm3ak_countries',
  PAYMENT_METHODS: 'm3ak_payment_methods',
  CHAT: 'm3ak_chat_messages',
  SETTINGS: 'm3ak_settings',
  APP_UPDATES: 'm3ak_app_updates',
  MODERATORS: 'm3ak_authorized_moderators'
};

export const OWNER_EMAILS = [
  'mohmdfartka00@gmail.com',
  'mohamedfartka00@gmail.com'
];
export const OWNER_EMAIL = 'mohmdfartka00@gmail.com';
export const OWNER_UUID = '279326f5-560f-3df1-b1e7-2b36e52c8038';

export const isOwnerEmail = (email?: string): boolean => {
  if (!email) return false;
  const clean = email.trim().toLowerCase();
  return OWNER_EMAILS.some(o => o.toLowerCase() === clean);
};

export const AppProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  // Views
  const [currentView, setCurrentView] = useState<'home' | 'products' | 'favorites' | 'orders' | 'about' | 'admin'>('home');

  // Core Data
  const [products, setProducts] = useState<Product[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.PRODUCTS);
    if (saved) {
      try {
        const parsed: Product[] = JSON.parse(saved);
        // Ensure SA and AE products are present from INITIAL_PRODUCTS
        const hasSa = parsed.some((p) => p.country_code === 'SA');
        const hasAe = parsed.some((p) => p.country_code === 'AE');
        if (!hasSa || !hasAe) {
          const missing = INITIAL_PRODUCTS.filter((ip) => !parsed.some((p) => p.id === ip.id));
          const merged = [...parsed, ...missing];
          localStorage.setItem(STORAGE_KEYS.PRODUCTS, JSON.stringify(merged));
          return merged;
        }
        return parsed;
      } catch {
        return INITIAL_PRODUCTS;
      }
    }
    return INITIAL_PRODUCTS;
  });
  const [categories] = useState<Category[]>(DEFAULT_CATEGORIES);
  const [budgets] = useState<Budget[]>(DEFAULT_BUDGETS);
  const [stores] = useState<Store[]>(DEFAULT_STORES);
  const [countries, setCountries] = useState<Country[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.COUNTRIES);
    if (saved) {
      try {
        const parsed: Country[] = JSON.parse(saved);
        // Exclude legacy 'ALL' completely
        const filtered = parsed.filter((c) => c.code !== 'ALL');
        // Ensure all default countries are present
        const missing = DEFAULT_COUNTRIES.filter((dc) => !filtered.some((f) => f.code === dc.code));
        const merged = [...filtered, ...missing];
        return merged;
      } catch {
        return DEFAULT_COUNTRIES;
      }
    }
    return DEFAULT_COUNTRIES;
  });
  const [paymentMethods, setPaymentMethods] = useState<PaymentMethod[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.PAYMENT_METHODS);
    if (saved) {
      try {
        const parsed: PaymentMethod[] = JSON.parse(saved);
        if (Array.isArray(parsed)) {
          return parsed;
        }
      } catch {
        return DEFAULT_PAYMENT_METHODS;
      }
    }
    return DEFAULT_PAYMENT_METHODS;
  });

  const [orders, setOrders] = useState<Order[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.ORDERS);
    return saved ? JSON.parse(saved) : [];
  });

  const [payments, setPayments] = useState<Payment[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.PAYMENTS);
    return saved ? JSON.parse(saved) : [];
  });

  const [favorites, setFavorites] = useState<string[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.FAVORITES);
    return saved ? JSON.parse(saved) : [];
  });

  const [chatMessages, setChatMessages] = useState<ChatMessage[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.CHAT);
    return saved ? JSON.parse(saved) : [
      {
        message_id: 'welcome_msg',
        conversation_id: 'support',
        sender_id: 'admin',
        sender_name: 'خدمة العملاء (معاك 100) 🛡️',
        sender_role: 'ADMIN',
        message_text: 'أهلاً بك في منصة معاك 100! كيف يمكننا مساعدتك اليوم؟',
        timestamp: Date.now() - 3600000,
        is_read: true
      }
    ];
  });

  const [appUpdates, setAppUpdates] = useState<AppUpdate[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.APP_UPDATES);
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) {
          const filtered = parsed
            .filter((u: any) => u && u.apk_url && !u.apk_url.includes('github.com'))
            .map((u: any) => ({
              ...u,
              apk_url: resolvePublicApkUrl(u.apk_url)
            }));
          if (filtered.length > 0) return filtered;
        }
      } catch {}
    }
    return [];
  });

  // User
  const [currentUser, setCurrentUser] = useState<UserProfile | null>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.USER);
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch {
        return null;
      }
    }
    // Default guest user
    return {
      id: 'guest_' + Math.random().toString(36).substring(2, 9),
      name: 'زائر معاك 100',
      email: 'guest@m3ak100.com',
      is_admin: false,
      role: 'guest',
      created_at: Date.now()
    };
  });

  // Filters
  const [selectedBudget, setSelectedBudget] = useState<number | null>(null);
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [selectedStore, setSelectedStore] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedCountry, setSelectedCountryState] = useState<string>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.COUNTRY);
    if (!saved || saved === 'ALL') {
      return 'EG';
    }
    return saved;
  });

  // Settings Key-Value Map from Supabase
  const [settingsMap, setSettingsMap] = useState<Record<string, string>>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.SETTINGS);
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch {
        return {};
      }
    }
    return {};
  });

  // Payment Gateway Toggle: Enabled by default, can be toggled by Owner/Admin
  const [isPaymentGatewayEnabled, setIsPaymentGatewayEnabled] = useState<boolean>(() => {
    const saved = localStorage.getItem('m3ak_payment_gateway_enabled');
    if (saved !== null) return saved === 'true';
    return true;
  });

  // Authorized Moderators List (Saved in Supabase settings as 'authorized_moderators' & localStorage)
  const [moderators, setModerators] = useState<ModeratorUser[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.MODERATORS);
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed)) return parsed;
      } catch {
        return [];
      }
    }
    return [];
  });

  // Helper functions for per-country fees and expiry
  const getOrderFeeForCountry = (countryCode?: string): number => {
    // If payment gateway is disabled, all order fees are waived (0)
    if (!isPaymentGatewayEnabled) {
      return 0;
    }

    const rawCode = (countryCode || selectedCountry || 'EG').trim().toUpperCase();
    const code = rawCode === 'ALL' ? 'EG' : rawCode;

    // 1. Per-country setting in settings table: orderFee_EG, orderFee_SA, etc.
    const perCountryKey = `orderFee_${code}`;
    if (settingsMap[perCountryKey] !== undefined && settingsMap[perCountryKey] !== '') {
      const val = parseFloat(settingsMap[perCountryKey]);
      if (!isNaN(val) && val >= 0) return val;
    }

    // 2. Fallback to global orderFee in settings
    if (settingsMap['orderFee'] !== undefined && settingsMap['orderFee'] !== '') {
      const val = parseFloat(settingsMap['orderFee']);
      if (!isNaN(val) && val >= 0) return val;
    }

    // 3. Fallback to country default
    const countryObj = countries.find(c => c.code === code);
    if (countryObj?.order_fee !== undefined && countryObj.order_fee >= 0) {
      return countryObj.order_fee;
    }

    return 10;
  };

  const getOrderExpiryForCountry = (countryCode?: string): number => {
    const rawCode = (countryCode || selectedCountry || 'EG').trim().toUpperCase();
    const code = rawCode === 'ALL' ? 'EG' : rawCode;

    // 1. Per-country setting in settings table: orderExpiryMinutes_EG, orderExpiryMinutes_SA, etc.
    const perCountryKey = `orderExpiryMinutes_${code}`;
    if (settingsMap[perCountryKey] !== undefined && settingsMap[perCountryKey] !== '') {
      const val = parseInt(settingsMap[perCountryKey], 10);
      if (!isNaN(val) && val > 0) return val;
    }

    // 2. Fallback to global orderExpiryMinutes in settings
    if (settingsMap['orderExpiryMinutes'] !== undefined && settingsMap['orderExpiryMinutes'] !== '') {
      const val = parseInt(settingsMap['orderExpiryMinutes'], 10);
      if (!isNaN(val) && val > 0) return val;
    }

    return 30;
  };

  // Derived initial country metadata
  const initialCountryObj = countries.find((c) => c.code === selectedCountry) || countries[0] || DEFAULT_COUNTRIES[0];
  const [orderFee, setOrderFee] = useState<number>(() => getOrderFeeForCountry(selectedCountry));
  const [orderExpiryMinutes, setOrderExpiryMinutes] = useState<number>(() => getOrderExpiryForCountry(selectedCountry));
  const [activeCurrency, setActiveCurrency] = useState<string>(initialCountryObj?.currency_name_ar || initialCountryObj?.currency_code || 'جنيه');
  const [activeCurrencySymbol, setActiveCurrencySymbol] = useState<string>(initialCountryObj?.currency_symbol || 'ج.م');

  // Modals
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [isDownloadModalOpen, setIsDownloadModalOpen] = useState(false);
  const [activeProductModal, setActiveProductModal] = useState<Product | null>(null);
  const [activeOrderModal, setActiveOrderModal] = useState<{ product: Product; order?: Order; step?: 'confirm' | 'pay' | 'success' } | null>(null);
  const [isChatModalOpen, setIsChatModalOpen] = useState(false);
  const [isLiveSyncConnected, setIsLiveSyncConnected] = useState(true);
  const [lastLiveEvent, setLastLiveEvent] = useState<{ table: string; type: string; timestamp: number } | null>(null);

  // Latest active app update memo (filtering out any non-official or github URLs)
  const latestActiveAppUpdate = useMemo(() => {
    const activeList = appUpdates.filter(u => u.is_active && !u.apk_url?.includes('github.com'));
    if (activeList.length === 0) {
      const anyValid = appUpdates.filter(u => !u.apk_url?.includes('github.com'));
      if (anyValid.length === 0) return null;
      return [...anyValid].sort((a, b) => (b.created_at || 0) - (a.created_at || 0))[0];
    }
    return [...activeList].sort((a, b) => (b.created_at || 0) - (a.created_at || 0))[0];
  }, [appUpdates]);

  const getLatestActiveAppUpdate = async (): Promise<AppUpdate | null> => {
    // 1. Try querying Supabase 'app_updates' table
    try {
      let { data, error } = await supabase
        .from('app_updates')
        .select('*')
        .eq('is_active', true)
        .order('created_at', { ascending: false })
        .limit(1);

      if (error || !data || data.length === 0) {
        const { data: allData, error: allError } = await supabase
          .from('app_updates')
          .select('*')
          .order('created_at', { ascending: false })
          .limit(1);
        if (!allError && allData && allData.length > 0) {
          data = allData;
        }
      }

      if (data && data.length > 0) {
        const row = data[0] as AppUpdate;
        if (!row.apk_url?.includes('github.com')) {
          const latest: AppUpdate = {
            ...row,
            apk_url: resolvePublicApkUrl(row.apk_url)
          };

          setAppUpdates(prev => {
            const filtered = prev.filter(u => u.id !== latest.id && !u.apk_url?.includes('github.com'));
            const next = [latest, ...filtered];
            localStorage.setItem(STORAGE_KEYS.APP_UPDATES, JSON.stringify(next));
            return next;
          });
          return latest;
        }
      }
    } catch (err) {
      console.warn('Supabase getLatestActiveAppUpdate query notice:', err);
    }

    // 2. Real-time fallback: check Supabase 'settings' table for key 'latest_active_app_update'
    try {
      const { data: settData } = await supabase
        .from('settings')
        .select('value')
        .eq('key', 'latest_active_app_update')
        .single();

      if (settData?.value) {
        const parsed = JSON.parse(settData.value) as AppUpdate;
        if (parsed && parsed.apk_url && !parsed.apk_url.includes('github.com')) {
          const latest: AppUpdate = {
            ...parsed,
            apk_url: resolvePublicApkUrl(parsed.apk_url)
          };
          setAppUpdates(prev => {
            const filtered = prev.filter(u => u.id !== latest.id && !u.apk_url?.includes('github.com'));
            const next = [latest, ...filtered];
            localStorage.setItem(STORAGE_KEYS.APP_UPDATES, JSON.stringify(next));
            return next;
          });
          return latest;
        }
      }
    } catch {}

    // 3. Fallback: check locally cached active update
    const localActive = appUpdates.find(u => u.is_active && !u.apk_url?.includes('github.com'));
    if (localActive) {
      return {
        ...localActive,
        apk_url: resolvePublicApkUrl(localActive.apk_url)
      };
    }

    return null;
  };

  const downloadLatestApk = async (): Promise<{ success: boolean; update?: AppUpdate; error?: string }> => {
    try {
      const update = await getLatestActiveAppUpdate();
      if (!update || !update.apk_url) {
        return {
          success: false,
          error: 'لا يوجد إصدار منشور ومتاح للتحميل حالياً. يرجى إضافة ونشر إصدار APK من لوحة التحكم.'
        };
      }

      if (update.apk_url.includes('github.com/mohmdfartka00/m3ak100')) {
        return {
          success: false,
          error: 'رابط التحديث غير متوفر. يرجى رفع ملف APK جديد من لوحة التحكم.'
        };
      }

      const finalUrl = resolvePublicApkUrl(update.apk_url);
      if (!finalUrl || !finalUrl.startsWith('http')) {
        return {
          success: false,
          error: 'رابط تحميل ملف الـ APK غير صالح.'
        };
      }

      const cleanVer = (update.version_name || 'latest').replace(/[^a-zA-Z0-9._-]/g, '_');
      const downloadFileName = `m3ak100_v${cleanVer}.apk`;

      // Direct instant native browser download (single download, fast, stable, 0% freeze)
      const link = document.createElement('a');
      link.href = finalUrl;
      link.setAttribute('download', downloadFileName);
      link.setAttribute('target', '_blank');
      link.rel = 'noopener noreferrer';
      document.body.appendChild(link);
      link.click();
      setTimeout(() => {
        if (document.body.contains(link)) document.body.removeChild(link);
      }, 1000);

      return { success: true, update };
    } catch (e: any) {
      console.error('Error downloading APK:', e);
      return { success: false, error: e?.message || 'تعذر بدء تحميل ملف التطبيق' };
    }
  };

  const activeCountries = countries.filter((c) => c.is_active);

  const setSelectedCountry = (code: string) => {
    const cleanCode = (!code || code === 'ALL') ? 'EG' : code;
    const target = countries.find((c) => c.code === cleanCode) || activeCountries[0] || countries[0] || DEFAULT_COUNTRIES[0];
    setSelectedCountryState(target.code);
    localStorage.setItem(STORAGE_KEYS.COUNTRY, target.code);
    setActiveCurrency(target.currency_name_ar || target.currency_code);
    setActiveCurrencySymbol(target.currency_symbol);

    // Update order fee and order expiry minutes instantly based on per-country settings
    const countryFee = getOrderFeeForCountry(target.code);
    const countryExpiry = getOrderExpiryForCountry(target.code);
    setOrderFee(countryFee);
    setOrderExpiryMinutes(countryExpiry);
  };

  const isOwner = Boolean(
    currentUser?.email && isOwnerEmail(currentUser.email)
  );

  const isModerator = Boolean(
    currentUser?.email && !isOwner && (
      currentUser.role === 'moderator' ||
      moderators.some(m => m.email.trim().toLowerCase() === currentUser.email?.trim().toLowerCase())
    )
  );

  const isAdmin = isOwner || isModerator;

  // Sync to localStorage
  useEffect(() => {
    if (currentUser) {
      localStorage.setItem(STORAGE_KEYS.USER, JSON.stringify(currentUser));
    } else {
      localStorage.removeItem(STORAGE_KEYS.USER);
    }
  }, [currentUser]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.MODERATORS, JSON.stringify(moderators));
  }, [moderators]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.FAVORITES, JSON.stringify(favorites));
  }, [favorites]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.ORDERS, JSON.stringify(orders));
  }, [orders]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.PAYMENTS, JSON.stringify(payments));
  }, [payments]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.PRODUCTS, JSON.stringify(products));
  }, [products]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.PAYMENT_METHODS, JSON.stringify(paymentMethods));
  }, [paymentMethods]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.CHAT, JSON.stringify(chatMessages));
  }, [chatMessages]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.COUNTRIES, JSON.stringify(countries));
  }, [countries]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.APP_UPDATES, JSON.stringify(appUpdates));
  }, [appUpdates]);

  // Initial fetch from Supabase
  const syncWithSupabase = async () => {
    try {
      // 1. Products
      const { data: prods, error: pErr } = await supabase.from('products').select('*');
      if (!pErr && prods && prods.length > 0) {
        setProducts(prev => {
          if (areValuesEqual(prev, prods)) return prev;
          localStorage.setItem(STORAGE_KEYS.PRODUCTS, JSON.stringify(prods));
          return prods;
        });
      }

      // 2. Payment Methods
      const { data: methods, error: mErr } = await supabase.from('payment_methods').select('*').order('display_order', { ascending: true });
      if (!mErr && methods && methods.length > 0) {
        setPaymentMethods(prev => {
          if (areValuesEqual(prev, methods)) return prev;
          localStorage.setItem(STORAGE_KEYS.PAYMENT_METHODS, JSON.stringify(methods));
          return methods;
        });
      }

      // 3. Orders (Always fetch all if admin, or user-specific)
      let query = supabase.from('orders').select('*').order('created_at', { ascending: false });
      if (!isAdmin && currentUser) {
        query = query.eq('user_id', currentUser.id);
      }
      const { data: ords, error: oErr } = await query;
      if (!oErr && ords) {
        setOrders(prev => {
          if (areValuesEqual(prev, ords)) return prev;
          localStorage.setItem(STORAGE_KEYS.ORDERS, JSON.stringify(ords));
          return ords;
        });
      }

      // 4. Payments (Always fetch all if admin, or user-specific)
      let pQuery = supabase.from('payments').select('*').order('created_at', { ascending: false });
      if (!isAdmin && currentUser) {
        pQuery = pQuery.eq('user_id', currentUser.id);
      }
      const { data: pays, error: payErr } = await pQuery;
      if (!payErr && pays) {
        setPayments(prev => {
          if (areValuesEqual(prev, pays)) return prev;
          localStorage.setItem(STORAGE_KEYS.PAYMENTS, JSON.stringify(pays));
          return pays;
        });
      }

      // 5. App Updates
      try {
        const { data: updates, error: uErr } = await supabase
          .from('app_updates')
          .select('*')
          .order('created_at', { ascending: false });
        if (!uErr && updates && updates.length > 0) {
          const sanitized = updates
            .filter((u: any) => u && u.apk_url && !u.apk_url.includes('github.com'))
            .map((u: any) => ({
              ...u,
              apk_url: resolvePublicApkUrl(u.apk_url)
            }));
          if (sanitized.length > 0) {
            setAppUpdates(prev => {
              if (areValuesEqual(prev, sanitized)) return prev;
              localStorage.setItem(STORAGE_KEYS.APP_UPDATES, JSON.stringify(sanitized));
              return sanitized;
            });
          }
        } else {
          // Real-time fallback from settings table
          const { data: settData } = await supabase
            .from('settings')
            .select('value')
            .eq('key', 'latest_active_app_update')
            .single();
          if (settData?.value) {
            try {
              const parsed = JSON.parse(settData.value) as AppUpdate;
              if (parsed && parsed.apk_url && !parsed.apk_url.includes('github.com')) {
                const item: AppUpdate = {
                  ...parsed,
                  apk_url: resolvePublicApkUrl(parsed.apk_url)
                };
                setAppUpdates(prev => {
                  if (prev.length === 1 && prev[0].id === item.id && prev[0].apk_url === item.apk_url && prev[0].version_code === item.version_code) {
                    return prev;
                  }
                  localStorage.setItem(STORAGE_KEYS.APP_UPDATES, JSON.stringify([item]));
                  return [item];
                });
              }
            } catch {}
          }
        }
      } catch (err) {
        console.warn('Supabase app_updates sync note:', err);
      }

      // 6. Countries Sync
      try {
        const { data: dbCountries, error: cErr } = await supabase
          .from('countries')
          .select('*');
        if (!cErr && dbCountries && dbCountries.length > 0) {
          setCountries(prev => {
            if (areValuesEqual(prev, dbCountries)) return prev;
            localStorage.setItem(STORAGE_KEYS.COUNTRIES, JSON.stringify(dbCountries));
            return dbCountries;
          });
        }
      } catch (err) {
        console.warn('Supabase countries sync note:', err);
      }

      // 7. Settings
      const { data: setts } = await supabase.from('settings').select('*');
      if (setts) {
        const map: Record<string, string> = {};
        setts.forEach((s: { key: string; value: string }) => {
          map[s.key] = s.value;
        });
        setSettingsMap(prev => {
          let hasDiff = false;
          for (const k of Object.keys(map)) {
            if (prev[k] !== map[k]) {
              hasDiff = true;
              break;
            }
          }
          if (!hasDiff) return prev;
          const next = { ...prev, ...map };
          localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(next));
          return next;
        });

        const currentTargetCode = (!selectedCountry || selectedCountry === 'ALL') ? 'EG' : selectedCountry;
        const fee = map[`orderFee_${currentTargetCode}`] !== undefined && map[`orderFee_${currentTargetCode}`] !== ''
          ? parseFloat(map[`orderFee_${currentTargetCode}`])
          : (map['orderFee'] !== undefined && map['orderFee'] !== '' ? parseFloat(map['orderFee']) : 10);
        const exp = map[`orderExpiryMinutes_${currentTargetCode}`] !== undefined && map[`orderExpiryMinutes_${currentTargetCode}`] !== ''
          ? parseInt(map[`orderExpiryMinutes_${currentTargetCode}`], 10)
          : (map['orderExpiryMinutes'] !== undefined && map['orderExpiryMinutes'] !== '' ? parseInt(map['orderExpiryMinutes'], 10) : 30);

        // Sync Payment Gateway Enabled State
        const isGwEnabled = map['payment_gateway_enabled'] !== undefined ? map['payment_gateway_enabled'] !== 'false' : true;
        setIsPaymentGatewayEnabled(isGwEnabled);
        localStorage.setItem('m3ak_payment_gateway_enabled', isGwEnabled ? 'true' : 'false');

        // Sync Authorized Moderators
        if (map['authorized_moderators'] !== undefined) {
          try {
            const parsedMods = JSON.parse(map['authorized_moderators']);
            if (Array.isArray(parsedMods)) {
              setModerators(parsedMods);
              localStorage.setItem(STORAGE_KEYS.MODERATORS, JSON.stringify(parsedMods));
            }
          } catch (e) {}
        }

        if (!isGwEnabled) {
          setOrderFee(0);
        } else if (!isNaN(fee) && fee >= 0) {
          setOrderFee(fee);
        }
        if (!isNaN(exp) && exp > 0) setOrderExpiryMinutes(exp);
        if (map['currency']) setActiveCurrency(map['currency']);
      }
    } catch (e) {
      console.warn('Supabase initial fetch notice (using local storage fallback):', e);
    }
  };

  useEffect(() => {
    syncWithSupabase();

    // Auto-sync polling fallback every 5 seconds (with value equality checking to eliminate redundant renders)
    const pollInterval = setInterval(() => {
      syncWithSupabase();
    }, 5000);

    // Subscribe to Realtime live updates from Supabase (instant sync between Web & Mobile App)
    const channel = supabase
      .channel('m3ak100-live-sync')
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'products' },
        (payload) => {
          setLastLiveEvent({ table: 'products', type: payload.eventType, timestamp: Date.now() });
          if (payload.eventType === 'INSERT') {
            setProducts(prev => {
              if (prev.some(p => p.id === (payload.new as Product).id)) return prev;
              return [payload.new as Product, ...prev];
            });
          } else if (payload.eventType === 'UPDATE') {
            setProducts(prev => prev.map(p => p.id === (payload.new as Product).id ? (payload.new as Product) : p));
          } else if (payload.eventType === 'DELETE') {
            setProducts(prev => prev.filter(p => p.id !== (payload.old as any).id));
          }
        }
      )
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'orders' },
        (payload) => {
          setLastLiveEvent({ table: 'orders', type: payload.eventType, timestamp: Date.now() });
          if (payload.eventType === 'INSERT') {
            setOrders(prev => {
              if (prev.some(o => o.order_id === (payload.new as Order).order_id)) return prev;
              return [payload.new as Order, ...prev];
            });
          } else if (payload.eventType === 'UPDATE') {
            setOrders(prev => prev.map(o => o.order_id === (payload.new as Order).order_id ? (payload.new as Order) : o));
          } else if (payload.eventType === 'DELETE') {
            setOrders(prev => prev.filter(o => o.order_id !== (payload.old as any).order_id));
          }
        }
      )
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'payments' },
        (payload) => {
          setLastLiveEvent({ table: 'payments', type: payload.eventType, timestamp: Date.now() });
          if (payload.eventType === 'INSERT') {
            setPayments(prev => {
              if (prev.some(p => p.payment_id === (payload.new as Payment).payment_id)) return prev;
              return [payload.new as Payment, ...prev];
            });
          } else if (payload.eventType === 'UPDATE') {
            setPayments(prev => prev.map(p => p.payment_id === (payload.new as Payment).payment_id ? (payload.new as Payment) : p));
          } else if (payload.eventType === 'DELETE') {
            setPayments(prev => prev.filter(p => p.payment_id !== (payload.old as any).payment_id));
          }
        }
      )
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'payment_methods' },
        (payload) => {
          setLastLiveEvent({ table: 'payment_methods', type: payload.eventType, timestamp: Date.now() });
          if (payload.eventType === 'INSERT') {
            const item = payload.new as PaymentMethod;
            setPaymentMethods(prev => {
              let next: PaymentMethod[];
              if (prev.some(m => m.id === item.id)) {
                next = prev.map(m => m.id === item.id ? item : m);
              } else {
                next = [...prev, item];
              }
              localStorage.setItem(STORAGE_KEYS.PAYMENT_METHODS, JSON.stringify(next));
              return next;
            });
          } else if (payload.eventType === 'UPDATE') {
            const updated = payload.new as PaymentMethod;
            setPaymentMethods(prev => {
              const next = prev.map(m => m.id === updated.id ? updated : m);
              localStorage.setItem(STORAGE_KEYS.PAYMENT_METHODS, JSON.stringify(next));
              return next;
            });
          } else if (payload.eventType === 'DELETE') {
            const oldId = (payload.old as any)?.id;
            if (oldId) {
              setPaymentMethods(prev => {
                const next = prev.filter(m => m.id !== oldId);
                localStorage.setItem(STORAGE_KEYS.PAYMENT_METHODS, JSON.stringify(next));
                return next;
              });
            }
          }
        }
      )
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'app_updates' },
        (payload) => {
          setLastLiveEvent({ table: 'app_updates', type: payload.eventType, timestamp: Date.now() });
          if (payload.eventType === 'INSERT') {
            setAppUpdates(prev => {
              if (prev.some(u => u.id === (payload.new as AppUpdate).id)) return prev;
              return [payload.new as AppUpdate, ...prev];
            });
          } else if (payload.eventType === 'UPDATE') {
            setAppUpdates(prev => prev.map(u => u.id === (payload.new as AppUpdate).id ? (payload.new as AppUpdate) : u));
          } else if (payload.eventType === 'DELETE') {
            setAppUpdates(prev => prev.filter(u => u.id !== (payload.old as any).id));
          }
        }
      )
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'countries' },
        (payload) => {
          setLastLiveEvent({ table: 'countries', type: payload.eventType, timestamp: Date.now() });
          if (payload.eventType === 'INSERT') {
            setCountries(prev => {
              if (prev.some(c => c.code === (payload.new as Country).code)) return prev;
              return [...prev, payload.new as Country];
            });
          } else if (payload.eventType === 'UPDATE') {
            setCountries(prev => prev.map(c => c.code === (payload.new as Country).code ? (payload.new as Country) : c));
          } else if (payload.eventType === 'DELETE') {
            setCountries(prev => prev.filter(c => c.code !== (payload.old as any).code));
          }
        }
      )
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'settings' },
        (payload) => {
          setLastLiveEvent({ table: 'settings', type: payload.eventType, timestamp: Date.now() });
          if (payload.new) {
            const s = payload.new as { key: string; value: string };
            setSettingsMap(prev => {
              const next = { ...prev, [s.key]: s.value };
              localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(next));
              return next;
            });

            const currentTargetCode = (!selectedCountry || selectedCountry === 'ALL') ? 'EG' : selectedCountry;
            if (s.key === `orderFee_${currentTargetCode}`) {
              const parsed = parseFloat(s.value);
              if (!isNaN(parsed) && parsed > 0) setOrderFee(parsed);
            } else if (s.key === 'orderFee' && !settingsMap[`orderFee_${currentTargetCode}`]) {
              const parsed = parseFloat(s.value);
              if (!isNaN(parsed) && parsed > 0) setOrderFee(parsed);
            }

            if (s.key === `orderExpiryMinutes_${currentTargetCode}`) {
              const parsed = parseInt(s.value, 10);
              if (!isNaN(parsed) && parsed > 0) setOrderExpiryMinutes(parsed);
            } else if (s.key === 'orderExpiryMinutes' && !settingsMap[`orderExpiryMinutes_${currentTargetCode}`]) {
              const parsed = parseInt(s.value, 10);
              if (!isNaN(parsed) && parsed > 0) setOrderExpiryMinutes(parsed);
            }

            if (s.key === 'currency') setActiveCurrency(s.value);
          }
        }
      )
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'chat_messages' },
        (payload) => {
          setLastLiveEvent({ table: 'chat_messages', type: payload.eventType, timestamp: Date.now() });
          if (payload.eventType === 'INSERT') {
            const msg = payload.new as ChatMessage;
            setChatMessages(prev => {
              if (prev.some(m => m.message_id === msg.message_id)) return prev;
              return [...prev, msg];
            });
          }
        }
      )
      .subscribe((status) => {
        if (status === 'SUBSCRIBED') {
          setIsLiveSyncConnected(true);
        } else if (status === 'CHANNEL_ERROR' || status === 'CLOSED') {
          setIsLiveSyncConnected(false);
        }
      });

    return () => {
      clearInterval(pollInterval);
      supabase.removeChannel(channel);
    };
  }, [currentUser?.id, isAdmin]);

  // Supabase Auth Listeners & Real-Time Auth State
  useEffect(() => {
    // Check active session from Supabase
    supabase.auth.getSession().then(({ data: { session } }) => {
      if (session?.user) {
        applySupabaseSessionUser(session.user);
      }
    }).catch(err => console.warn('Supabase session load error:', err));

    // Listen to real auth state changes (login, logout, token refresh)
    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      if (session?.user) {
        applySupabaseSessionUser(session.user);
      } else if (_event === 'SIGNED_OUT') {
        setCurrentUser(null);
        localStorage.removeItem(STORAGE_KEYS.USER);
      }
    });

    return () => {
      subscription.unsubscribe();
    };
  }, []);

  const applySupabaseSessionUser = (sbUser: any) => {
    const email = (sbUser.email || '').trim().toLowerCase();
    const isOwnerUser = isOwnerEmail(email);
    const isModUser = moderators.some(m => m.email.trim().toLowerCase() === email);
    const hasAdminAccess = isOwnerUser || isModUser;

    const profile: UserProfile = {
      id: sbUser.id || (isOwnerUser ? OWNER_UUID : 'usr_' + Math.random().toString(36).substring(2, 9)),
      name: isOwnerUser ? 'المالك والمدير العام 👑' : (isModUser ? `${sbUser.user_metadata?.full_name || sbUser.user_metadata?.name || email.split('@')[0]} (مشرف 🛡️)` : (sbUser.user_metadata?.full_name || sbUser.user_metadata?.name || email.split('@')[0])),
      email: email,
      avatar_url: sbUser.user_metadata?.avatar_url || sbUser.user_metadata?.picture || (isOwnerUser ? '' : `https://api.dicebear.com/7.x/initials/svg?seed=${email}`),
      is_admin: hasAdminAccess,
      role: isOwnerUser ? 'admin' : (isModUser ? 'moderator' : 'user'),
      created_at: sbUser.created_at ? new Date(sbUser.created_at).getTime() : Date.now()
    };
    setCurrentUser(profile);
    localStorage.setItem(STORAGE_KEYS.USER, JSON.stringify(profile));
  };

  // Real Google OAuth with Gmail Workspace support
  const signInWithGoogleReal = async () => {
    try {
      const { user: fbUser, accessToken } = await signInWithGoogleWorkspace();
      const email = (fbUser.email || '').trim().toLowerCase();
      const isOwnerUser = isOwnerEmail(email);
      const isModUser = moderators.some(m => m.email.trim().toLowerCase() === email);
      const hasAdminAccess = isOwnerUser || isModUser;

      const profile: UserProfile = {
        id: fbUser.uid || (isOwnerUser ? OWNER_UUID : 'usr_' + Math.random().toString(36).substring(2, 9)),
        name: isOwnerUser ? 'المالك والمدير العام 👑' : (isModUser ? `${fbUser.displayName || email.split('@')[0]} (مشرف 🛡️)` : (fbUser.displayName || email.split('@')[0] || 'مستخدم Google')),
        email: email,
        avatar_url: fbUser.photoURL || (isOwnerUser ? '' : `https://api.dicebear.com/7.x/initials/svg?seed=${email}`),
        is_admin: hasAdminAccess,
        role: isOwnerUser ? 'admin' : (isModUser ? 'moderator' : 'user'),
        created_at: Date.now()
      };
      setCurrentUser(profile);
      localStorage.setItem(STORAGE_KEYS.USER, JSON.stringify(profile));
      setIsAuthModalOpen(false);

      // Persist to Supabase Database
      try {
        await supabase.from('users').upsert({
          id: profile.id,
          name: profile.name,
          email: profile.email,
          avatar_url: profile.avatar_url || '',
          is_admin: profile.is_admin,
          role: profile.role,
          country_code: selectedCountry,
          updated_at: new Date().toISOString()
        }, { onConflict: 'email' });
      } catch (e) {
        console.warn('User upsert notice:', e);
      }
    } catch (err: any) {
      console.warn('Google Workspace login popup notice:', err);
      // Fallback to Supabase OAuth redirect if needed
      try {
        const redirectUrl = window.location.origin;
        const { data, error } = await supabase.auth.signInWithOAuth({
          provider: 'google',
          options: {
            redirectTo: redirectUrl,
            queryParams: {
              prompt: 'select_account'
            }
          }
        });
        if (error) throw error;
        if (data?.url) {
          window.location.href = data.url;
        }
      } catch (fallbackErr) {
        throw err;
      }
    }
  };

  // Auth Methods
  const loginWithGoogle = async (email?: string, name?: string) => {
    const userEmail = (email || '').trim().toLowerCase();
    const isOwnerUser = isOwnerEmail(userEmail);
    const isModUser = moderators.some(m => m.email.trim().toLowerCase() === userEmail);
    const hasAdminAccess = isOwnerUser || isModUser;

    const userProfile: UserProfile = {
      id: isOwnerUser ? OWNER_UUID : 'usr_' + Math.random().toString(36).substring(2, 9),
      name: isOwnerUser ? 'المالك والمدير العام 👑' : (isModUser ? `${name || (userEmail ? userEmail.split('@')[0] : 'مشرف')} (مشرف 🛡️)` : (name || (userEmail ? userEmail.split('@')[0] : 'مستخدم Google'))),
      email: userEmail,
      avatar_url: isOwnerUser ? '' : `https://api.dicebear.com/7.x/initials/svg?seed=${name || userEmail}`,
      is_admin: hasAdminAccess,
      role: isOwnerUser ? 'admin' : (isModUser ? 'moderator' : 'user'),
      created_at: Date.now()
    };
    setCurrentUser(userProfile);
    localStorage.setItem(STORAGE_KEYS.USER, JSON.stringify(userProfile));
    setIsAuthModalOpen(false);

    // Persist to Supabase Database (table 'users')
    try {
      await supabase.from('users').upsert({
        id: userProfile.id,
        name: userProfile.name,
        email: userProfile.email,
        avatar_url: userProfile.avatar_url || '',
        is_admin: userProfile.is_admin,
        role: userProfile.role,
        country_code: selectedCountry,
        updated_at: new Date().toISOString()
      }, { onConflict: 'email' });
    } catch (e) {
      console.warn('User upsert notice:', e);
    }
  };

  const logout = () => {
    supabase.auth.signOut().catch(() => {});
    logoutGoogle().catch(() => {});
    setCurrentUser(null);
    localStorage.removeItem(STORAGE_KEYS.USER);
    if (currentView === 'admin' || currentView === 'gmail') {
      setCurrentView('home');
    }
  };

  const setGuestUser = async () => {
    const randNumber = Math.floor(100000 + Math.random() * 900000);
    const guestId = `GST-${randNumber}`;
    const guestName = `زائر #${randNumber}`;
    const guestEmail = `guest_${randNumber}@m3ak100.com`;

    const guest: UserProfile = {
      id: guestId,
      name: guestName,
      email: guestEmail,
      avatar_url: `https://api.dicebear.com/7.x/initials/svg?seed=${randNumber}`,
      is_admin: false,
      role: 'guest',
      created_at: Date.now()
    };
    setCurrentUser(guest);
    localStorage.setItem(STORAGE_KEYS.USER, JSON.stringify(guest));
    setIsAuthModalOpen(false);

    try {
      await supabase.from('users').upsert({
        id: guest.id,
        name: guest.name,
        email: guest.email,
        avatar_url: guest.avatar_url || '',
        is_admin: false,
        role: 'guest',
        country_code: selectedCountry,
        updated_at: new Date().toISOString()
      }, { onConflict: 'email' });
    } catch (e) {
      console.warn('Guest upsert notice:', e);
    }
  };

  // Favorites
  const toggleFavorite = (productId: string) => {
    setFavorites(prev => {
      const exists = prev.includes(productId);
      const next = exists ? prev.filter(id => id !== productId) : [...prev, productId];
      // Sync with Supabase favorites if logged in
      if (currentUser && currentUser.role !== 'guest') {
        if (exists) {
          supabase.from('favorites').delete().eq('user_id', currentUser.id).eq('product_id', productId).then();
        } else {
          supabase.from('favorites').insert({
            id: `${currentUser.id}_${productId}`,
            user_id: currentUser.id,
            product_id: productId,
            created_at: Date.now()
          }).then();
        }
      }
      return next;
    });
  };

  // Orders
  const createOrder = async (product: Product): Promise<Order> => {
    const user = currentUser || {
      id: 'guest_' + Math.random().toString(36).substring(2, 9),
      name: 'عميل معاك 100',
      email: 'guest@m3ak100.com',
      is_admin: false,
      role: 'guest'
    };

    const dateStr = new Date().toISOString().slice(0, 10).replace(/-/g, '');
    const randSeq = Math.floor(100000 + Math.random() * 900000);
    const orderId = `FK-${dateStr}-${randSeq}`;
    const now = Date.now();

    const targetCountry = (product.country_code && product.country_code !== 'ALL')
      ? product.country_code
      : (selectedCountry !== 'ALL' ? selectedCountry : 'EG');

    const specificFee = getOrderFeeForCountry(targetCountry);
    const specificExpiryMinutes = getOrderExpiryForCountry(targetCountry);
    const expiresAt = now + specificExpiryMinutes * 60 * 1000;

    const initialFee = isPaymentGatewayEnabled ? specificFee : 0;
    const initialStatus = isPaymentGatewayEnabled ? 'PENDING_PAYMENT' : 'APPROVED';
    const initialRedirect = isPaymentGatewayEnabled ? 'NotRedirected' : 'DirectActivated';

    const newOrder: Order = {
      order_id: orderId,
      user_id: user.id,
      user_name: user.name,
      user_phone: user.phone || '',
      product_id: product.id,
      product_name: product.name,
      product_image: product.image_url,
      product_price: product.price,
      order_fee: initialFee,
      payment_status: initialStatus,
      created_at: now,
      original_product_url: product.original_product_url,
      affiliate_url: product.affiliate_url,
      store_name: product.store_name,
      redirect_status: initialRedirect,
      expires_at: expiresAt,
      coupon_code: product.coupon_code || '',
      country_code: targetCountry
    };

    setOrders(prev => [newOrder, ...prev]);

    // Push to Supabase with robust upsert
    try {
      const { error: upsertErr } = await supabase.from('orders').upsert({
        order_id: newOrder.order_id,
        user_id: newOrder.user_id,
        user_name: newOrder.user_name,
        user_phone: newOrder.user_phone,
        product_id: newOrder.product_id,
        product_name: newOrder.product_name,
        product_image: newOrder.product_image,
        product_price: newOrder.product_price,
        order_fee: newOrder.order_fee,
        payment_status: newOrder.payment_status,
        created_at: newOrder.created_at,
        original_product_url: newOrder.original_product_url,
        affiliate_url: newOrder.affiliate_url,
        store_name: newOrder.store_name,
        redirect_status: newOrder.redirect_status,
        expires_at: newOrder.expires_at,
        coupon_code: newOrder.coupon_code
      }, { onConflict: 'order_id' });

      if (upsertErr) {
        console.error('Supabase order sync error:', upsertErr);
      }
    } catch (e) {
      console.warn('Order sync exception:', e);
    }

    return newOrder;
  };

  const deleteOrder = async (orderId: string) => {
    setOrders(prev => prev.filter(o => o.order_id !== orderId));
    setPayments(prev => prev.filter(p => p.order_id !== orderId));

    try {
      await supabase.from('payments').delete().eq('order_id', orderId);
      await supabase.from('orders').delete().eq('order_id', orderId);
    } catch (e) {
      console.warn('Order delete notice:', e);
    }
  };

  // Submit Payment
  const submitPayment = async (
    orderId: string,
    method: string,
    senderWallet: string,
    receiptImage: string
  ): Promise<boolean> => {
    const order = orders.find(o => o.order_id === orderId);
    if (!order) return false;

    const paymentId = 'PAY-' + Math.random().toString(36).substring(2, 9).toUpperCase();
    const now = Date.now();

    // Automatic date and time recording according to Egypt time (القاهرة)
    const autoDateTime = new Date().toLocaleString('ar-EG', {
      timeZone: 'Africa/Cairo',
      year: 'numeric',
      month: 'numeric',
      day: 'numeric',
      hour: 'numeric',
      minute: 'numeric',
      second: 'numeric',
      hour12: true
    }) + ' (توقيت مصر - القاهرة)';

    const newPayment: Payment = {
      payment_id: paymentId,
      order_id: orderId,
      user_id: order.user_id,
      user_name: order.user_name,
      user_email: currentUser?.email,
      user_phone: senderWallet,
      product_name: order.product_name,
      amount: order.order_fee,
      status: 'PAYMENT_REVIEW',
      payment_method: method,
      sender_wallet: senderWallet,
      transaction_id: 'تلقائي (تحويل مباشر)',
      transfer_date_time: autoDateTime,
      receipt_image_url: receiptImage,
      created_at: now,
      expires_at: order.expires_at,
      country_code: order.country_code || (selectedCountry !== 'ALL' ? selectedCountry : 'EG')
    };

    setPayments(prev => [newPayment, ...prev]);

    // Update order status
    setOrders(prev => prev.map(o => o.order_id === orderId ? { ...o, payment_status: 'PAYMENT_REVIEW', user_phone: senderWallet } : o));

    // Save to Supabase
    try {
      console.log('Attempting to upsert payment with receipt URL length:', newPayment.receipt_image_url?.length);
      
      // Upload receipt to Supabase Storage if it's a data URL
      let uploadedReceiptUrl = newPayment.receipt_image_url;
      if (newPayment.receipt_image_url?.startsWith('data:')) {
          const response = await fetch(newPayment.receipt_image_url);
          const blob = await response.blob();
          const fileName = `receipts/${orderId}_${paymentId}.jpg`;
          
          const { data, error: uploadErr } = await supabase.storage
            .from('receipts')
            .upload(fileName, blob, { contentType: 'image/jpeg', upsert: true });
            
          if (uploadErr) {
              console.error('Supabase storage upload error:', uploadErr);
          } else {
              const { data: publicUrlData } = supabase.storage
                .from('receipts')
                .getPublicUrl(fileName);
              uploadedReceiptUrl = publicUrlData.publicUrl;
          }
      }

      const { error: payErr } = await supabase.from('payments').upsert({
        payment_id: newPayment.payment_id,
        order_id: newPayment.order_id,
        user_id: newPayment.user_id,
        user_name: newPayment.user_name,
        user_email: newPayment.user_email || '',
        user_phone: newPayment.user_phone || '',
        product_name: newPayment.product_name,
        amount: newPayment.amount,
        status: newPayment.status,
        payment_method: newPayment.payment_method,
        sender_wallet: newPayment.sender_wallet,
        transaction_id: newPayment.transaction_id,
        transfer_date_time: newPayment.transfer_date_time,
        receipt_image_url: uploadedReceiptUrl,
        created_at: newPayment.created_at,
        expires_at: newPayment.expires_at
      }, { onConflict: 'payment_id' });

      if (payErr) {
        console.error('Supabase payment sync error:', payErr);
      } else {
        console.log('Payment upsert successful');
      }

      const { error: ordUpErr } = await supabase.from('orders').update({
        payment_status: 'PAYMENT_REVIEW',
        user_phone: senderWallet
      }).eq('order_id', orderId);

      if (ordUpErr) {
        console.error('Supabase order update error:', ordUpErr);
      }
    } catch (e) {
      console.warn('Payment sync exception:', e);
    }

    return true;
  };

  const deletePayment = async (paymentId: string) => {
    const payment = payments.find(p => p.payment_id === paymentId);
    setPayments(prev => prev.filter(p => p.payment_id !== paymentId));

    if (payment) {
      setOrders(prev => prev.map(o => {
        if (o.order_id === payment.order_id && (o.payment_status === 'PAYMENT_REVIEW' || o.payment_status === 'REJECTED')) {
          return { ...o, payment_status: 'PENDING_PAYMENT' };
        }
        return o;
      }));

      try {
        await supabase.from('payments').delete().eq('payment_id', paymentId);
        await supabase.from('orders').update({ payment_status: 'PENDING_PAYMENT' }).eq('order_id', payment.order_id);
      } catch (e) {
        console.warn('Payment delete notice:', e);
      }
    } else {
      try {
        await supabase.from('payments').delete().eq('payment_id', paymentId);
      } catch (e) {
        console.warn('Payment delete notice:', e);
      }
    }
  };

  // Support Chat
  const sendChatMessage = async (text: string, orderId?: string) => {
    if (!text.trim()) return;
    const user = currentUser || { id: 'guest', name: 'عميل' };
    const now = Date.now();
    const newMsg: ChatMessage = {
      message_id: 'msg_' + Math.random().toString(36).substring(2, 9),
      conversation_id: user.id,
      order_id: orderId,
      sender_id: user.id,
      sender_name: user.name,
      sender_role: isAdmin ? 'ADMIN' : 'USER',
      message_text: text.trim(),
      timestamp: now,
      is_read: false
    };

    setChatMessages(prev => [...prev, newMsg]);

    try {
      await supabase.from('chat_messages').insert({
        message_id: newMsg.message_id,
        conversation_id: newMsg.conversation_id,
        order_id: newMsg.order_id || null,
        sender_id: newMsg.sender_id,
        sender_name: newMsg.sender_name,
        sender_role: newMsg.sender_role,
        message_text: newMsg.message_text,
        timestamp: newMsg.timestamp,
        is_read: false
      });
    } catch (e) {
      console.warn('Chat insert notice:', e);
    }
  };

  // Admin Actions
  const adminApprovePayment = async (paymentId: string, orderId: string) => {
    const now = Date.now();
    setPayments(prev => prev.map(p => p.payment_id === paymentId ? { ...p, status: 'APPROVED', reviewed_at: now, reviewed_by_admin_name: 'إدارة معاك 100' } : p));
    setOrders(prev => prev.map(o => o.order_id === orderId ? { ...o, payment_status: 'APPROVED' } : o));

    try {
      await supabase.from('payments').update({
        status: 'APPROVED',
        reviewed_at: now,
        reviewed_by_admin_name: 'إدارة معاك 100'
      }).eq('payment_id', paymentId);

      await supabase.from('orders').update({
        payment_status: 'APPROVED'
      }).eq('order_id', orderId);
    } catch (e) {
      console.warn('Payment approval notice:', e);
    }
  };

  const adminRejectPayment = async (paymentId: string, orderId: string, reason: string) => {
    const now = Date.now();
    setPayments(prev => prev.map(p => p.payment_id === paymentId ? { ...p, status: 'REJECTED', rejection_reason: reason, reviewed_at: now } : p));
    setOrders(prev => prev.map(o => o.order_id === orderId ? { ...o, payment_status: 'REJECTED', rejection_reason: reason } : o));

    try {
      await supabase.from('payments').update({
        status: 'REJECTED',
        rejection_reason: reason,
        reviewed_at: now
      }).eq('payment_id', paymentId);

      await supabase.from('orders').update({
        payment_status: 'REJECTED',
        rejection_reason: reason
      }).eq('order_id', orderId);
    } catch (e) {
      console.warn('Payment rejection notice:', e);
    }
  };

  const adminUpsertProduct = async (product: Product) => {
    setProducts(prev => {
      const idx = prev.findIndex(p => p.id === product.id);
      if (idx >= 0) {
        const next = [...prev];
        next[idx] = product;
        return next;
      }
      return [product, ...prev];
    });

    try {
      await supabase.from('products').upsert(product);
    } catch (e) {
      console.warn('Product upsert notice:', e);
    }
  };

  const adminDeleteProduct = async (productId: string) => {
    setProducts(prev => prev.filter(p => p.id !== productId));
    try {
      await supabase.from('products').delete().eq('id', productId);
    } catch (e) {
      console.warn('Product delete notice:', e);
    }
  };

  const adminToggleFeatured = async (productId: string) => {
    setProducts(prev => prev.map(p => {
      if (p.id === productId) {
        const updated = { ...p, is_featured: !p.is_featured };
        supabase.from('products').update({ is_featured: updated.is_featured }).eq('id', productId).then();
        return updated;
      }
      return p;
    }));
  };

  const adminUpsertPaymentMethod = async (method: PaymentMethod) => {
    setPaymentMethods(prev => {
      const idx = prev.findIndex(m => m.id === method.id);
      let next: PaymentMethod[];
      if (idx >= 0) {
        next = prev.map((m, i) => i === idx ? method : m);
      } else {
        next = [...prev, method];
      }
      localStorage.setItem(STORAGE_KEYS.PAYMENT_METHODS, JSON.stringify(next));
      return next;
    });

    try {
      await supabase.from('payment_methods').upsert(method, { onConflict: 'id' });
    } catch (e) {
      console.warn('Payment method upsert notice:', e);
    }
  };

  const adminDeletePaymentMethod = async (methodId: string) => {
    setPaymentMethods(prev => {
      const next = prev.filter(m => m.id !== methodId);
      localStorage.setItem(STORAGE_KEYS.PAYMENT_METHODS, JSON.stringify(next));
      return next;
    });
    try {
      await supabase.from('payment_methods').delete().eq('id', methodId);
    } catch (e) {
      console.warn('Payment method delete notice:', e);
    }
  };

  const adminTogglePaymentMethodActive = async (methodId: string) => {
    let newStatus = true;
    setPaymentMethods(prev => {
      const next = prev.map(m => {
        if (m.id === methodId) {
          newStatus = !m.is_enabled;
          return { ...m, is_enabled: !m.is_enabled };
        }
        return m;
      });
      localStorage.setItem(STORAGE_KEYS.PAYMENT_METHODS, JSON.stringify(next));
      return next;
    });

    try {
      await supabase.from('payment_methods').update({ is_enabled: newStatus }).eq('id', methodId);
    } catch (e) {
      console.warn('Payment method toggle notice:', e);
    }
  };

  const adminSyncPaymentMethodsToSupabase = async (): Promise<{ success: boolean; count?: number; error?: string }> => {
    try {
      if (paymentMethods.length === 0) {
        return { success: true, count: 0 };
      }

      // 1. Upsert all current custom & modified payment methods to Supabase
      const { error: upsertErr } = await supabase
        .from('payment_methods')
        .upsert(paymentMethods, { onConflict: 'id' });

      if (upsertErr) {
        return { success: false, error: upsertErr.message };
      }

      // 2. Clean up any deleted method IDs on Supabase so deleted wallets do not linger
      try {
        const currentIds = paymentMethods.map(m => m.id);
        const { data: dbMethods } = await supabase.from('payment_methods').select('id');
        if (dbMethods && dbMethods.length > 0) {
          const toDeleteIds = dbMethods.map((m: any) => m.id).filter((id: string) => !currentIds.includes(id));
          if (toDeleteIds.length > 0) {
            await supabase.from('payment_methods').delete().in('id', toDeleteIds);
          }
        }
      } catch (cleanErr) {
        console.warn('Orphaned payment methods cleanup note:', cleanErr);
      }

      // 3. Re-fetch fresh data from Supabase to guarantee 100% sync
      const { data: freshMethods, error: fetchErr } = await supabase
        .from('payment_methods')
        .select('*')
        .order('display_order', { ascending: true });

      if (!fetchErr && freshMethods && freshMethods.length > 0) {
        setPaymentMethods(freshMethods);
        localStorage.setItem(STORAGE_KEYS.PAYMENT_METHODS, JSON.stringify(freshMethods));
      }

      return { success: true, count: paymentMethods.length };
    } catch (e: any) {
      return { success: false, error: e?.message || 'فشل المزامنة مع Supabase' };
    }
  };

  const adminSeedPaymentMethodsToSupabase = adminSyncPaymentMethodsToSupabase;

  const adminResetDefaultPaymentMethods = async (): Promise<{ success: boolean; count?: number; error?: string }> => {
    try {
      const { error } = await supabase
        .from('payment_methods')
        .upsert(DEFAULT_PAYMENT_METHODS, { onConflict: 'id' });

      if (error) {
        return { success: false, error: error.message };
      }

      setPaymentMethods(DEFAULT_PAYMENT_METHODS);
      localStorage.setItem(STORAGE_KEYS.PAYMENT_METHODS, JSON.stringify(DEFAULT_PAYMENT_METHODS));

      return { success: true, count: DEFAULT_PAYMENT_METHODS.length };
    } catch (e: any) {
      return { success: false, error: e?.message || 'فشلت استعادة المحافظ الافتراضية' };
    }
  };

  const adminToggleCountryActive = async (countryCode: string) => {
    let newStatus = true;
    setCountries(prev => {
      const next = prev.map(c => {
        if (c.code === countryCode) {
          newStatus = !c.is_active;
          return { ...c, is_active: !c.is_active };
        }
        return c;
      });
      localStorage.setItem(STORAGE_KEYS.COUNTRIES, JSON.stringify(next));

      // If current selectedCountry was disabled, fall back to first active country
      const currentActive = next.find(c => c.code === selectedCountry && c.is_active);
      if (!currentActive) {
        const firstActive = next.find(c => c.is_active);
        if (firstActive) {
          setSelectedCountry(firstActive.code);
        }
      }
      return next;
    });

    try {
      await supabase.from('countries').update({ is_active: newStatus }).eq('code', countryCode);
    } catch (e) {
      console.warn('Supabase country toggle update notice:', e);
    }
  };

  const adminUpsertCountry = async (country: Country) => {
    setCountries(prev => {
      const idx = prev.findIndex(c => c.code === country.code);
      const next = idx >= 0 ? prev.map((c, i) => i === idx ? country : c) : [...prev, country];
      localStorage.setItem(STORAGE_KEYS.COUNTRIES, JSON.stringify(next));
      return next;
    });

    try {
      await supabase.from('countries').upsert(country, { onConflict: 'code' });
    } catch (e) {
      console.warn('Supabase country upsert notice:', e);
    }
  };

  const adminDeleteCountry = async (countryCode: string) => {
    setCountries(prev => {
      const next = prev.filter(c => c.code !== countryCode);
      localStorage.setItem(STORAGE_KEYS.COUNTRIES, JSON.stringify(next));
      return next;
    });

    try {
      await supabase.from('countries').delete().eq('code', countryCode);
    } catch (e) {
      console.warn('Supabase country delete notice:', e);
    }
  };

  const adminSeedCountriesToSupabase = async (): Promise<{ success: boolean; count?: number; error?: string }> => {
    try {
      const { error } = await supabase.from('countries').upsert(DEFAULT_COUNTRIES, { onConflict: 'code' });
      if (error) {
        console.warn('Supabase countries seeding notice:', error.message);
        return { success: false, error: error.message };
      }
      setCountries(DEFAULT_COUNTRIES);
      localStorage.setItem(STORAGE_KEYS.COUNTRIES, JSON.stringify(DEFAULT_COUNTRIES));
      return { success: true, count: DEFAULT_COUNTRIES.length };
    } catch (e: any) {
      return { success: false, error: e?.message || 'فشلت تهيئة الدول' };
    }
  };

  const adminUpdateSettings = async (newFee: number, newExpiry: number, currency: string) => {
    setOrderFee(newFee);
    setOrderExpiryMinutes(newExpiry);
    setActiveCurrency(currency);

    const currentTargetCode = (!selectedCountry || selectedCountry === 'ALL') ? 'EG' : selectedCountry;
    const updates: { key: string; value: string }[] = [
      { key: 'orderFee', value: newFee.toString() },
      { key: 'orderExpiryMinutes', value: newExpiry.toString() },
      { key: 'currency', value: currency },
      { key: `orderFee_${currentTargetCode}`, value: newFee.toString() },
      { key: `orderExpiryMinutes_${currentTargetCode}`, value: newExpiry.toString() }
    ];

    setSettingsMap(prev => {
      const next = { ...prev };
      updates.forEach(u => {
        next[u.key] = u.value;
      });
      localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(next));
      return next;
    });

    try {
      await supabase.from('settings').upsert(updates, { onConflict: 'key' });
    } catch (e) {
      console.warn('Settings update notice:', e);
    }
  };

  const adminUpdateCountrySettings = async (
    countryCode: string,
    newFee: number,
    newExpiry: number,
    currency?: string,
    currencySymbol?: string
  ) => {
    const code = (countryCode || 'EG').trim().toUpperCase();
    const updates: { key: string; value: string }[] = [
      { key: `orderFee_${code}`, value: newFee.toString() },
      { key: `orderExpiryMinutes_${code}`, value: newExpiry.toString() }
    ];

    if (currency) {
      updates.push({ key: `currency_${code}`, value: currency });
    }
    if (currencySymbol) {
      updates.push({ key: `currency_symbol_${code}`, value: currencySymbol });
    }

    // Sync base fallback keys if editing default country (EG)
    if (code === 'EG') {
      updates.push({ key: 'orderFee', value: newFee.toString() });
      updates.push({ key: 'orderExpiryMinutes', value: newExpiry.toString() });
      if (currency) updates.push({ key: 'currency', value: currency });
    }

    // Optimistically update local settings map
    setSettingsMap(prev => {
      const next = { ...prev };
      updates.forEach(u => {
        next[u.key] = u.value;
      });
      localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(next));
      return next;
    });

    // If currently viewing this country, update live fee & expiry state
    if (selectedCountry === code || (selectedCountry === 'ALL' && code === 'EG')) {
      setOrderFee(newFee);
      setOrderExpiryMinutes(newExpiry);
      if (currency) setActiveCurrency(currency);
    }

    try {
      await supabase.from('settings').upsert(updates, { onConflict: 'key' });
    } catch (e) {
      console.warn('Country settings update notice:', e);
    }
  };

  const adminTogglePaymentGateway = async (enabled: boolean) => {
    setIsPaymentGatewayEnabled(enabled);
    localStorage.setItem('m3ak_payment_gateway_enabled', enabled ? 'true' : 'false');

    if (!enabled) {
      setOrderFee(0);
    } else {
      const currentTargetCode = (!selectedCountry || selectedCountry === 'ALL') ? 'EG' : selectedCountry;
      const fee = getOrderFeeForCountry(currentTargetCode);
      setOrderFee(fee);
    }

    setSettingsMap(prev => {
      const next = { ...prev, payment_gateway_enabled: enabled ? 'true' : 'false' };
      localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(next));
      return next;
    });

    try {
      await supabase.from('settings').upsert({
        key: 'payment_gateway_enabled',
        value: enabled ? 'true' : 'false'
      }, { onConflict: 'key' });
    } catch (e) {
      console.warn('Payment gateway toggle Supabase note:', e);
    }
  };

  const adminAddModerator = async (email: string, name?: string): Promise<{ success: boolean; error?: string }> => {
    const cleanEmail = (email || '').trim().toLowerCase();
    if (!cleanEmail || !cleanEmail.includes('@') || !cleanEmail.includes('.')) {
      return { success: false, error: 'يرجى إدخال بريد إلكتروني صالح (مثل: user@gmail.com)' };
    }

    if (isOwnerEmail(cleanEmail)) {
      return { success: false, error: 'هذا البريد هو المالك الأساسي والمدير العام ومحمى بأعلى رتبة 👑' };
    }

    if (moderators.some(m => m.email.toLowerCase() === cleanEmail)) {
      return { success: false, error: 'هذا الحساب مضاف بالفعل كمشرف في لوحة التحكم' };
    }

    const newMod: ModeratorUser = {
      email: cleanEmail,
      name: (name || '').trim() || cleanEmail.split('@')[0],
      added_at: Date.now(),
      added_by: currentUser?.email || OWNER_EMAIL,
      role: 'moderator'
    };

    const updatedMods = [newMod, ...moderators];
    setModerators(updatedMods);
    localStorage.setItem(STORAGE_KEYS.MODERATORS, JSON.stringify(updatedMods));

    // Also update current user state if the added moderator happens to be logged in right now
    if (currentUser?.email && currentUser.email.toLowerCase() === cleanEmail) {
      const updatedProfile: UserProfile = {
        ...currentUser,
        is_admin: true,
        role: 'moderator'
      };
      setCurrentUser(updatedProfile);
      localStorage.setItem(STORAGE_KEYS.USER, JSON.stringify(updatedProfile));
    }

    try {
      await supabase.from('settings').upsert({
        key: 'authorized_moderators',
        value: JSON.stringify(updatedMods)
      }, { onConflict: 'key' });
    } catch (e) {
      console.warn('Moderator save to Supabase note:', e);
    }

    return { success: true };
  };

  const adminRemoveModerator = async (email: string): Promise<{ success: boolean; error?: string }> => {
    const cleanEmail = (email || '').trim().toLowerCase();
    if (isOwnerEmail(cleanEmail)) {
      return { success: false, error: 'خط أحمر ⛔: حساب المالك الأساسي محمي بشكل دائم ولا يمكن إزالته أو حذفه أبداً!' };
    }

    const updatedMods = moderators.filter(m => m.email.toLowerCase() !== cleanEmail);
    setModerators(updatedMods);
    localStorage.setItem(STORAGE_KEYS.MODERATORS, JSON.stringify(updatedMods));

    // If removed moderator is currently logged in, demote them
    if (currentUser?.email && currentUser.email.toLowerCase() === cleanEmail) {
      const demotedProfile: UserProfile = {
        ...currentUser,
        is_admin: false,
        role: 'user'
      };
      setCurrentUser(demotedProfile);
      localStorage.setItem(STORAGE_KEYS.USER, JSON.stringify(demotedProfile));
    }

    try {
      await supabase.from('settings').upsert({
        key: 'authorized_moderators',
        value: JSON.stringify(updatedMods)
      }, { onConflict: 'key' });
    } catch (e) {
      console.warn('Moderator delete Supabase note:', e);
    }

    return { success: true };
  };

  const adminUploadApk = async (
    file: File,
    versionName: string,
    versionCode: number,
    title: string,
    description: string,
    isActive: boolean = true
  ): Promise<{ success: boolean; error?: string; update?: AppUpdate }> => {
    try {
      if (!file) {
        return { success: false, error: 'لم يتم اختيار أي ملف للرفع' };
      }

      // 1. Run browser-side binary APK inspection & compatibility check
      const analysis = await validateAndAnalyzeApkFile(file, versionName);
      if (!analysis.isValidApk) {
        return {
          success: false,
          error: 'الملف المحدد ليس حزمة أندرويد APK صالحة. يرجى التأكد من اختيار ملف حقيقي بصيغة .apk'
        };
      }

      const cleanFileName = sanitizeApkFileName(file.name, versionName);
      const filePath = `releases/${Date.now()}_${cleanFileName}`;

      console.log(`[Supabase Storage] Starting APK upload to bucket 'app-apks': ${filePath} (${analysis.fileSizeMb} MB)...`);

      // 2. Execute actual upload to Supabase Storage bucket 'app-apks'
      const { data: uploadData, error: uploadErr } = await supabase.storage
        .from('app-apks')
        .upload(filePath, file, {
          contentType: 'application/vnd.android.package-archive',
          cacheControl: '3600',
          upsert: true
        });

      // 3. Strict verification: halt if upload fails
      if (uploadErr || !uploadData) {
        console.error('[Supabase Storage] APK upload failed:', uploadErr);
        const rawMsg = uploadErr?.message || 'تعذر إتمام عملية الرفع إلى Storage';
        let friendlyError = `فشل في رفع ملف الـ APK إلى Supabase Storage: ${rawMsg}`;
        if (rawMsg.toLowerCase().includes('bucket not found')) {
          friendlyError = `حاوية التخزين (Bucket) باسم 'app-apks' غير موجودة في مشروع Supabase. يرجى إنشاء Bucket باسم app-apks وجعله Public في لوحة Supabase.`;
        } else if (rawMsg.toLowerCase().includes('row-level security') || rawMsg.toLowerCase().includes('policy')) {
          friendlyError = `سياسة الأمان (RLS Policy) تمنع الرفع لحاوية app-apks. يرجى تطبيق كود SQL الموضح في لوحة التحكم لإعطاء صلاحيات الرفع والتحميل.`;
        }
        return { success: false, error: friendlyError };
      }

      console.log('[Supabase Storage] APK uploaded successfully:', uploadData);

      // 4. Obtain public URL only AFTER successful upload
      const { data: publicUrlData } = supabase.storage
        .from('app-apks')
        .getPublicUrl(filePath);

      if (!publicUrlData || !publicUrlData.publicUrl) {
        return {
          success: false,
          error: 'تم رفع الملف ولكن تعذر استخراج الرابط العام (Public URL) من Supabase Storage'
        };
      }

      const apkUrl = publicUrlData.publicUrl;
      const updateId = 'update_' + Date.now() + '_' + Math.random().toString(36).substring(2, 7);
      const now = Date.now();

      // Deactivate others if this is set to active
      if (isActive) {
        setAppUpdates(prev => prev.map(u => ({ ...u, is_active: false })));
        try {
          await supabase.from('app_updates').update({ is_active: false }).neq('id', updateId);
        } catch {}
      }

      const newUpdate: AppUpdate = {
        id: updateId,
        version_name: versionName.trim(),
        version_code: versionCode,
        apk_url: apkUrl,
        update_title: title.trim(),
        update_description: description.trim(),
        is_active: isActive,
        created_at: now,
        file_size_mb: analysis.fileSizeMb
      };

      // 5. Save release record to Supabase table 'app_updates'
      try {
        const { error: dbErr } = await supabase.from('app_updates').upsert({
          id: newUpdate.id,
          version_name: newUpdate.version_name,
          version_code: newUpdate.version_code,
          apk_url: newUpdate.apk_url,
          update_title: newUpdate.update_title,
          update_description: newUpdate.update_description,
          is_active: newUpdate.is_active,
          created_at: newUpdate.created_at,
          file_size_mb: newUpdate.file_size_mb
        }, { onConflict: 'id' });

        if (dbErr) {
          console.warn('Supabase app_updates table upsert note (table might need creation):', dbErr.message);
        }
      } catch (err) {
        console.warn('Failed to upsert to app_updates table:', err);
      }

      // Also propagate to settings table for instant live sync across all devices
      if (newUpdate.is_active) {
        try {
          await supabase.from('settings').upsert({
            key: 'latest_active_app_update',
            value: JSON.stringify(newUpdate)
          }, { onConflict: 'key' });
        } catch {}
      }

      // 6. Update local state
      setAppUpdates(prev => [newUpdate, ...prev.filter(u => u.id !== newUpdate.id)]);
      localStorage.setItem(STORAGE_KEYS.APP_UPDATES, JSON.stringify([newUpdate, ...appUpdates]));

      return { success: true, update: newUpdate };
    } catch (e: any) {
      console.error('adminUploadApk exception:', e);
      return { success: false, error: e?.message || 'حدث خطأ غير متوقع أثناء معالجة رفع ملف APK' };
    }
  };

  const adminPublishCustomApkUrl = async (
    apkUrl: string,
    versionName: string,
    versionCode: number,
    title: string,
    description: string,
    isActive: boolean = true,
    fileSizeMb?: number
  ): Promise<{ success: boolean; error?: string; update?: AppUpdate }> => {
    try {
      if (!apkUrl.trim() || !apkUrl.startsWith('http')) {
        return { success: false, error: 'يرجى إدخال رابط مباشر صالح يبدأ بـ https://' };
      }

      const updateId = 'update_' + Date.now() + '_' + Math.random().toString(36).substring(2, 7);
      const now = Date.now();

      if (isActive) {
        setAppUpdates(prev => prev.map(u => ({ ...u, is_active: false })));
        try {
          await supabase.from('app_updates').update({ is_active: false }).neq('id', updateId);
        } catch {}
      }

      const newUpdate: AppUpdate = {
        id: updateId,
        version_name: versionName.trim(),
        version_code: versionCode,
        apk_url: apkUrl.trim(),
        update_title: title.trim(),
        update_description: description.trim(),
        is_active: isActive,
        created_at: now,
        file_size_mb: fileSizeMb || 18.0
      };

      try {
        const { error: dbErr } = await supabase.from('app_updates').upsert({
          id: newUpdate.id,
          version_name: newUpdate.version_name,
          version_code: newUpdate.version_code,
          apk_url: newUpdate.apk_url,
          update_title: newUpdate.update_title,
          update_description: newUpdate.update_description,
          is_active: newUpdate.is_active,
          created_at: newUpdate.created_at,
          file_size_mb: newUpdate.file_size_mb
        }, { onConflict: 'id' });

        if (dbErr) {
          console.warn('Supabase app_updates custom URL upsert note:', dbErr.message);
        }
      } catch (err) {
        console.warn('Failed to upsert custom URL to app_updates table:', err);
      }

      // Also propagate to settings table for instant live sync across all devices
      if (newUpdate.is_active) {
        try {
          await supabase.from('settings').upsert({
            key: 'latest_active_app_update',
            value: JSON.stringify(newUpdate)
          }, { onConflict: 'key' });
        } catch {}
      }

      setAppUpdates(prev => [newUpdate, ...prev.filter(u => u.id !== newUpdate.id)]);
      localStorage.setItem(STORAGE_KEYS.APP_UPDATES, JSON.stringify([newUpdate, ...appUpdates]));

      return { success: true, update: newUpdate };
    } catch (e: any) {
      return { success: false, error: e?.message || 'تعذر حفظ الرابط المباشر' };
    }
  };

  const adminToggleAppUpdateActive = async (updateId: string) => {
    let newStatus = true;
    setAppUpdates(prev => prev.map(u => {
      if (u.id === updateId) {
        newStatus = !u.is_active;
        return { ...u, is_active: newStatus };
      }
      return u;
    }));

    try {
      await supabase.from('app_updates').update({ is_active: newStatus }).eq('id', updateId);
    } catch (e) {
      console.warn('App update toggle notice:', e);
    }
  };

  const adminDeleteAppUpdate = async (updateId: string) => {
    setAppUpdates(prev => prev.filter(u => u.id !== updateId));
    try {
      await supabase.from('app_updates').delete().eq('id', updateId);
    } catch (e) {
      console.warn('App update delete notice:', e);
    }
  };

  return (
    <AppContext.Provider
      value={{
        currentView,
        setCurrentView,
        products,
        categories,
        budgets,
        stores,
        countries,
        activeCountries,
        paymentMethods,
        orders,
        payments,
        chatMessages,
        favorites,
        appUpdates,
        currentUser,
        isAdmin,
        isOwner,
        moderators,
        isPaymentGatewayEnabled,
        adminTogglePaymentGateway,
        adminAddModerator,
        adminRemoveModerator,
        signInWithGoogleReal,
        loginWithGoogle,
        logout,
        setGuestUser,
        selectedBudget,
        setSelectedBudget,
        selectedCategory,
        setSelectedCategory,
        selectedStore,
        setSelectedStore,
        searchQuery,
        setSearchQuery,
        selectedCountry,
        setSelectedCountry,
        activeCurrency,
        activeCurrencySymbol,
        orderFee,
        orderExpiryMinutes,
        getOrderFeeForCountry,
        getOrderExpiryForCountry,
        settingsMap,
        toggleFavorite,
        createOrder,
        deleteOrder,
        submitPayment,
        deletePayment,
        sendChatMessage,
        adminApprovePayment,
        adminRejectPayment,
        adminUpsertProduct,
        adminDeleteProduct,
        adminToggleFeatured,
        adminUpsertPaymentMethod,
        adminDeletePaymentMethod,
        adminTogglePaymentMethodActive,
        adminSeedPaymentMethodsToSupabase,
        adminSyncPaymentMethodsToSupabase,
        adminResetDefaultPaymentMethods,
        isLiveSyncConnected,
        lastLiveEvent,
        adminToggleCountryActive,
        adminUpsertCountry,
        adminDeleteCountry,
        adminUpdateSettings,
        adminUpdateCountrySettings,
        adminUploadApk,
        adminPublishCustomApkUrl,
        adminToggleAppUpdateActive,
        adminDeleteAppUpdate,
        adminSeedCountriesToSupabase,
        syncWithSupabase,
        getLatestActiveAppUpdate,
        downloadLatestApk,
        latestActiveAppUpdate,
        isAuthModalOpen,
        setIsAuthModalOpen,
        isDownloadModalOpen,
        setIsDownloadModalOpen,
        activeProductModal,
        setActiveProductModal,
        activeOrderModal,
        setActiveOrderModal,
        isChatModalOpen,
        setIsChatModalOpen
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
